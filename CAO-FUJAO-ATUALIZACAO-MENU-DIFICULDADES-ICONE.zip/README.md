# Cão Fujão - atualização visual e de jogabilidade

- Nova tela de boas-vindas em tela cheia.
- Depois de INICIAR, abre diretamente o menu principal (sem tela obrigatória de regras).
- Menu com loja, recordes, moedas, vidas e seleção de dificuldade.
- Dificuldades Fácil, Médio e Hard com parâmetros crescentes.
- Controle direcional em formato de +, com movimento contínuo ao segurar.
- Novo ícone do aplicativo.

Para gerar o APK: abra Actions e execute “CAO FUJAO - GERAR APK”.
