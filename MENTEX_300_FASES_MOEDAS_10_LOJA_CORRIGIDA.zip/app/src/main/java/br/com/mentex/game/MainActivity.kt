package br.com.mentex.game

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var rewardedAd: RewardedAd? = null
    private var interstitialAd: InterstitialAd? = null

    companion object {
        private const val REWARDED_AD_UNIT_ID = "ca-app-pub-3631665156241326/4036769692"
        private const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3631665156241326/2935053979"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(GameBridge(), "AndroidAds")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            loadRewardedAd()
            loadInterstitialAd()
        }
    }
    }

    private fun loadRewardedAd() {
        RewardedAd.load(
            this,
            REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }

    private fun loadInterstitialAd() {
        InterstitialAd.load(
            this,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private inner class GameBridge {
        @JavascriptInterface
        fun speak(text: String) {
            // As falas IA podem ser adicionadas como MP3s no APK.
        }

        @JavascriptInterface
        fun stopSpeech() {
            // MENTEX 3.4 não usa fala. Mantido apenas por compatibilidade.
        }

        @JavascriptInterface
        fun showInterstitialAd() {
            runOnUiThread {
                val ad = interstitialAd
                if (ad != null) {
                    ad.show(this@MainActivity)
                    interstitialAd = null
                    loadInterstitialAd()
                } else {
                    loadInterstitialAd()
                }
            }
        }

        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                val ad = rewardedAd
                if (ad == null) {
                    webView.evaluateJavascript(
                        "alert('O anúncio ainda está carregando. Tente novamente em alguns segundos.');",
                        null
                    )
                    loadRewardedAd()
                    return@runOnUiThread
                }

                ad.show(this@MainActivity) { _: RewardItem ->
                    webView.evaluateJavascript(
                        "window.rewardFromAd && window.rewardFromAd();",
                        null
                    )
                }
                rewardedAd = null
                loadRewardedAd()
            }
        }
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
