MENTEX — PROJETO PARA GERAR APK
================================

Este ZIP foi preparado a partir do APK enviado nesta conversa.

Preservado:
- Boas-vindas e regras existentes.
- Perguntas, lógica de jogo e fases presentes no APK.
- Cérebro e imagens de reação existentes.
- Perfil, ranking, loja, vidas, moedas, dicas e escudos.
- Ícone MENTEX que acompanha o aplicativo.

Acrescentado:
- Botão "Convidar amigos para jogar", com compartilhamento do Android
  quando disponível e cópia do convite como alternativa.

IMPORTANTE:
- O APK enviado contém 200 fases. O projeto preserva os dados recebidos;
  não inventei perguntas ou fases adicionais.
- A loja mantém o comportamento que já existia. Compras reais na Google
  Play exigem produtos e Billing configurados no Play Console.
- O fluxo gera APK DEBUG para teste. Publicação exige assinatura de release.
- Uma nova assinatura não garante, sozinha, que o Play Protect deixe de
  exibir alertas.

COMO GERAR:
1. Extraia o ZIP e envie os arquivos para um repositório GitHub.
2. Abra a aba Actions.
3. Escolha "Gerar APK MENTEX".
4. Toque em "Run workflow".
5. Ao terminar, baixe o artefato "MENTEX-APK".

Estrutura:
- www/: telas, perguntas, lógica e imagens.
- config.xml e package.json: configuração Cordova.
- .github/workflows/build-apk.yml: compilação automática.
- res/: ícone do aplicativo.
