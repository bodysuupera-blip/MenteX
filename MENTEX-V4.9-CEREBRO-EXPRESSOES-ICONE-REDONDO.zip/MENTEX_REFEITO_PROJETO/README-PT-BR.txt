MENTEX 4.7 — PROJETO ANDROID RECONSTRUÍDO A PARTIR DOS ARQUIVOS RECUPERADOS DO APK

O projeto inclui uma Activity Android com WebView, o jogo recuperado e workflow do GitHub Actions para compilar um APK de teste.

CORREÇÕES NA TELA DE PERGUNTAS:
- O botão “Usar dica” agora revela a dica ao toque, mesmo se o inventário de dicas estiver zerado. Se houver dica guardada, uma é consumida.
- A caixa de dica não fica mais cortada por altura máxima fixa e aceita quebra de linha.
- Cérebro, pergunta e alternativas ficam maiores, com ajuste responsivo.

COMO GERAR O APK:
1. Envie a pasta do projeto para um repositório GitHub.
2. Abra Actions > “MENTEX 4.7 - Gerar APK” > Run workflow.
3. Ao terminar, abra o artefato “MENTEX-4.7-APK” e baixe o APK.

LIMITAÇÕES IMPORTANTES:
- Este é um projeto Android reconstruído a partir dos recursos recuperáveis do APK, não o projeto-fonte original.
- O APK de saída do workflow é um APK debug para teste, não um pacote assinado para publicação no Google Play.
- Compras do Google Play dependem de integração nativa e configuração de produtos; os textos existentes na interface não garantem compras reais.
- Não foi possível executar a compilação Android neste ambiente; o workflow foi preparado para compilar no GitHub Actions. Teste no aparelho antes de substituir o app atual.


ATUALIZAÇÃO V4.8 — INTERFACE MODERNA
- Visual renovado com cartões modernos, gradientes discretos, botões refinados e navegação inferior.
- Tela de perguntas continua sem rolagem e adapta o tamanho do cérebro e das respostas à altura da tela.
- Lógica do jogo e progresso foram mantidos.
- Para compilar, use o workflow .github/workflows/build-apk.yml.


ATUALIZACAO V4.9: icone circular do aplicativo MENTEX aplicado ao launcher Android. A tela de pergunta usa brain_neutral.png (cerebro pensando), acerto usa brain_happy.png (cerebro feliz) e erro usa brain_sad.png (cerebro triste). Esses recursos ficam em app/src/main/assets/www. Versao do app: 4.9 (versionCode 49).
