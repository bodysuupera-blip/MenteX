MENTEX V4.6 COMPACTO

IMPORTANTE:
1. O conteúdo deste ZIP deve ser colocado na RAIZ do repositório GitHub.
2. A pasta .github/workflows/main.yml deve ficar exatamente nesse caminho.
3. Não deixe uma pasta "mentex" envolvendo todos os arquivos.
4. No GitHub, abra Actions > Build MENTEX V4.6 Compacto > Run workflow.
5. Ao terminar, o APK estará em Artifacts como MENTEX-V4.6-COMPACTO.

O projeto usa Java 17, Android Gradle Plugin 8.6.1 e Gradle 8.7.
