# MENTEX 2.0

Jogo Android de desafios mentais com 50 fases, vidas, moedas, pontuação, estrelas, bônus diário, conquistas, loja virtual, ranking local e integração AdMob.

## Build
- Kotlin 2.3.0
- Android Gradle Plugin 8.6.1
- Gradle 8.7
- Java 17
- AdMob 25.4.0

## Observação
Esta versão usa armazenamento local para progresso e ranking. Compras com dinheiro real e ranking online exigem integrações adicionais antes da publicação.
