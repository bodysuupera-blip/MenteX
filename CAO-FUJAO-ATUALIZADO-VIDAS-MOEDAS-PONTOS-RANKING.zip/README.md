# Cão Fujão — atualização de progressão e ranking

- Ícone redondo mantido.
- Na migração para esta versão: 10 vidas e 0 moedas.
- Cada moeda coletada vale 10 moedas.
- Fases concluídas dão pontos, não moedas nem vidas.
- Cachorro movimenta-se aleatoriamente em cerca de 85% das jogadas.
- Removida a escrita “Modo Fácil”.
- Obstáculos aumentam gradualmente até 12 nas fases avançadas.
- Loja: item mais barato por 200 moedas; vantagens especiais custam mais.
- Ranking local com as 10 melhores pontuações.

O ranking é local ao aparelho. Ranking online compartilhado exige backend.
Compilação: Java 17, Gradle 8.9, Android SDK Platform 35.
