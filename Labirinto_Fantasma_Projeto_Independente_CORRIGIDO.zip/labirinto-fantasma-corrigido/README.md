# Labirinto Fantasma — pacote independente corrigido

Este ZIP contém os arquivos do aplicativo na raiz do pacote. Para compilar pelo GitHub Actions no repositório MenteX, coloque este ZIP na raiz do repositório com o nome `Labirinto_Fantasma_Projeto_Independente.zip` e use o workflow fornecido separadamente.


## Estrutura
- `package.json`
- `capacitor.config.json`
- `www/index.html`


## Compilação
O workflow baixa o ZIP do repositório, extrai os arquivos para uma pasta de trabalho temporária, instala Capacitor/Android e gera o APK debug.


## Observação
O jogo usa moedas e itens virtuais locais. Não inclui faturamento Google Play Billing nem anúncios AdMob reais.
