package com.mentex.caofujaonovo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 27, 55));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 27, 55));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 27, 55));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class ShareBridge {
        @JavascriptInterface
        public void share(String message) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, message);
                try {
                    startActivity(Intent.createChooser(send, "Convidar amigos"));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Compartilhamento indisponível", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null) {
            webView.evaluateJavascript("(function(){const s=['rules','game','result','shop','end'];let found=s.find(id=>!document.getElementById(id).classList.contains('hidden'));if(found){if(found==='game'){document.getElementById('pause').click();}document.getElementById(found).classList.add('hidden');document.getElementById('home').classList.remove('hidden');document.body.classList.add('home-screen');return 'handled';}return 'home';})()", null);
        } else {
            super.onBackPressed();
        }
    }
}
