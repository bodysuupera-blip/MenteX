package com.caofujao.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;

import com.android.billingclient.api.*;
import org.json.JSONObject;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private BillingClient billing;
    private boolean pageReady = false;
    private final List<Purchase> pendingDeliveries = new ArrayList<>();
    private static final String[] PRODUCT_IDS = {"coins_500","coins_1500","coins_4000","coins_10000"};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,27,55));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,27,55));
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                flushPurchases();
                connectBilling();
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void share(String message) {
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(send, "Convidar amigos"));
                });
            }
        }, "AndroidShare");
        web.addJavascriptInterface(new BillingBridge(), "AndroidBilling");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class BillingBridge {
        @JavascriptInterface public void buyProduct(String productId) {
            runOnUiThread(() -> launchPurchase(productId));
        }
        @JavascriptInterface public void consumePurchase(String token) {
            runOnUiThread(() -> consume(token));
        }
    }

    private void connectBilling() {
        if (billing != null && billing.isReady()) {
            queryProducts();
            queryExistingPurchases();
            return;
        }
        billing = BillingClient.newBuilder(this)
            .setListener((result, purchases) -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                    for (Purchase purchase : purchases) handlePurchase(purchase);
                } else if (result.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
                    js("window.onBillingReady && window.onBillingReady(false," +
                        JSONObject.quote("Não foi possível concluir a compra: " + result.getDebugMessage()) + ")");
                }
            })
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .build();
        billing.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    js("window.onBillingReady && window.onBillingReady(true,'Google Play conectada')");
                    queryProducts();
                    queryExistingPurchases();
                } else {
                    js("window.onBillingReady && window.onBillingReady(false,'Google Play indisponível. Verifique a instalação pela Play Store.')");
                }
            }
            @Override public void onBillingServiceDisconnected() {
                js("window.onBillingReady && window.onBillingReady(false,'Conexão com a Google Play interrompida')");
            }
        });
    }

    private void queryProducts() {
        if (billing == null || !billing.isReady()) return;
        List<QueryProductDetailsParams.Product> products = new ArrayList<>();
        for (String id : PRODUCT_IDS) products.add(QueryProductDetailsParams.Product.newBuilder()
            .setProductId(id).setProductType(BillingClient.ProductType.INAPP).build());
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(products).build();
        billing.queryProductDetailsAsync(params, (result, queryResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) return;
            JSONObject prices = new JSONObject();
            for (ProductDetails detail : queryResult.getProductDetailsList()) {
                try {
                    if (detail.getOneTimePurchaseOfferDetails() != null)
                        prices.put(detail.getProductId(), detail.getOneTimePurchaseOfferDetails().getFormattedPrice());
                } catch (Exception ignored) {}
            }
            js("window.onBillingProducts && window.onBillingProducts(" + JSONObject.quote(prices.toString()) + ")");
        });
    }

    private void launchPurchase(String productId) {
        if (!Arrays.asList(PRODUCT_IDS).contains(productId)) return;
        if (billing == null || !billing.isReady()) {
            js("window.onBillingReady && window.onBillingReady(false,'Google Play ainda está conectando. Tente novamente.')");
            connectBilling();
            return;
        }
        List<QueryProductDetailsParams.Product> products = Collections.singletonList(
            QueryProductDetailsParams.Product.newBuilder().setProductId(productId)
                .setProductType(BillingClient.ProductType.INAPP).build());
        billing.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(products).build(),
            (result, queryResult) -> {
                if (result.getResponseCode() != BillingClient.BillingResponseCode.OK ||
                    queryResult.getProductDetailsList().isEmpty()) {
                    js("window.onBillingReady && window.onBillingReady(false,'Produto não encontrado. Confira o cadastro no Play Console.')");
                    return;
                }
                ProductDetails detail = queryResult.getProductDetailsList().get(0);
                BillingFlowParams flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(
                    Collections.singletonList(BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(detail).build())).build();
                billing.launchBillingFlow(this, flow);
            });
    }

    private void queryExistingPurchases() {
        if (billing == null || !billing.isReady()) return;
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP).build();
        billing.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK)
                for (Purchase purchase : purchases) handlePurchase(purchase);
        });
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        if (!pageReady) {
            pendingDeliveries.add(purchase);
            return;
        }
        for (String product : purchase.getProducts()) {
            js("window.onGooglePurchase && window.onGooglePurchase(" +
                JSONObject.quote(product) + "," + JSONObject.quote(purchase.getPurchaseToken()) + ")");
        }
    }

    private void flushPurchases() {
        for (Purchase purchase : new ArrayList<>(pendingDeliveries)) handlePurchase(purchase);
        pendingDeliveries.clear();
    }

    private void consume(String token) {
        if (billing == null || !billing.isReady()) return;
        ConsumeParams params = ConsumeParams.newBuilder().setPurchaseToken(token).build();
        billing.consumeAsync(params, (result, purchaseToken) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK)
                js("window.onBillingReady && window.onBillingReady(false,'Moedas registradas; confirmação final pendente.')");
        });
    }

    private void js(String script) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(script, null); });
    }

    @Override protected void onDestroy() {
        if (billing != null) billing.endConnection();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
