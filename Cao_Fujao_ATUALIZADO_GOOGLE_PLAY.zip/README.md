# Cão Fujão — atualização 1.1

Projeto Android (Java + WebView) com 100 fases progressivas e integração inicial com Google Play Billing 7.1.1 para venda de pacotes consumíveis de moedas.

## Mudanças
- Removido o seletor Fácil / Médio / Hard: existe uma dificuldade única e progressiva.
- Fases iniciais mais acessíveis; obstáculos e inteligência do cão aumentam gradualmente, com limites.
- Itens da loja com efeitos no jogo: tênis turbo, rede mágica, chapéu de herói, tentativa extra, coleira dourada e escudo.
- Loja com integração nativa Google Play Billing.
- IDs dos pacotes: `coins_500`, `coins_1500`, `coins_4000`, `coins_10000`.

## Configuração obrigatória no Google Play Console
1. O app precisa usar o applicationId `com.caofujao.game`.
2. Gere e envie um Android App Bundle (AAB) assinado para uma faixa de teste interno.
3. Em Monetização > Produtos > Produtos únicos, cadastre os quatro IDs exatamente como acima, configure os preços e ative os produtos.
4. Adicione os e-mails dos testadores em Configurações > Testadores de licença e/ou na faixa de teste interno.
5. Instale o app pelo link da faixa de teste da Play Store (não por APK instalado diretamente), usando a conta cadastrada como testadora.
6. Teste compra, cancelamento e recuperação antes de publicar.

## Segurança
O código demonstra o fluxo Billing, credita moedas localmente e consome o produto. Para lançamento comercial com proteção robusta contra fraude ou alteração dos dados locais, valide o token da compra em um servidor usando a Google Play Developer API. Não coloque credenciais de serviço Google dentro do APK.

## Compilação
Abra no Android Studio com JDK 17 e Android SDK 35, sincronize o Gradle e gere um Android App Bundle em Build > Generate Signed Bundle / APK > Android App Bundle. O ZIP contém código-fonte, não um APK compilado; o projeto original não inclui Gradle Wrapper.
