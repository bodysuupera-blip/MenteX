# Cão Fujão 1.3

Atualização do jogo com progressão de dificuldade mais suave, efeitos sonoros e música gerados no próprio jogo (sem arquivos externos), botão para ligar/desligar o som e loja com descrição dos itens, confirmação de compra e efeitos de uso.

## Dificuldade
- Fases 1–5: cachorro se move a cada 3 jogadas do jogador; sem paredes; 32 jogadas para capturar.
- Fases 6–15: cachorro se move a cada 2 jogadas; 28 jogadas para capturar.
- A partir da fase 16: movimento a cada jogada, com inteligência e limite de jogadas aumentando gradualmente.

## Loja
- Tênis turbo: a cada 4 movimentos, o cachorro perde a vez.
- Rede mágica: captura quando o cachorro fica a até 2 casas.
- Chapéu de herói: +20 moedas por vitória.
- Tentativa extra: +1 vida imediata.
- Coleira dourada: +5 moedas por vitória.
- Escudo: evita uma derrota e é consumido ao proteger.

Compras de moedas pela Google Play exigem que os produtos coins_500, coins_1500, coins_4000 e coins_10000 estejam cadastrados e ativos no Play Console.
