# Cão Fujão — Nível HARD 🐾

Projeto Android nativo simples com jogo em HTML5 dentro de uma WebView.

## O que vem no ZIP
- Projeto Android Studio (Java + Gradle).
- Jogo HTML5 em `app/src/main/assets/index.html`.
- 100 fases progressivas, 10 tentativas iniciais, moedas, pontos, loja local, tutorial e convite via compartilhamento do Android.
- Progresso salvo localmente no aparelho.

## Como gerar o APK
1. Instale o Android Studio e o Android SDK.
2. Abra esta pasta no Android Studio (`File > Open`).
3. Aguarde a sincronização do Gradle.
4. Selecione `Build > Build Bundle(s) / APK(s) > Build APK(s)`.
5. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Este ZIP contém o **código-fonte do aplicativo**, não um APK já compilado. A compilação precisa do Android SDK/Android Studio.

## Requisitos
- Android Studio recente
- JDK 17
- Android SDK 35
