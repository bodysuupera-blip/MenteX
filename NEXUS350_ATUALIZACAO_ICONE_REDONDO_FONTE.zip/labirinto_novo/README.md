# Labirinto de Fantasmas (projeto independente)

## Gerar APK pelo GitHub Actions
1. Envie o conteúdo deste ZIP para um repositório GitHub vazio (incluindo `.github/workflows`).
2. Abra Actions e execute `Labirinto de Fantasmas - APK Independente` usando Run workflow.
3. Baixe o APK em Artifacts após o workflow concluir.

Projeto web/Capacitor de demonstração. O APK debug é gerado; publicação Play Store e compras reais/ads reais precisam ser configuradas separadamente com IDs de produto, Play Console e SDKs apropriados.
