# Labirinto Fantasma - Projeto independente

Jogo mobile web empacotável via Capacitor para Android.

## Funcionalidades
- Menu responsivo, 300 fases e 10 mundos (estrutura de progressão).
- Labirinto procedural, chave/portal, moedas e fantasmas perseguidores.
- Loja com compras usando moedas e inventário de poderes.
- Tutorial/manual, perfil local, sons gerados via WebAudio, controles touch e teclado.
- Escudo, velocidade, invisibilidade, mapa, armadilha e chave mágica.

## Gerar APK via GitHub Actions
1. Envie o conteúdo deste ZIP para a raiz do repositório (ou mantenha a pasta `labirinto-fantasma` e `.github/workflows`).
2. Abra Actions e execute `LABIRINTO FANTASMA - APK`.
3. Baixe o artefato `LABIRINTO-FANTASMA-APK`.

Observações: moedas/progresso salvam localmente no navegador (localStorage). Compra na loja é com moedas do jogo; não existe integração de compra real Play Billing/AdMob neste ZIP. O anúncio de recompensa real não está conectado. Este projeto é independente de MenteX e Cão Fujão.
