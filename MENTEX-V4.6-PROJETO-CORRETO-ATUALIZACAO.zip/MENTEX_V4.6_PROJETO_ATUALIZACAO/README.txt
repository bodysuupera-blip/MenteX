MENTEX V4.6 - PROJETO PARA GERAR APK

1. Envie todos estes arquivos para um repositorio GitHub.
2. Abra Actions.
3. Execute "MENTEX V4.6 - Compilar APK Atualizado".
4. Abra o resultado da execucao.
5. Em Artifacts, baixe MENTEX-V4.6-ATUALIZADO.

IMPORTANTE:
Este projeto recompila o aplicativo. Ele nao apenas copia um APK antigo.
O APK gerado e uma nova instalacao e pode exigir desinstalar uma versao anterior
assinada com outra chave.
