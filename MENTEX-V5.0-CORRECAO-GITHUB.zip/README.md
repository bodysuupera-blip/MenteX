# MENTEX V5.0 — projeto inicial reconstruído

Esta é uma reconstrução nova do jogo para Android, criada sem o código-fonte original. Inclui uma interface de jogo em tela cheia, mascote de cérebro animado, perguntas de demonstração, moedas, corações, escudo, loja e perfil local.

## Gerar o APK pelo GitHub
1. Crie/abra um repositório no GitHub.
2. Envie **todos os arquivos e pastas deste ZIP** para a raiz do repositório.
3. Abra a aba **Actions**.
4. Selecione **MENTEX V5.0 - Gerar APK** e clique em **Run workflow**.
5. Quando terminar, abra a execução concluída e baixe o artefato **MENTEX-V5.0-APK**.

## Importante
- O ZIP contém o projeto-fonte reconstruído, não um APK pronto.
- As perguntas incluídas são perguntas novas de demonstração; o APK antigo fornecido continha apenas o aplicativo compilado e não o projeto original. Portanto, não foi possível garantir a recuperação de todas as perguntas antigas.
- O saldo, o perfil e o progresso ficam guardados localmente neste dispositivo.
- A loja funciona como protótipo com moedas e itens virtuais. **Compras com dinheiro real ainda não estão integradas**; para publicar na Play Store, será necessário implementar e testar Google Play Billing, verificação de compras e políticas aplicáveis.
- Teste o APK em aparelhos diferentes antes de distribuir.
