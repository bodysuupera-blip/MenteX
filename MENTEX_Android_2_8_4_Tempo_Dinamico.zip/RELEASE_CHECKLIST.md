# MENTEX 1.1 — Checklist de publicação

## Código
- [x] versionName 1.1.0
- [x] targetSdk 36
- [x] compileSdk 36
- [x] applicationId `br.com.mentex.game`
- [ ] Gerar AAB assinado em Android Studio.
- [ ] Testar em pelo menos 2 aparelhos/versões Android.
- [ ] Testar rotação/tela pequena.
- [ ] Testar perda de vida, compra na loja e bônus diário.
- [ ] Testar anúncio recompensado.
- [ ] Remover IDs de teste do AdMob somente quando os IDs de produção estiverem configurados e o app tiver sido validado.

## AdMob
- [ ] Criar aplicativo MENTEX no AdMob.
- [ ] Criar unidade de anúncio recompensado de produção.
- [ ] Se forem usados intersticiais/banners, criar as unidades correspondentes.
- [ ] Substituir os IDs de teste por IDs reais antes da versão de produção.
- [ ] Confirmar consentimento e requisitos de privacidade aplicáveis ao público/região.
- [ ] Nunca clicar nos próprios anúncios durante testes.

## Google Play
- [ ] Criar app no Play Console.
- [ ] Enviar ícone e screenshots reais.
- [ ] Preencher classificação indicativa.
- [ ] Preencher Segurança dos dados.
- [ ] Adicionar URL pública da Política de Privacidade.
- [ ] Preencher informações de anúncios.
- [ ] Revisar conteúdo para não prometer ganhos financeiros.
- [ ] Criar versão de teste interno antes da produção.
- [ ] Gerar AAB assinado.
- [ ] Fazer upload e corrigir avisos do Play Console.
- [ ] Só depois promover para produção.

## Legal/privacidade
- [ ] Substituir `[NOME/EMPRESA]`.
- [ ] Substituir `[E-MAIL DE PRIVACIDADE]`.
- [ ] Publicar `POLITICA_PRIVACIDADE.html` em um endereço HTTPS público.
- [ ] Conferir a política com as práticas reais do AdMob e demais SDKs.
