# MENTEX — Material para Google Play

## Nome
**MENTEX — Desafie sua mente**

## Frase curta
**Desafie sua mente em fases rápidas, teste sua memória e supere seu próprio recorde!**

## Descrição completa
**MENTEX** é um jogo de desafios mentais rápidos para quem gosta de testar atenção, memória, raciocínio e velocidade.

🧠 **50 fases** em 5 mundos  
⚡ Desafios rápidos e variados  
🏆 Conquistas e progressão de jogador  
🔥 Sequência de vitórias para buscar recordes  
🪙 Moedas para usar na loja  
❤️ Sistema de vidas  
🎁 Bônus diário  
📺 Anúncios recompensados opcionais para ganhar benefícios

Cada fase traz um pequeno desafio. Observe, pense e responda antes que o tempo acabe.

Seu objetivo é chegar ao **DESAFIO SUPREMO MENTEX**, completar as 50 fases e construir a maior pontuação possível.

**MENTEX — Desafie sua mente. Supere seus limites.**

## Categoria sugerida
**Jogos → Quebra-cabeça** (confirme a categoria mais adequada no Play Console).

## Checklist de mídia
- Ícone do app em alta resolução.
- Pelo menos 2–4 capturas de tela reais do jogo.
- Uma captura mostrando o mapa das 50 fases.
- Uma captura mostrando perfil/conquistas.
- Uma captura mostrando a loja.
- Não usar imagens ou textos que prometam dinheiro ou prêmios em dinheiro.

## Observação
As informações da ficha devem corresponder exatamente à versão enviada e aos recursos efetivamente ativos.
