# Segurança dos dados — roteiro para o Play Console

Este arquivo é um **roteiro**, não uma declaração automática. O preenchimento final deve ser conferido contra a versão publicada, inclusive todos os SDKs.

## Antes de preencher
- [ ] Confirmar quais SDKs estão no APK/AAB.
- [ ] Confirmar se AdMob está ativo.
- [ ] Conferir as práticas de coleta/compartilhamento dos SDKs de publicidade.
- [ ] Publicar a Política de Privacidade em URL público.
- [ ] Garantir que a política e a seção Segurança dos dados não se contradigam.

## Situação da versão MENTEX 1.1
- Progresso do jogo: armazenamento local.
- Conta/login: não implementado.
- Ranking online: não implementado; ranking atual é local/demonstrativo.
- Publicidade: Google Mobile Ads está integrado.
- IDs de produção do AdMob: ainda não fornecidos pelo desenvolvedor.

**Atenção:** não marque “nenhum dado coletado” simplesmente porque o MENTEX usa localStorage. O Google exige que também sejam consideradas as práticas dos SDKs de terceiros usados no aplicativo.

## Referências oficiais
Consulte a documentação atual do Google Play antes de enviar a ficha, pois as declarações precisam refletir o comportamento real da versão distribuída.
