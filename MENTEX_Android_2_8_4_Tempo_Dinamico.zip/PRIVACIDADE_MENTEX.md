# Política de Privacidade — MENTEX

**Última atualização:** 14 de setembro de 2026

Esta é uma **minuta para publicação**. Antes de colocar o MENTEX no Google Play, substitua os campos entre `[ ]` pelos dados reais do desenvolvedor e confirme que o texto corresponde exatamente aos SDKs e recursos ativados na versão publicada.

## 1. Quem somos

O aplicativo **MENTEX** é desenvolvido por **[NOME/EMPRESA]**.

Contato de privacidade: **[E-MAIL DE PRIVACIDADE]**.

## 2. Sobre o MENTEX

MENTEX é um jogo de desafios mentais com fases, pontuação, moedas virtuais, vidas, conquistas e outros recursos de progressão.

## 3. Dados armazenados no dispositivo

Na versão atual, o progresso do jogo é armazenado localmente no dispositivo por meio do armazenamento do aplicativo (por exemplo, progresso de fases, pontuação, moedas, vidas, sequência e conquistas).

Esses dados locais não devem ser descritos como uma conta online. Se futuramente houver login, ranking online, sincronização em nuvem ou outro serviço remoto, esta política deverá ser atualizada.

## 4. Publicidade

O aplicativo pode utilizar o Google Mobile Ads (AdMob) para exibir anúncios e, quando habilitado, anúncios recompensados.

Serviços de publicidade de terceiros podem tratar informações do dispositivo e identificadores relacionados à publicidade de acordo com suas próprias políticas e configurações. Antes da publicação, o desenvolvedor deve revisar a documentação e as práticas efetivamente usadas pelo SDK instalado e refletir essas práticas na seção **Segurança dos dados** do Google Play.

## 5. Dados que não devem ser prometidos

Esta política não afirma que o MENTEX não coleta dados em nenhuma circunstância. A declaração final deve considerar o comportamento da versão publicada, inclusive bibliotecas e SDKs de terceiros.

## 6. Compartilhamento

O MENTEX não deve vender dados pessoais dos usuários.

Quando serviços de terceiros forem utilizados (por exemplo, publicidade), o tratamento de dados realizado por esses serviços deve ser informado de acordo com a configuração efetivamente utilizada no aplicativo e com as políticas aplicáveis.

## 7. Retenção e exclusão

Os dados de progresso armazenados apenas no dispositivo podem ser removidos pelo usuário ao limpar os dados do aplicativo ou desinstalá-lo, conforme o funcionamento do Android.

Se forem adicionados dados associados a uma conta ou armazenados em servidores, deverá existir um mecanismo adequado para solicitação de exclusão desses dados e esta política deverá ser atualizada.

## 8. Crianças

O MENTEX não deve ser apresentado como aplicativo direcionado especificamente a crianças sem que o desenvolvedor primeiro revise e implemente todos os requisitos aplicáveis às políticas do Google Play para famílias e à legislação pertinente.

## 9. Segurança

São adotadas medidas razoáveis para proteger o aplicativo e os dados tratados. Nenhum método de armazenamento ou transmissão pode ser garantido como absolutamente seguro.

## 10. Alterações

Esta política poderá ser atualizada quando houver mudanças no aplicativo, nos SDKs, na publicidade ou nas práticas de tratamento de dados.

## 11. Contato

Para dúvidas sobre privacidade:

**[NOME/EMPRESA]**  
**[E-MAIL]**

---
**Importante:** publique esta política em uma página web pública, estável e acessível sem login. O Google Play exige uma política de privacidade acessível no app e vinculada à ficha do aplicativo.
