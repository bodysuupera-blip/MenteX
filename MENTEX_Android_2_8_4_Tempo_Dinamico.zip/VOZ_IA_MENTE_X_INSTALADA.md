# Voz IA Mente X

O arquivo `app/src/main/assets/mentex_intro.mp3` foi substituído pela gravação enviada pelo proprietário do projeto.

A reprodução da abertura usa `AssetFileDescriptor`, garantindo que o MP3 dentro do APK seja lido corretamente pelo Android.
