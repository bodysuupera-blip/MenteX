# MENTEX V4.8

Atualização focada nas perguntas em tela cheia.

- Pergunta e alternativas sem rolagem.
- Conteúdo ajustado automaticamente à altura disponível.
- Tela de desafio ocupa toda a área útil.
- Mantém abertura em duas imagens e música de introdução.
- Java 17 e Android Gradle Plugin 8.6.1.
- Compile SDK 35 para compatibilidade com AGP 8.6.1.

## Compilação
O workflow do GitHub Actions deve instalar Gradle 8.7 e executar `gradle clean assembleDebug`; este projeto não depende de `./gradlew` dentro do ZIP.
