# MENTEX — Nova Geração

Projeto novo criado do zero, com proposta de jogo de perguntas por fases.

## Recursos incluídos
- Abertura de boas-vindas e regras antes de jogar.
- Fases e desbloqueio progressivo.
- Meu Jogador / Meu Perfil e nome personalizável.
- Moedas, vidas e escudos.
- Loja, ranking local e conquistas.
- Convite de amigos usando o compartilhamento do aparelho.
- Recompensa única por pergunta acertada: a pergunta fica gravada no armazenamento local e não paga moedas novamente.

## Gerar APK pelo GitHub
1. Crie um repositório GitHub e envie todos os arquivos deste ZIP.
2. Abra Actions.
3. Selecione **MENTEX - Gerar APK**.
4. Clique em **Run workflow**.
5. Ao terminar, baixe o artefato **MENTEX-NOVA-GERACAO-APK**.

## Observações
- Esta é uma primeira versão funcional, independente do projeto antigo.
- O progresso fica salvo localmente no aparelho; não sincroniza entre aparelhos.
- O ranking é local, não é um ranking online.
- O convite abre o compartilhamento nativo; ainda não existe sistema de contas, links individuais ou recompensas por indicação verificadas.
- O banco de perguntas inicial é demonstrativo e pode ser ampliado.
