NEXUS - PACOTE DE ÍCONE ANDROID

Conteúdo:
- assets/icons/nexus_icon_master.png: ícone mestre em alta resolução
- assets/icons/mipmap-*/ic_launcher.png: ícones por densidade Android
- assets/icons/mipmap-*/ic_launcher_round.png: variantes redondas
- .github/workflows/nexus-icon-apk.yml: workflow para compilar APK no GitHub Actions

Como usar:
1. Copie a pasta assets/icons e a pasta .github/workflows para a raiz do repositório Nexus.
2. No GitHub, abra Actions > NEXUS - APK com novo ícone > Run workflow.
3. Aguarde a compilação. O APK estará em Artifacts com o nome NEXUS-APK-NOVO-ICONE.

O workflow espera que o projeto Android já tenha android/app/src/main e android/gradlew.
