package br.com.mentex.game

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.content.SharedPreferences
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClient.ProductType
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.ConsumeParams
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.QueryProductDetailsParams
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

class MainActivity : Activity(), BillingClient.PurchasesUpdatedListener {
    private lateinit var webView: WebView
    private lateinit var prefs: SharedPreferences
    private lateinit var billingClient: BillingClient
    private var rewardedAd: RewardedAd? = null
    private var interstitialAd: InterstitialAd? = null
    private val products = mutableMapOf<String, ProductDetails>()

    companion object {
        private const val REWARDED_AD_UNIT_ID = "ca-app-pub-3631665156241326/4036769692"
        private const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3631665156241326/2935053979"
        private const val PREFS = "mentex_billing"
        private const val GRANTED_TOKENS = "granted_purchase_tokens"
        private const val COINS_100 = "coins_100"
        private const val COINS_550 = "coins_550"
        private const val COINS_1200 = "coins_1200"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        hideSystemBars()

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE)

        webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.settings.setSupportZoom(false)
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(GameBridge(), "AndroidAds")
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")

        setupBilling()

        MobileAds.initialize(this) {
            loadRewardedAd()
            loadInterstitialAd()
        }
    }

    private fun hideSystemBars() {
        window.decorView.systemUiVisibility = (
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                or View.SYSTEM_UI_FLAG_FULLSCREEN
                or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            )
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        }
    }

    private fun setupBilling() {
        billingClient = BillingClient.newBuilder(this)
            .setListener(this)
            .enablePendingPurchases(
                PendingPurchasesParams.newBuilder()
                    .enableOneTimeProducts()
                    .build()
            )
            .build()

        billingClient.startConnection(object : BillingClient.BillingClientStateListener() {
            override fun onBillingSetupFinished(result: BillingResult) {
                if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                    queryCoinProducts()
                    queryExistingPurchases()
                } else {
                    sendBillingMessage("Não foi possível conectar à Google Play agora.")
                }
            }

            override fun onBillingServiceDisconnected() {
                // A próxima tentativa de compra reconecta automaticamente.
            }
        })
    }

    private fun queryCoinProducts() {
        val productList = listOf(COINS_100, COINS_550, COINS_1200).map {
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId(it)
                .setProductType(ProductType.INAPP)
                .build()
        }

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(productList)
            .build()

        billingClient.queryProductDetailsAsync(params) { result, detailsResult ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK) return@queryProductDetailsAsync

            products.clear()
            detailsResult.productDetailsList.forEach { product ->
                products[product.productId] = product
                val price = product.oneTimePurchaseOfferDetailsList
                    ?.firstOrNull()
                    ?.formattedPrice
                    ?: ""
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.setCoinPrice && window.setCoinPrice('${product.productId}', '${escapeJs(price)}');",
                        null
                    )
                }
            }
        }
    }

    private fun queryExistingPurchases() {
        if (!billingClient.isReady) return
        val params = BillingClient.QueryPurchasesParams.newBuilder()
            .setProductType(ProductType.INAPP)
            .build()
        billingClient.queryPurchasesAsync(params) { result, purchaseList ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                purchaseList.forEach { processPurchase(it) }
            }
        }
    }

    private fun escapeJs(value: String): String = value
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\n", " ")

    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        when (result.responseCode) {
            BillingClient.BillingResponseCode.OK -> purchases?.forEach { processPurchase(it) }
            BillingClient.BillingResponseCode.USER_CANCELED -> sendBillingMessage("Compra cancelada.")
            else -> sendBillingMessage("A compra não foi concluída. Tente novamente.")
        }
    }

    private fun processPurchase(purchase: Purchase) {
        if (purchase.purchaseState != Purchase.PurchaseState.PURCHASED) return

        purchase.products.forEach { productId ->
            val amount = when (productId) {
                COINS_100 -> 100
                COINS_550 -> 550
                COINS_1200 -> 1200
                else -> 0
            }

            if (amount > 0) {
                grantCoinsIfNeeded(purchase.purchaseToken, amount)
            }
        }
    }

    private fun grantCoinsIfNeeded(token: String, amount: Int) {
        val granted = prefs.getStringSet(GRANTED_TOKENS, emptySet())?.toMutableSet() ?: mutableSetOf()

        if (!granted.contains(token)) {
            granted.add(token)
            prefs.edit().putStringSet(GRANTED_TOKENS, granted).apply()

            runOnUiThread {
                webView.evaluateJavascript(
                    "window.coinsPurchased && window.coinsPurchased($amount);",
                    null
                )
            }
        }

        consumePurchase(token)
    }

    private fun consumePurchase(token: String) {
        val params = ConsumeParams.newBuilder()
            .setPurchaseToken(token)
            .build()

        billingClient.consumeAsync(params) { result, _ ->
            if (result.responseCode != BillingClient.BillingResponseCode.OK &&
                result.responseCode != BillingClient.BillingResponseCode.ITEM_NOT_OWNED) {
                sendBillingMessage("A compra foi recebida, mas a confirmação ainda está sendo processada.")
            }
        }
    }

    private fun sendBillingMessage(message: String) {
        runOnUiThread {
            if (::webView.isInitialized) {
                webView.evaluateJavascript(
                    "window.coinPurchaseMessage && window.coinPurchaseMessage('${escapeJs(message)}');",
                    null
                )
            }
        }
    }

    private fun loadRewardedAd() {
        RewardedAd.load(
            this,
            REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }

    private fun loadInterstitialAd() {
        InterstitialAd.load(
            this,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }

                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private inner class GameBridge {
        @JavascriptInterface
        fun showInterstitialAd() {
            runOnUiThread {
                val ad = interstitialAd
                if (ad != null) {
                    ad.show(this@MainActivity)
                    interstitialAd = null
                    loadInterstitialAd()
                } else {
                    loadInterstitialAd()
                }
            }
        }

        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                val ad = rewardedAd
                if (ad == null) {
                    webView.evaluateJavascript(
                        "window.coinPurchaseMessage && window.coinPurchaseMessage('O anúncio ainda está carregando. Tente novamente em alguns segundos.');",
                        null
                    )
                    loadRewardedAd()
                    return@runOnUiThread
                }

                ad.show(this@MainActivity) { _: RewardItem ->
                    webView.evaluateJavascript(
                        "window.rewardFromAd && window.rewardFromAd();",
                        null
                    )
                }
                rewardedAd = null
                loadRewardedAd()
            }
        }

        @JavascriptInterface
        fun buyCoins(productId: String) {
            runOnUiThread {
                if (!billingClient.isReady) {
                    sendBillingMessage("Google Play ainda está conectando. Tente novamente em alguns segundos.")
                    billingClient.startConnection(object : BillingClient.BillingClientStateListener() {
                        override fun onBillingSetupFinished(result: BillingResult) {
                            if (result.responseCode == BillingClient.BillingResponseCode.OK) {
                                queryCoinProducts()
                            }
                        }
                        override fun onBillingServiceDisconnected() {}
                    })
                    return@runOnUiThread
                }

                val product = products[productId]
                if (product == null) {
                    queryCoinProducts()
                    sendBillingMessage("Produto ainda não disponível. Confira se ele foi criado no Play Console.")
                    return@runOnUiThread
                }

                val offer = product.oneTimePurchaseOfferDetailsList?.firstOrNull()
                if (offer == null) {
                    sendBillingMessage("Este pacote de moedas ainda não está disponível para compra.")
                    return@runOnUiThread
                }

                val productDetailsParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                    .setProductDetails(product)
                    .setOfferToken(offer.offerToken)
                    .build()

                val flowParams = BillingFlowParams.newBuilder()
                    .setProductDetailsParamsList(listOf(productDetailsParams))
                    .build()

                billingClient.launchBillingFlow(this@MainActivity, flowParams)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        hideSystemBars()
    }

    override fun onDestroy() {
        if (::billingClient.isInitialized && billingClient.isReady) {
            billingClient.endConnection()
        }
        webView.destroy()
        super.onDestroy()
    }
}
