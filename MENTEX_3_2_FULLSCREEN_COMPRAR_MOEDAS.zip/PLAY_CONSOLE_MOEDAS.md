# MENTEX 3.2 — compras de moedas na Google Play

A versão 3.2 adiciona três produtos de compra única (consumíveis) para moedas. A cobrança é feita pela Google Play Billing.

## IDs dos produtos

Crie estes produtos no Play Console, dentro de **Monetização > Produtos no app** (o nome exato do menu pode variar):

| ID do produto | Moedas entregues | Tipo |
|---|---:|---|
| `coins_100` | 100 | Produto único/consumível |
| `coins_550` | 550 | Produto único/consumível |
| `coins_1200` | 1.200 | Produto único/consumível |

Defina os preços no Play Console. O aplicativo consulta o preço localizado da Google Play e mostra o valor ao lado do pacote quando o produto estiver disponível.

## Fluxo

1. O jogador abre **Loja > Comprar moedas**.
2. O aplicativo consulta os produtos da Google Play.
3. O botão abre a tela oficial de compra da Google Play.
4. Depois de uma compra concluída, o aplicativo entrega as moedas.
5. O produto é consumido para permitir uma nova compra do mesmo pacote.

A integração usa a **Google Play Billing Library 9.1.0**, versão atualmente suportada para novos apps e atualizações neste projeto.

## Importante para publicação

Para produção, o fluxo recomendado pelo Google é validar as compras no servidor antes de conceder a entrega. Esta versão mantém uma proteção local contra reprocessamento do mesmo token, mas isso não substitui uma validação de servidor para um jogo publicado.

O app também precisa ser enviado para um teste interno/fechado ou outra faixa do Play Console para testar compras reais de teste.
