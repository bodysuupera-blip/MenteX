# MENTEX — pronto para GitHub Actions

## Como usar
1. Extraia este ZIP no celular/computador.
2. No GitHub, envie **os arquivos e pastas de dentro desta pasta** para a raiz do repositório.
3. Não coloque apenas o ZIP dentro do repositório.
4. O workflow está em `.github/workflows/main.yml`.
5. Abra **Actions > Gerar APK MENTEX** e execute o workflow.

O workflow também consegue encontrar e extrair um ZIP do projeto se ele for colocado no repositório, mas o recomendado é enviar os arquivos do projeto diretamente.

## Estrutura principal
- `settings.gradle`
- `build.gradle`
- `app/build.gradle`
- `app/src/main/...`
- `.github/workflows/main.yml`

O projeto usa Java 17, Gradle 8.13, Android Gradle Plugin 8.13.2 e compileSdk/targetSdk 36.
