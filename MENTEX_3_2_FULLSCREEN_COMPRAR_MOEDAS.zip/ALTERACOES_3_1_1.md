# MENTEX 3.1.1 — ajustes solicitados

- Mantidas as duas imagens originais de abertura (`intro_screen.png` e `opening_screen.png`), com o botão **COMEÇAR** por toque.
- Removida a voz e o controle/ícone de voz do aplicativo.
- Removido o áudio de introdução falado.
- Cada resposta correta concede **exatamente 10 moedas**.
- Removido o bônus de moedas por combo de acertos.
- O **escudo** fica visível durante o jogo, com a quantidade disponível.
- Mantidos os efeitos sonoros e a música opcionais.
