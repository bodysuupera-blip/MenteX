MENTEX V4.6 — PROJETO-FONTE ATUALIZADO

1. Coloque TODO o conteúdo deste ZIP na raiz do repositório GitHub.
2. Mantenha .github/workflows/main.yml nesse caminho.
3. Não coloque o projeto dentro de uma pasta extra.
4. Abra Actions > Build MENTEX V4.6 Atualizado > Run workflow.
5. Aguarde o job terminar com Success.
6. Baixe o artifact MENTEX-V4.6-ATUALIZADO.

Alterações incluídas:
- ícone MENTEX com recorte circular/adaptive icon;
- tela de perguntas compacta, sem rolagem/deslizamento;
- cérebro nas perguntas sem legenda;
- projeto Android completo com settings.gradle, build.gradle e app/.
