# Cão Fujão — 500 fases

Projeto Android (Java + Gradle) com jogo HTML5 em WebView.

## Atualizações
- 500 fases.
- Todas as fases possuem obstáculos.
- A dificuldade aumenta apenas pela quantidade de obstáculos; o comportamento do cão permanece igual.
- Início grátis com 10 vidas e 0 moedas.
- Cada fase concluída concede 20 vidas.
- Cada moeda coletada vale 10 moedas.
- Preços da loja: tênis turbo 500, rede mágica 800, chapéu 400, vida extra 900, coleira 1200 e escudo 1000 moedas.
- Controles corrigidos para responder aos botões direcionais.

## Compilar
Requer JDK 17, Android SDK 35 e Gradle 8.9 (ou Android Studio recente).
Abra o projeto no Android Studio e gere o APK de debug.
