BRIGA DE BAR - DUELO DA PAQUERA
Projeto web arcade com humor cartunesco, tela inicial, controles toque (soco, defesa, dança), 3 corações, moedas, 10 rodadas e final.

Para APK via GitHub Actions, coloque o ZIP na raiz do repo e use workflow próprio.
Este projeto não integra compras reais nem anúncios. É um protótipo offline.
