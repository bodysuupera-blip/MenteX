# Nexus 350 — Labirinto de Fantasmas

Projeto Android/Capacitor independente. Jogo em tela cheia, orientação horizontal, canvas responsivo, controles touch virtuais, fases, fantasmas perseguidores, moedas, chave e portal.

## Build no GitHub Actions
1. Coloque este ZIP na raiz do repositório.
2. Workflow `Nexus350 - APK Android` pode ser disparado manualmente.
3. O workflow instala dependências, adiciona/sincroniza Android e compila APK debug.

Observação: loja e compras são demonstrativas/local. Não há Billing Google Play nem anúncios reais conectados. O convite usa compartilhamento do dispositivo quando disponível.

## Atualização de controles e objetivo (landscape)

- Campo de jogo em orientação horizontal e tela cheia.
- Porta/saída posicionada no extremo direito do campo; jogador inicia ao lado dela.
- Chave posicionada no extremo esquerdo: atravessar o cenário e voltar à porta.
- Porta fica iluminada em verde quando a chave é coletada.
- Controles divididos em duas colunas transparentes: subir/descer à esquerda; esquerda/direita à direita, cada par empilhado verticalmente.
- Fantasmas recebem separação entre si para reduzir agrupamento.
- Moedas reduzidas para 3 a 5 por fase.
