package com.arcade.labirintomortal;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Vibrator;
import java.util.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(4|1024|4096);setContentView(new LabyrinthView(this));}
  @Override public void onBackPressed(){ if(view!=null)view.back(); else super.onBackPressed(); }
  @Override protected void onDestroy(){if(view!=null)view.tones.release();super.onDestroy();}
  LabyrinthView view;
  class LabyrinthView extends View {
    final Paint p=new Paint(3); final Random rng=new Random(); final SharedPreferences prefs=getSharedPreferences("labirinto",0);
    final ToneGenerator tones=new ToneGenerator(AudioManager.STREAM_MUSIC,55);
    String screen="intro", notice="", player="EXPLORADOR"; boolean sound=true, moving=false, dead=false, victory=false;
    int coins, best, totalRuns, bonusPoints=0, level=1,lives=10,score=0,selected=0; boolean[] owned={true,false,false,false};
    final String[] skins={"NEON", "SOMBRA", "VENENO", "COSMOS"}; final int[] skinColors={0xff31eaff,0xffb6a4ff,0xff7dff72,0xffff71c8}; final int[] prices={0,180,320,500};
    final int cols=13,rows=17; int[][] map=new int[rows][cols]; float cell,ox,oy,px,py,ex,ey; int direction=1,wanted=1,tick=0; long last=0; float anim=0;
    LabyrinthView(Context c){super(c);view=this;setLayerType(View.LAYER_TYPE_SOFTWARE,null);coins=prefs.getInt("coins",0);best=prefs.getInt("best",0);totalRuns=prefs.getInt("runs",0);bonusPoints=prefs.getInt("bonusPoints",0);selected=prefs.getInt("skin",0);for(int i=0;i<4;i++)owned[i]=prefs.getBoolean("owned"+i,i==0);sound=prefs.getBoolean("sound",true);}
    void save(){prefs.edit().putInt("coins",coins).putInt("best",best).putInt("runs",totalRuns).putInt("bonusPoints",bonusPoints).putInt("skin",selected).putBoolean("sound",sound).apply();for(int i=0;i<4;i++)prefs.edit().putBoolean("owned"+i,owned[i]).apply();}
    void tone(int t){if(sound)try{tones.startTone(t,110);}catch(Exception ignored){}}
    void back(){if(screen.equals("game")){screen="menu";moving=false;}else if(!screen.equals("menu")){screen="menu";}else{screen="intro";}invalidate();}
    void start(){level=1;lives=Math.max(10,lives);score=bonusPoints;bonusPoints=0;totalRuns++;newLevel();screen="game";save();tone(ToneGenerator.TONE_PROP_ACK);}
    void newLevel(){for(int y=0;y<rows;y++)for(int x=0;x<cols;x++)map[y][x]=(x==0||y==0||x==cols-1||y==rows-1)?1:0;
      for(int y=2;y<rows-2;y+=3)for(int x=2;x<cols-2;x++)if(x%4!=0)map[y][x]=1;
      for(int x=3;x<cols-3;x+=4)for(int y=3;y<rows-3;y+=4)map[y][x]=1;
      for(int y=1;y<rows-1;y++)map[y][6]=0;for(int x=1;x<cols-1;x++)map[8][x]=0;
      for(int i=0;i<4+Math.min(level,7);i++){int x,y;do{x=1+rng.nextInt(cols-2);y=1+rng.nextInt(rows-2);}while(map[y][x]!=0||(x==1&&y==1)||(x==cols-2&&y==rows-2));map[y][x]=2;}
      for(int i=0;i<3;i++){int x,y;do{x=2+rng.nextInt(cols-4);y=2+rng.nextInt(rows-4);}while(map[y][x]!=0);map[y][x]=3;}
      px=1;py=1;ex=cols-2;ey=rows-2;direction=1;wanted=1;tick=0;dead=false;victory=false;moving=true;}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();anim+=.035f;drawBackdrop(c,w,h);
      if(screen.equals("intro"))drawIntro(c,w,h);else if(screen.equals("menu"))drawMenu(c,w,h);else if(screen.equals("shop"))drawShop(c,w,h);else if(screen.equals("profile"))drawProfile(c,w,h);else if(screen.equals("ranking"))drawRanking(c,w,h);else if(screen.equals("howto"))drawHowTo(c,w,h);else if(screen.equals("invite"))drawInvite(c,w,h);else if(screen.equals("bank"))drawBank(c,w,h);else drawGame(c,w,h);
      postInvalidateDelayed(45);
    }
    void drawBackdrop(Canvas c,float w,float h){p.setShader(new LinearGradient(0,0,w,h,0xff090d20,0xff160d2a,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
      for(int i=0;i<32;i++){float x=(float)((i*83+Math.sin(anim+i)*20)%w);float y=(float)((i*137+anim*18)%h);p.setColor(i%3==0?0x5536dfff:0x33a16cff);c.drawCircle(x,y,1.5f+(i%3),p);} }
    void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif"+(bold?"-black":""),bold?1:0));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);}
    void panel(Canvas c,float l,float t,float r,float b){p.setColor(0xdd101a31);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,24,24,p);p.setColor(0x883b6da0);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(l,t,r,b,24,24,p);p.setStyle(Paint.Style.FILL);}
    void button(Canvas c,String s,float x,float y,float ww,float hh,int color){p.setColor(color);c.drawRoundRect(x-ww/2,y-hh/2,x+ww/2,y+hh/2,hh/2,hh/2,p);p.setColor(0xff07101e);p.setTextSize(Math.min(ww*.095f,ww*1.45f/Math.max(1,s.length())));p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y+ww*.032f,p);p.setTextAlign(Paint.Align.LEFT);}
    void monster(Canvas c,float x,float y,float r,int color,float phase){
      // Personagem em silhueta, com volume e luz recortada; sem aparência de mascote arcade.
      p.setColor(0x99000000);c.drawOval(x-r*.82f,y+r*.55f,x+r*.82f,y+r*1.02f,p);
      Path cloak=new Path();cloak.moveTo(x-r*.48f,y+r*.12f);cloak.quadTo(x-r*.95f,y+r*.48f,x-r*.92f,y+r*.92f);cloak.quadTo(x,y+r*1.18f,x+r*.92f,y+r*.92f);cloak.quadTo(x+r*.95f,y+r*.48f,x+r*.48f,y+r*.12f);cloak.close();
      p.setShader(new LinearGradient(x-r,y-r,x+r,y+r,0xff27364a,0xff080d18,Shader.TileMode.CLAMP));p.setShadowLayer(r*.35f,0,r*.15f,0xff000000);c.drawPath(cloak,p);p.clearShadowLayer();p.setShader(null);
      p.setColor(0xff111a2a);p.setShadowLayer(r*.25f,0,0,color);c.drawOval(x-r*.52f,y-r*.78f,x+r*.52f,y+r*.34f,p);p.clearShadowLayer();
      p.setColor(0xff050a13);Path hood=new Path();hood.moveTo(x-r*.58f,y-r*.1f);hood.quadTo(x-r*.55f,y-r*.86f,x,y-r*.94f);hood.quadTo(x+r*.58f,y-r*.86f,x+r*.58f,y-r*.1f);hood.quadTo(x,y+r*.28f,x-r*.58f,y-r*.1f);c.drawPath(hood,p);
      p.setColor(color);p.setAlpha(230);p.setStrokeWidth(Math.max(2,r*.09f));p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x-r*.31f,y-r*.12f,x-r*.08f,y-r*.08f,p);c.drawLine(x+r*.08f,y-r*.08f,x+r*.31f,y-r*.12f,p);p.setAlpha(255);p.setStrokeCap(Paint.Cap.BUTT);
    }
    void introGlow(Canvas c,float x,float y,float radius,int color){
      p.setShader(new RadialGradient(x,y,radius,new int[]{color,0x223f8dff,0x00000000},null,Shader.TileMode.CLAMP));
      c.drawCircle(x,y,radius,p);p.setShader(null);
    }
    void drawIntroTorch(Canvas c,float x,float y,float scale){
      p.setColor(0xff292a31);c.drawRoundRect(x-scale*.10f,y,x+scale*.10f,y+scale*.48f,scale*.05f,scale*.05f,p);
      p.setColor(0xff78604b);c.drawRect(x-scale*.18f,y+scale*.06f,x+scale*.18f,y+scale*.15f,p);
      introGlow(c,x,y-scale*.03f,scale*.72f,0x66ff8a32);
      p.setShader(new LinearGradient(x,y-scale*.25f,x,y+scale*.16f,0xfffff0b0,0xffe45b18,Shader.TileMode.CLAMP));
      Path flame=new Path();flame.moveTo(x,y+scale*.13f);flame.cubicTo(x-scale*.28f,y-scale*.04f,x-scale*.08f,y-scale*.29f,x,y-scale*.39f);flame.cubicTo(x+scale*.24f,y-scale*.17f,x+scale*.25f,y+scale*.01f,x,y+scale*.13f);p.setShadowLayer(scale*.18f,0,0,0xffff7a22);c.drawPath(flame,p);p.clearShadowLayer();p.setShader(null);
    }
    void drawIntroExplorer(Canvas c,float x,float ground,float s){
      // Explorador visto de costas, com mochila, casaco, botas e lanterna.
      p.setColor(0x99000000);c.drawOval(x-s*.65f,ground-s*.08f,x+s*.65f,ground+s*.10f,p);
      p.setShader(new LinearGradient(x-s*.42f,ground-s*1.45f,x+s*.42f,ground,0xff59606a,0xff111923,Shader.TileMode.CLAMP));
      Path coat=new Path();coat.moveTo(x-s*.30f,ground-s*1.12f);coat.quadTo(x-s*.62f,ground-s*.92f,x-s*.55f,ground-s*.18f);coat.lineTo(x+s*.52f,ground-s*.18f);coat.quadTo(x+s*.62f,ground-s*.92f,x+s*.30f,ground-s*1.12f);coat.close();c.drawPath(coat,p);p.setShader(null);
      p.setColor(0xff171e28);c.drawRoundRect(x-s*.30f,ground-s*.62f,x-s*.05f,ground-s*.06f,s*.08f,s*.08f,p);c.drawRoundRect(x+s*.05f,ground-s*.62f,x+s*.30f,ground-s*.06f,s*.08f,s*.08f,p);
      p.setColor(0xff090e16);c.drawRoundRect(x-s*.33f,ground-s*.16f,x-s*.02f,ground+s*.02f,s*.06f,s*.06f,p);c.drawRoundRect(x+s*.02f,ground-s*.16f,x+s*.34f,ground+s*.02f,s*.06f,s*.06f,p);
      p.setShader(new LinearGradient(x-s*.35f,ground-s*1.25f,x+s*.35f,ground-s*.65f,0xff8b7658,0xff3d3028,Shader.TileMode.CLAMP));c.drawRoundRect(x-s*.36f,ground-s*1.25f,x+s*.36f,ground-s*.67f,s*.13f,s*.13f,p);p.setShader(null);
      p.setColor(0xffb49a70);p.setStrokeWidth(s*.055f);c.drawLine(x-s*.24f,ground-s*1.15f,x+s*.24f,ground-s*1.15f,p);
      p.setColor(0xffb98c68);c.drawCircle(x,ground-s*1.38f,s*.22f,p);
      p.setColor(0xff171b22);Path hood=new Path();hood.moveTo(x-s*.27f,ground-s*1.35f);hood.quadTo(x-s*.24f,ground-s*1.72f,x,ground-s*1.73f);hood.quadTo(x+s*.28f,ground-s*1.70f,x+s*.27f,ground-s*1.35f);hood.quadTo(x,ground-s*1.47f,x-s*.27f,ground-s*1.35f);c.drawPath(hood,p);
      p.setColor(0xffc7a47a);p.setStrokeWidth(s*.10f);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x+s*.29f,ground-s*1.02f,x+s*.53f,ground-s*.63f,p);
      p.setColor(0xff252a30);c.drawRoundRect(x+s*.43f,ground-s*.70f,x+s*.62f,ground-s*.46f,s*.04f,s*.04f,p);drawIntroTorch(c,x+s*.53f,ground-s*.72f,s*.35f);p.setStrokeCap(Paint.Cap.BUTT);
    }
    void drawIntroCreature(Canvas c,float x,float ground,float s){
      // Criatura alta e ameaçadora ao fundo, sem aparência cartunesca.
      p.setColor(0x77000000);c.drawOval(x-s*.65f,ground-s*.08f,x+s*.65f,ground+s*.05f,p);
      p.setShader(new LinearGradient(x-s*.55f,ground-s*1.7f,x+s*.55f,ground,0xff353a43,0xff080b12,Shader.TileMode.CLAMP));
      Path body=new Path();body.moveTo(x-s*.28f,ground-s*1.2f);body.quadTo(x-s*.82f,ground-s*.85f,x-s*.68f,ground-s*.12f);body.quadTo(x,ground+s*.02f,x+s*.68f,ground-s*.12f);body.quadTo(x+s*.82f,ground-s*.85f,x+s*.28f,ground-s*1.2f);body.close();c.drawPath(body,p);p.setShader(null);
      p.setColor(0xff090b10);Path head=new Path();head.moveTo(x-s*.34f,ground-s*1.26f);head.quadTo(x-s*.38f,ground-s*1.78f,x,ground-s*1.82f);head.quadTo(x+s*.38f,ground-s*1.78f,x+s*.34f,ground-s*1.26f);head.quadTo(x,ground-s*1.05f,x-s*.34f,ground-s*1.26f);c.drawPath(head,p);
      p.setColor(0xffff4b39);p.setShadowLayer(s*.16f,0,0,0xffff271e);c.drawCircle(x-s*.13f,ground-s*1.43f,s*.045f,p);c.drawCircle(x+s*.13f,ground-s*1.43f,s*.045f,p);p.clearShadowLayer();
      p.setColor(0xff090c12);p.setStrokeWidth(s*.16f);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x-s*.34f,ground-s*.93f,x-s*.58f,ground-s*.28f,p);c.drawLine(x+s*.34f,ground-s*.93f,x+s*.58f,ground-s*.28f,p);p.setStrokeCap(Paint.Cap.BUTT);
    }
    void drawIntroScene(Canvas c,float w,float h){
      float horizon=h*.455f, cx=w*.5f;
      int save=c.save();c.clipRect(0,0,w,h*.49f);
      p.setShader(new LinearGradient(0,0,0,h*.49f,0xff05080e,0xff222a35,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h*.49f,p);p.setShader(null);
      // Corredor de pedra em perspectiva e arco monumental.
      Path floor=new Path();floor.moveTo(w*.08f,h*.49f);floor.lineTo(w*.39f,h*.25f);floor.lineTo(w*.61f,h*.25f);floor.lineTo(w*.92f,h*.49f);floor.close();p.setShader(new LinearGradient(0,h*.25f,0,h*.49f,0xff343b43,0xff0a0e15,Shader.TileMode.CLAMP));c.drawPath(floor,p);p.setShader(null);
      p.setColor(0xff171e28);Path arch=new Path();arch.moveTo(w*.04f,h*.49f);arch.lineTo(w*.04f,h*.18f);arch.quadTo(w*.5f,-h*.10f,w*.96f,h*.18f);arch.lineTo(w*.96f,h*.49f);arch.lineTo(w*.84f,h*.49f);arch.lineTo(w*.84f,h*.21f);arch.quadTo(w*.5f,h*.01f,w*.16f,h*.21f);arch.lineTo(w*.16f,h*.49f);arch.close();c.drawPath(arch,p);
      p.setColor(0xff59616b);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(Math.max(3,w*.012f));c.drawArc(w*.08f,h*.02f,w*.92f,h*.55f,180,180,false,p);p.setStyle(Paint.Style.FILL);
      // Pedras laterais e juntas.
      for(int side=0;side<2;side++){float x=side==0?w*.08f:w*.92f;for(int i=0;i<5;i++){float yy=h*(.18f+i*.065f);p.setColor(i%2==0?0xff39414c:0xff252d38);c.drawRoundRect(side==0?x:x-w*.13f,yy,side==0?x+w*.13f:x,yy+h*.052f,5,5,p);p.setColor(0x557b8794);c.drawLine(side==0?x:x-w*.13f,yy,side==0?x+w*.13f:x,yy,p);}}
      // Luz distante, névoa e tochas.
      introGlow(c,cx,h*.30f,w*.34f,0x66d17a45);introGlow(c,cx,h*.40f,w*.46f,0x334b7ca0);
      drawIntroTorch(c,w*.19f,h*.30f,w*.18f);drawIntroTorch(c,w*.81f,h*.30f,w*.18f);
      for(int i=0;i<6;i++){p.setColor(0x143d5068);c.drawOval(w*(.18f+i*.105f),h*(.39f+(i%2)*.025f),w*(.42f+i*.055f),h*(.46f+(i%2)*.02f),p);}
      drawIntroCreature(c,w*.57f,h*.405f,w*.13f);
      drawIntroExplorer(c,w*.34f,h*.485f,w*.17f);
      // Vinheta cinematográfica.
      p.setShader(new LinearGradient(0,0,0,h*.49f,0xaa000000,0x00000000,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h*.49f,p);p.setShader(null);
      c.restoreToCount(save);
    }
    void drawIntro(Canvas c,float w,float h){
      float cx=w/2;
      drawIntroScene(c,w,h);
      text(c,"BEM-VINDO AO",cx,h*.555f,w*.046f,0xffb9c9df,true);
      text(c,"LABIRINTO",cx,h*.625f,w*.105f,0xfff5f1e9,true);
      text(c,"MORTAL",cx,h*.705f,w*.125f,0xffd84b42,true);
      text(c,"VOCÊ NÃO ESTÁ SOZINHO AQUI.",cx,h*.765f,w*.032f,0xffc0c8d2,true);
      button(c,"ENTRAR NO JOGO",cx,h*.865f,w*.72f,h*.075f,0xffc58a4d);
      text(c,"SOBREVIVA AO LABIRINTO",cx,h*.95f,w*.026f,0xff8996a7,true);
    }
    void drawMenu(Canvas c,float w,float h){
      text(c,"LABIRINTO MORTAL",w/2,h*.075f,w*.073f,0xfff4f7ff,true);
      text(c,"ENCONTRE O CAMINHO PARA A SAÍDA",w/2,h*.115f,w*.03f,0xffa5b9df,true);
      monster(c,w/2,h*.235f,w*.085f,skinColors[selected],anim);
      text(c,"◆ "+coins+"     ♥ "+lives+"     RECORDE "+best,w/2,h*.345f,w*.036f,0xffffd66b,true);
      button(c,"JOGAR AGORA",w/2,h*.435f,w*.78f,h*.072f,0xff42e6dc);
      button(c,"COMO JOGAR",w/2,h*.525f,w*.78f,h*.065f,0xff579bff);
      button(c,"LOJA",w*.29f,h*.615f,w*.38f,h*.065f,0xff9b83ff);
      button(c,"PONTOS E VIDAS",w*.71f,h*.615f,w*.48f,h*.065f,0xffffc45c);
      button(c,"MEU PERFIL",w*.29f,h*.705f,w*.38f,h*.065f,0xff4c9eff);
      button(c,"RANKING",w*.71f,h*.705f,w*.38f,h*.065f,0xffff658e);
      button(c,"CONVIDAR AMIGOS",w/2,h*.795f,w*.78f,h*.065f,0xff54d6a4);
      text(c,"SOM: "+(sound?"LIGADO":"DESLIGADO")+"  •  TOQUE PARA ALTERAR",w/2,h*.89f,w*.028f,0xff9eb1d1,true);
      text(c,"EXPLORE COM CUIDADO. CADA PASSO IMPORTA.",w/2,h*.96f,w*.026f,0xff7186a6,true);
    }
    void drawHowTo(Canvas c,float w,float h){
      header(c,"COMO JOGAR","Aprenda a sobreviver ao labirinto");
      panel(c,w*.08f,h*.22f,w*.92f,h*.76f);
      String[] lines={"1. USE AS SETAS PARA SE MOVER", "2. COLETE ORBES PARA GANHAR PONTOS", "3. FUJA DO CAÇADOR VERMELHO", "4. NÃO PISE NOS ESPINHOS", "5. EVITE AS ARMADILHAS DE LASER", "6. CHEGUE À SAÍDA PARA AVANÇAR", "", "DICA: GUARDE MOEDAS PARA COMPRAR", "VIDAS EXTRAS E NOVAS CRIATURAS."};
      for(int i=0;i<lines.length;i++)text(c,lines[i],w/2,h*(.31f+i*.052f),w*.032f,i==8?0xffffd66b:0xffe4edff,true);
      button(c,"VOLTAR",w/2,h*.88f,w*.48f,h*.07f,0xff607da9);
    }
    void drawInvite(Canvas c,float w,float h){
      header(c,"CHAME SEUS AMIGOS","Compartilhe o desafio");
      monster(c,w/2,h*.34f,w*.15f,skinColors[selected],anim);
      panel(c,w*.1f,h*.52f,w*.9f,h*.72f);
      text(c,"VOCÊ CONSEGUE ESCAPAR?",w/2,h*.60f,w*.045f,0xfff4f7ff,true);
      text(c,"Convide seus amigos para",w/2,h*.65f,w*.034f,0xffb7c9e5,false);
      text(c,"bater seu recorde no labirinto!",w/2,h*.69f,w*.034f,0xffb7c9e5,false);
      button(c,"COMPARTILHAR CONVITE",w/2,h*.79f,w*.78f,h*.075f,0xff54d6a4);
      button(c,"VOLTAR",w/2,h*.90f,w*.45f,h*.065f,0xff607da9);
    }
    void drawBank(Canvas c,float w,float h){
      header(c,"PONTOS E VIDAS","Use suas moedas para continuar");
      panel(c,w*.1f,h*.22f,w*.9f,h*.36f);
      text(c,"SUA CARTEIRA",w/2,h*.29f,w*.04f,0xffa9bfdf,true);
      text(c,"◆ "+coins+" MOEDAS",w/2,h*.36f,w*.075f,0xffffd66b,true);
      text(c,"♥ "+lives+" VIDAS",w/2,h*.42f,w*.06f,0xffff7298,true);
      text(c,"BÔNUS PARA A PRÓXIMA PARTIDA: "+bonusPoints,w/2,h*.535f,w*.027f,0xffb9c9e5,true);
      text(c,"★ "+score+" PONTOS NESTA PARTIDA",w/2,h*.49f,w*.032f,0xff75e8d0,true);
      button(c,"COMPRAR 1 VIDA • 30 MOEDAS",w/2,h*.65f,w*.82f,h*.075f,0xffff7196);
      button(c,"TROCAR 50 MOEDAS POR 500 PONTOS",w/2,h*.76f,w*.86f,h*.075f,0xff58d9c7);
      text(c,notice,w/2,h*.835f,w*.03f,0xffffbd72,true);
      button(c,"VOLTAR",w/2,h*.91f,w*.45f,h*.065f,0xff607da9);
    }
    void drawShop(Canvas c,float w,float h){header(c,"LOJA DE CRIATURAS","Desbloqueie aparências com suas moedas");for(int i=0;i<4;i++){float y=h*.28f+i*h*.145f;panel(c,w*.09f,y-h*.055f,w*.91f,y+h*.055f);monster(c,w*.23f,y,w*.038f,skinColors[i],anim);text(c,skins[i],w*.43f,y-5,w*.043f,0xfff4f7ff,true);text(c,owned[i]?(selected==i?"EQUIPADO":"DESBLOQUEADO"):"◆ "+prices[i],w*.69f,y+22,w*.032f,owned[i]?0xff55e9c0:0xffffd36d,true);button(c,owned[i]?(selected==i?"OK":"USAR"):"COMPRAR",w*.78f,y+2,w*.22f,h*.052f,owned[i]?0xff48d8c7:0xffffc45c);}button(c,"VOLTAR",w/2,h*.91f,w*.45f,h*.065f,0xff607da9);}
    void header(Canvas c,String a,String b){text(c,a,getWidth()/2,getHeight()*.10f,getWidth()*.075f,0xfff4f7ff,true);text(c,b,getWidth()/2,getHeight()*.15f,getWidth()*.031f,0xff9db2d6,false);}
    void drawProfile(Canvas c,float w,float h){header(c,"MEU PERFIL","Sua jornada no labirinto");monster(c,w/2,h*.32f,w*.13f,skinColors[selected],anim);text(c,player,w/2,h*.44f,w*.055f,0xfff4f7ff,true);panel(c,w*.12f,h*.51f,w*.88f,h*.78f);text(c,"MELHOR PONTUAÇÃO",w/2,h*.58f,w*.035f,0xffa8bbd8,true);text(c,""+best,w/2,h*.65f,w*.10f,0xffffd66b,true);text(c,"PARTIDAS INICIADAS: "+totalRuns,w/2,h*.72f,w*.035f,0xffdce8ff,true);text(c,"MOEDAS: "+coins,w/2,h*.76f,w*.035f,0xff63e9d0,true);button(c,"VOLTAR",w/2,h*.89f,w*.45f,h*.07f,0xff607da9);}
    void drawRanking(Canvas c,float w,float h){header(c,"RANKING LOCAL","Seus melhores resultados neste aparelho");panel(c,w*.1f,h*.24f,w*.9f,h*.72f);text(c,"#",w*.22f,h*.32f,w*.04f,0xff8fa9d0,true);text(c,"JOGADOR",w*.47f,h*.32f,w*.04f,0xff8fa9d0,true);text(c,"PONTOS",w*.77f,h*.32f,w*.04f,0xff8fa9d0,true);String[] labels={"1  •  VOCÊ","2  •  MELHOR MARCA","3  •  PRÓXIMO DESAFIO"};int[] values={best,best,Math.max(0,best-100)};for(int i=0;i<3;i++){float y=h*(.42f+i*.105f);text(c,labels[i],w*.42f,y,w*.032f,i==0?0xffffd66b:0xffdce7fa,true);text(c,""+values[i],w*.78f,y,w*.035f,0xff65e9d2,true);}text(c,"Ranking offline: sem jogadores fictícios.",w/2,h*.70f,w*.026f,0xff8198bc,false);button(c,"VOLTAR",w/2,h*.86f,w*.45f,h*.07f,0xff607da9);}
    void drawStoneWall(Canvas c,float l,float t,float s){
      // Sombra projetada e duas faces dão volume sem alterar a colisão do labirinto.
      p.setColor(0x99000000);c.drawRoundRect(l+s*.08f,t+s*.16f,l+s*.98f,t+s*.98f,s*.10f,s*.10f,p);
      Path side=new Path();side.moveTo(l+s*.10f,t+s*.10f);side.lineTo(l+s*.90f,t+s*.10f);side.lineTo(l+s*.90f,t+s*.90f);side.lineTo(l+s*.10f,t+s*.90f);side.close();
      p.setShader(new LinearGradient(l,t,l+s,t+s,0xff53627a,0xff26354b,Shader.TileMode.CLAMP));c.drawPath(side,p);p.setShader(null);
      Path top=new Path();top.moveTo(l+s*.08f,t+s*.08f);top.lineTo(l+s*.88f,t+s*.08f);top.lineTo(l+s*.98f,t+s*.22f);top.lineTo(l+s*.18f,t+s*.22f);top.close();
      p.setShader(new LinearGradient(l,t,l,t+s*.22f,0xff91a0b4,0xff48576d,Shader.TileMode.CLAMP));c.drawPath(top,p);p.setShader(null);
      p.setColor(0xff34445b);c.drawRect(l+s*.18f,t+s*.22f,l+s*.98f,t+s*.90f,p);
      p.setColor(0x557f91a8);p.setStrokeWidth(1);c.drawLine(l+s*.18f,t+s*.24f,l+s*.96f,t+s*.24f,p);
      p.setColor(0x33404e62);c.drawLine(l+s*.55f,t+s*.28f,l+s*.55f,t+s*.82f,p);
    }
    void drawGame(Canvas c,float w,float h){text(c,"FASE "+level+"     ♥ "+lives+"     PONTOS "+score+"     MOEDAS "+coins,w/2,h*.065f,w*.039f,0xffe9f2ff,true);cell=Math.min(w*.88f/cols,h*.59f/rows);ox=(w-cols*cell)/2;oy=h*.13f;panel(c,ox-7,oy-7,ox+cols*cell+7,oy+rows*cell+7);
      for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){float l=ox+x*cell,t=oy+y*cell;
        // Piso de pedra escura com pequenas variações de luz.
        p.setColor(((x+y)&1)==0?0xff172338:0xff1b293d);c.drawRect(l,t,l+cell,t+cell,p);
        p.setColor(0x223c5573);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawRect(l+1,t+1,l+cell-1,t+cell-1,p);p.setStyle(Paint.Style.FILL);
        if(map[y][x]==1){drawStoneWall(c,l,t,cell);}
        else if(map[y][x]==2){p.setColor((tick/7)%2==0?0xffff526c:0xff8d263f);p.setShadowLayer(cell*.22f,0,0,0x99ff294f);Path tr=new Path();tr.moveTo(l+cell/2,t+cell*.13f);tr.lineTo(l+cell*.88f,t+cell*.86f);tr.lineTo(l+cell*.12f,t+cell*.86f);tr.close();c.drawPath(tr,p);p.clearShadowLayer();p.setColor(0xffffb3bd);p.setStrokeWidth(1.5f);c.drawLine(l+cell*.5f,t+cell*.3f,l+cell*.5f,t+cell*.7f,p);}
        else if(map[y][x]==3){p.setColor((tick/10)%2==0?0xffffc15a:0xff694332);p.setShadowLayer(cell*.18f,0,0,0x99ff9d32);p.setStrokeWidth(Math.max(2,cell*.10f));c.drawLine(l+cell*.16f,t+cell/2,l+cell*.84f,t+cell/2,p);p.clearShadowLayer();p.setColor(0xffffe0a1);p.setStrokeWidth(1);c.drawLine(l+cell*.2f,t+cell*.43f,l+cell*.8f,t+cell*.43f,p);}
        else if(map[y][x]!=4){p.setColor(0x665d7891);c.drawCircle(l+cell/2,t+cell/2,cell*.035f,p);}
      }
      p.setColor(0xff51f2c3);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(ox+(cols-1.5f)*cell,oy+(rows-1.5f)*cell,cell*.3f,p);p.setStyle(Paint.Style.FILL);monster(c,ox+(ex+.5f)*cell,oy+(ey+.5f)*cell,cell*.34f,0xffff477c,anim);monster(c,ox+(px+.5f)*cell,oy+(py+.5f)*cell,cell*.36f,skinColors[selected],anim);
      float cy=h*.84f,r=w*.067f;control(c,w*.5f,cy-r*1.1f,"▲");control(c,w*.5f,cy+r*1.1f,"▼");control(c,w*.5f-r*1.35f,cy,"◀");control(c,w*.5f+r*1.35f,cy,"▶");text(c,"TOQUE NAS SETAS • FUJA DO CAÇADOR",w/2,h*.97f,w*.027f,0xff8ca3c9,true);
      if(dead||victory){panel(c,w*.09f,h*.34f,w*.91f,h*.64f);text(c,victory?"VOCÊ SOBREVIVEU":"A ESCURIDÃO VENCEU",w/2,h*.43f,w*.062f,victory?0xff55efc5:0xffff6489,true);text(c,victory?"Prepare-se. O próximo labirinto é pior.":"Suas vidas acabaram.",w/2,h*.49f,w*.034f,0xffd4def1,false);button(c,victory?"PRÓXIMA FASE":"TENTAR NOVAMENTE",w/2,h*.56f,w*.68f,h*.07f,0xff48e2d8);}
    }
    void control(Canvas c,float x,float y,String s){p.setColor(0xff1d3158);c.drawCircle(x,y,getWidth()*.052f,p);p.setColor(0xff62eaff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(x,y,getWidth()*.052f,p);p.setStyle(Paint.Style.FILL);text(c,s,x,y+getWidth()*.018f,getWidth()*.052f,0xffeafaff,true);}
    boolean free(int x,int y){return x>0&&y>0&&x<cols-1&&y<rows-1&&map[y][x]!=1;}
    void hit(){lives--;tone(ToneGenerator.TONE_PROP_NACK);try{((Vibrator)getContext().getSystemService(VIBRATOR_SERVICE)).vibrate(100);}catch(Exception ignored){}px=1;py=1;if(lives<=0){dead=true;moving=false;coins+=score/100;save();}}
    void step(){if(!screen.equals("game")||!moving||dead||victory)return;tick++;int nx=(int)px+new int[]{0,1,0,-1}[wanted],ny=(int)py+new int[]{-1,0,1,0}[wanted];if(free(nx,ny))direction=wanted;nx=(int)px+new int[]{0,1,0,-1}[direction];ny=(int)py+new int[]{-1,0,1,0}[direction];if(free(nx,ny)){px=nx;py=ny;}
      int tx=(int)px,ty=(int)py;if(map[ty][tx]==2||(map[ty][tx]==3&&(tick/10)%2==0)){hit();}else if(map[ty][tx]==0){score+=10;if(rng.nextInt(4)==0){coins++;tone(ToneGenerator.TONE_PROP_BEEP);save();}map[ty][tx]=4;}
      if(tick%2==0){int ax=(int)ex,ay=(int)ey;ArrayList<int[]> opts=new ArrayList<>();int[][] ds={{0,-1},{1,0},{0,1},{-1,0}};for(int[] d:ds)if(free(ax+d[0],ay+d[1]))opts.add(new int[]{ax+d[0],ay+d[1]});if(!opts.isEmpty()){opts.sort((a,b)->Integer.compare(Math.abs(a[0]-(int)px)+Math.abs(a[1]-(int)py),Math.abs(b[0]-(int)px)+Math.abs(b[1]-(int)py)));ex=opts.get(0)[0];ey=opts.get(0)[1];}}
      if(Math.abs(ex-px)<.1f&&Math.abs(ey-py)<.1f)hit();if((int)px==cols-2&&(int)py==rows-2){victory=true;moving=false;score+=level*100;coins+=level*15;level++;if(score>best)best=score;save();tone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD);}}
    @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;
      if(screen.equals("intro")){screen="menu";tone(ToneGenerator.TONE_PROP_ACK);}
      else if(screen.equals("menu")){if(y>h*.39f&&y<h*.48f)start();else if(y>h*.49f&&y<h*.56f)screen="howto";else if(y>h*.58f&&y<h*.65f){if(x<w*.5f)screen="shop";else screen="bank";}else if(y>h*.67f&&y<h*.74f){if(x<w*.5f)screen="profile";else screen="ranking";}else if(y>h*.76f&&y<h*.83f)screen="invite";else if(y>h*.85f&&y<h*.93f){sound=!sound;save();tone(ToneGenerator.TONE_PROP_BEEP);}}
      else if(screen.equals("howto")){if(y>h*.80f)screen="menu";}
      else if(screen.equals("invite")){if(y>h*.74f&&y<h*.85f){try{android.content.Intent send=new android.content.Intent(android.content.Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(android.content.Intent.EXTRA_SUBJECT,"Desafio: Labirinto Mortal");send.putExtra(android.content.Intent.EXTRA_TEXT,"Vamos jogar LABIRINTO MORTAL! Entre no labirinto, fuja das armadilhas e tente superar meu recorde de "+best+" pontos.");getContext().startActivity(android.content.Intent.createChooser(send,"Convidar amigos"));}catch(Exception ignored){}}else if(y>h*.86f)screen="menu";}
      else if(screen.equals("bank")){if(y>h*.60f&&y<h*.70f){if(coins>=30){coins-=30;lives=Math.min(10,lives+1);notice="VIDA ADICIONADA!";tone(ToneGenerator.TONE_PROP_ACK);save();}else{notice="MOEDAS INSUFICIENTES";tone(ToneGenerator.TONE_PROP_NACK);}}else if(y>h*.71f&&y<h*.81f){if(coins>=50){coins-=50;bonusPoints+=500;notice="500 PONTOS RESERVADOS PARA A PRÓXIMA PARTIDA!";tone(ToneGenerator.TONE_PROP_ACK);save();}else{notice="MOEDAS INSUFICIENTES";tone(ToneGenerator.TONE_PROP_NACK);}}else if(y>h*.85f){screen="menu";notice="";}}
      else if(screen.equals("shop")){if(y>h*.86f){screen="menu";}else{int i=Math.round((y-h*.28f)/(h*.145f));if(i>=0&&i<4){if(owned[i]){selected=i;save();tone(ToneGenerator.TONE_PROP_ACK);}else if(coins>=prices[i]){coins-=prices[i];owned[i]=true;selected=i;save();tone(ToneGenerator.TONE_PROP_ACK);}else{notice="MOEDAS INSUFICIENTES";tone(ToneGenerator.TONE_PROP_NACK);}}}}
      else if(screen.equals("profile")||screen.equals("ranking")){if(y>h*.78f)screen="menu";}
      else if(screen.equals("game")){if(dead||victory){if(y>h*.50f&&y<h*.63f){if(dead){level=1;lives=10;score=0;}newLevel();}else if(y<h*.34f){screen="menu";}}else{float cy=h*.84f,r=w*.067f;if(y<cy-r*.55f&&x>w*.35f&&x<w*.65f)wanted=0;else if(y>cy+r*.55f&&x>w*.35f&&x<w*.65f)wanted=2;else if(x<w*.5f)wanted=3;else wanted=1;}}
      invalidate();return true;}
    @Override public void computeScroll(){super.computeScroll();long now=System.currentTimeMillis();if(now-last>210){last=now;step();invalidate();}}
  }
}
