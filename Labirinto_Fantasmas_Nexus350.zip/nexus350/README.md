# Labirinto de Fantasmas — Nexus 350
Projeto independente de jogo HTML5 + Capacitor Android.

## Jogabilidade implementada
- Arena aberta com controles touch e teclado
- 350 fases progressivas, mundos por faixas de fases
- Fantasmas com 5 estilos de comportamento
- Chave e portal de saída
- Moedas coletáveis e loja de upgrades
- Escudo, turbo e pulso
- Chefes a cada 25 fases (marcador de chefe)
- Salvamento local de fase, moedas, upgrades e vidas

## APK via GitHub Actions
Enviar o conteúdo desta pasta para a raiz de um repositório independente. Abrir Actions > `Nexus 350 - Gerar APK Android` > Run workflow. O APK debug será publicado em Artifacts.
