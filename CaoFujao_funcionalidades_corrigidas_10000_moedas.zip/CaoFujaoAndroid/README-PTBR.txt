CÃO FUJÃO — PROJETO ANDROID PARA GERAR APK

COMO GERAR:
1. Instale o Android Studio.
2. Extraia esta pasta do ZIP.
3. No Android Studio, escolha Open e selecione a pasta CaoFujaoAndroid.
4. Aguarde a sincronização do Gradle.
5. Abra Build > Build Bundle(s) / APK(s) > Build APK(s).
6. O APK de teste será gerado em app/build/outputs/apk/debug/.

O QUE ESTÁ INCLUÍDO:
- Projeto Android Studio/Gradle.
- Aplicativo Android com WebView.
- assets/index.html e assets/intro.png do jogo atualizado.
- Configuração para gerar APK de depuração.

IMPORTANTE:
- Este é um novo projeto Android wrapper para o jogo web. Não é o projeto-fonte original que gerou o APK enviado.
- O botão de propaganda premiada do jogo depende de integração real com um SDK de anúncios recompensados no Android. Esta base ainda não inclui SDK, IDs de anúncios ou callback seguro; portanto o anúncio não será exibido/validado até essa integração.
- A compra de moedas pela Google Play também depende da integração do Google Play Billing. Não está configurada neste projeto.
- Para publicar na Play Store, configure assinatura, identificador de pacote definitivo, política de privacidade e os SDKs necessários.

GERAR O APK PELO GITHUB (SEM INSTALAR ANDROID STUDIO):
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. No repositório, abra a aba Actions.
3. Selecione "Gerar APK Android" e clique em "Run workflow" (ou aguarde o build automático após enviar para main/master).
4. Quando terminar com sucesso, abra a execução e baixe o artefato "cao-fujao-apk-debug".
5. Dentro do ZIP baixado estará app-debug.apk para instalar no Android.

O workflow compila um APK de depuração. Para publicação na Play Store, ainda é necessário configurar assinatura de release.
