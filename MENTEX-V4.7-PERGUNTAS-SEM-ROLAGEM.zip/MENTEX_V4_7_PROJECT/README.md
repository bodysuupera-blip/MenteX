# MENTEX V4.7 — Perguntas sem rolagem

Atualização focada na tela de perguntas: a pergunta, o cérebro e as opções são encaixados automaticamente na área disponível, sem rolagem vertical/horizontal.

## Alterações
- Tela de desafio em tela cheia.
- Rolagem desativada durante as perguntas.
- Ajuste automático de escala quando o conteúdo é maior que a altura disponível.
- Compatível com telas menores e mudança de orientação.
- Mantidos os recursos e imagens da versão V4.6.
- Versão interna atualizada para 4.7.

Compile com Java 17 e Android Gradle Plugin 8.6.1.
