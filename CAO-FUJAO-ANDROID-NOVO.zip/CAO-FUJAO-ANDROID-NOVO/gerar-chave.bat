@echo off
echo Gerando uma nova chave digital para o Cao Fujão...
keytool -genkeypair -v -keystore cao-fujao-release.jks -alias cao-fujao -keyalg RSA -keysize 2048 -validity 10000
echo.
echo Guarde o arquivo cao-fujao-release.jks e as senhas em local seguro.
pause
