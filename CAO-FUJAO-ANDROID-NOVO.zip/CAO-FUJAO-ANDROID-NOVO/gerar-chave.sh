#!/usr/bin/env bash
set -e
keytool -genkeypair -v -keystore cao-fujao-release.jks -alias cao-fujao -keyalg RSA -keysize 2048 -validity 10000
echo "Guarde cao-fujao-release.jks e as senhas em local seguro."
