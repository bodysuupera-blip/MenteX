# Cão Fujão — atualização 1.1

Projeto Android (Java + WebView/HTML5).

## O que foi atualizado
- Três dificuldades selecionáveis: Fácil, Normal e Hard.
- Ajuste da quantidade de movimentos, obstáculos e comportamento do cachorro em cada dificuldade.
- Correção dos botões de direção: os controles agora recebem os cliques corretamente.
- Loja funcional: tênis turbo (dois passos por turno por 5 turnos), rede mágica (imobiliza o cão por 3 turnos), chapéu (dobra pontos na próxima vitória), tentativa extra, coleira (dobra moedas na próxima vitória) e escudo (protege de uma captura).
- Itens comprados ficam no inventário até serem usados; a tentativa extra é aplicada imediatamente.
- Pacotes de moedas integrados à Google Play Billing Library 9.1.0.

## Produtos que precisam ser criados na Play Console
Crie três produtos de compra única (INAPP), com estes IDs exatos:
- `coins_500` — concede 500 moedas
- `coins_1200` — concede 1.200 moedas
- `coins_3000` — concede 3.000 moedas

Defina os preços na Play Console. O aplicativo consulta e exibe o preço localizado retornado pela Google Play. Não altere os IDs sem alterar também `MainActivity.java` e `index.html`.

## Importante sobre compras reais
O fluxo cliente usa `consumeAsync()` para compras consumíveis e só acrescenta moedas após o retorno de consumo bem-sucedido. Para lançamento comercial com proteção antifraude e recuperação confiável entre aparelhos/reinstalações, é recomendado implementar verificação de tokens de compra em um backend seguro. Não publique os produtos antes de configurar e testar a ficha do app, os produtos e as contas de teste na Play Console.

## Como compilar
- Android Studio recente
- JDK 17
- Android SDK 35
- Abra a pasta do projeto no Android Studio e aguarde a sincronização do Gradle.
- Gere em **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

APK de teste: `app/build/outputs/apk/debug/app-debug.apk`.

Este ZIP contém o código-fonte. A compra pela Google Play só funciona depois que o app estiver configurado na Play Console e instalado por um canal de teste/produção da Play Store; não funciona como compra real ao abrir o APK diretamente.
