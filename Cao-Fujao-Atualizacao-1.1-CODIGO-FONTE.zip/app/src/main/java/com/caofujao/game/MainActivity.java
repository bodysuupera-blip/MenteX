package com.caofujao.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.util.Log;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryProductDetailsResult;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONObject;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView web;
    private BillingClient billingClient;
    private final Map<String, ProductDetails> productDetailsMap = new HashMap<>();
    private final Map<String, Integer> coinAmounts = new HashMap<>();
    private String pendingProductId = null;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,27,55));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,27,55));

        coinAmounts.put("coins_500", 500);
        coinAmounts.put("coins_1200", 1200);
        coinAmounts.put("coins_3000", 3000);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void share(String message) {
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(send, "Convidar amigos"));
                });
            }
            @JavascriptInterface public void buyCoins(String productId) {
                runOnUiThread(() -> startCoinPurchase(productId));
            }
        }, "AndroidShare");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void buyCoins(String productId) {
                runOnUiThread(() -> startCoinPurchase(productId));
            }
        }, "AndroidBilling");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        setupBilling();
    }

    private void setupBilling() {
        billingClient = BillingClient.newBuilder(this)
            .setListener((billingResult, purchases) -> handlePurchases(billingResult, purchases))
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build();
        connectBilling();
    }

    private void connectBilling() {
        if (billingClient == null || billingClient.isReady()) return;
        billingClient.startConnection(new BillingClient.BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryCoinProducts();
                    queryExistingPurchases();
                    if (pendingProductId != null) {
                        String id = pendingProductId;
                        pendingProductId = null;
                        launchCoinPurchase(id);
                    }
                } else {
                    notifyJs("Não foi possível conectar à Google Play: " + result.getDebugMessage());
                }
            }
            @Override public void onBillingServiceDisconnected() {
                Log.w("CaoFujaoBilling", "Conexão com Google Play interrompida.");
            }
        });
    }

    private void queryCoinProducts() {
        List<QueryProductDetailsParams.Product> products = Arrays.asList(
            QueryProductDetailsParams.Product.newBuilder().setProductId("coins_500").setProductType(BillingClient.ProductType.INAPP).build(),
            QueryProductDetailsParams.Product.newBuilder().setProductId("coins_1200").setProductType(BillingClient.ProductType.INAPP).build(),
            QueryProductDetailsParams.Product.newBuilder().setProductId("coins_3000").setProductType(BillingClient.ProductType.INAPP).build()
        );
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(products).build();
        billingClient.queryProductDetailsAsync(params, (result, queryResult) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                notifyJs("Não foi possível carregar os pacotes de moedas.");
                return;
            }
            productDetailsMap.clear();
            JSONObject prices = new JSONObject();
            for (ProductDetails details : queryResult.getProductDetailsList()) {
                productDetailsMap.put(details.getProductId(), details);
                try {
                    JSONObject item = new JSONObject();
                    if (details.getOneTimePurchaseOfferDetails() != null) {
                        item.put("price", details.getOneTimePurchaseOfferDetails().getFormattedPrice());
                    }
                    prices.put(details.getProductId(), item);
                } catch (Exception ignored) {}
            }
            runJs("window.onBillingProducts(" + JSONObject.quote(prices.toString()) + ")");
        });
    }

    private void startCoinPurchase(String productId) {
        if (!coinAmounts.containsKey(productId)) {
            notifyJs("Pacote de moedas inválido.");
            return;
        }
        if (billingClient == null || !billingClient.isReady()) {
            pendingProductId = productId;
            connectBilling();
            notifyJs("Conectando à Google Play...");
            return;
        }
        launchCoinPurchase(productId);
    }

    private void launchCoinPurchase(String productId) {
        ProductDetails details = productDetailsMap.get(productId);
        if (details == null) {
            queryCoinProducts();
            notifyJs("Pacote ainda não disponível. Confira se ele foi cadastrado na Play Console.");
            return;
        }
        BillingFlowParams.ProductDetailsParams productParams =
            BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details).build();
        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(Collections.singletonList(productParams))
            .build();
        BillingResult result = billingClient.launchBillingFlow(this, flowParams);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            notifyJs("A Google Play não iniciou a compra: " + result.getDebugMessage());
        }
    }

    private void handlePurchases(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK || purchases == null) {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
                notifyJs("Compra não concluída: " + result.getDebugMessage());
            }
            return;
        }
        for (Purchase purchase : purchases) processPurchase(purchase);
    }

    private void queryExistingPurchases() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.INAPP).build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                for (Purchase purchase : purchases) processPurchase(purchase);
            }
        });
    }

    private void processPurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        String productId = null;
        for (String id : purchase.getProducts()) {
            if (coinAmounts.containsKey(id)) { productId = id; break; }
        }
        if (productId == null) return;
        final int amount = coinAmounts.get(productId);
        ConsumeParams params = ConsumeParams.newBuilder()
            .setPurchaseToken(purchase.getPurchaseToken()).build();
        billingClient.consumeAsync(params, (result, token) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                runJs("window.onCoinsPurchased(" + amount + ")");
            } else {
                notifyJs("Não foi possível confirmar o pacote. Entre em contato com o suporte antes de tentar comprar novamente.");
                Log.e("CaoFujaoBilling", "Falha ao consumir compra: " + result.getDebugMessage());
            }
        });
    }

    private void runJs(String javascript) {
        runOnUiThread(() -> {
            if (web != null) web.evaluateJavascript(javascript, null);
        });
    }

    private void notifyJs(String message) {
        runJs("window.onBillingMessage(" + JSONObject.quote(message) + ")");
    }

    @Override protected void onDestroy() {
        if (billingClient != null) billingClient.endConnection();
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
