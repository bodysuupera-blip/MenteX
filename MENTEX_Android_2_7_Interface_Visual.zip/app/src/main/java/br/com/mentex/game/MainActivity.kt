package br.com.mentex.game

import android.app.Activity
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.speech.tts.TextToSpeech
import java.util.Locale
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardItem
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.LoadAdError

class MainActivity : Activity() {
    private lateinit var webView: WebView
    private var rewardedAd: RewardedAd? = null
    private var interstitialAd: InterstitialAd? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var pageLoaded = false
    private var introSpoken = false

    companion object {
        // IDs de produção fornecidos pelo proprietário da conta AdMob MENTX.
        private const val ADMOB_APP_ID = "ca-app-pub-3631665156241326~8323112024"
        private const val REWARDED_AD_UNIT_ID = "ca-app-pub-3631665156241326/4036769692"
        private const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3631665156241326/2935053979"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        webView = WebView(this)
        webView.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                pageLoaded = true
                speakIntroWhenReady()
            }
        }
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.addJavascriptInterface(GameBridge(), "AndroidAds")
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                tts?.language = Locale("pt", "BR")
                // Tenta selecionar uma voz masculina em português (Google TTS costuma usar nomes como #male_1-local).
                val maleVoice = tts?.voices?.firstOrNull { voice ->
                    val n = voice.name.lowercase()
                    voice.locale.language == "pt" && voice.locale.country == "BR" &&
                        (n.contains("#male") || n.contains("_male") || n.contains("-male")) &&
                        !n.contains("female")
                }
                if (maleVoice != null) tts?.voice = maleVoice
                tts?.setSpeechRate(1.02f)
                tts?.setPitch(0.78f)
                if (pageLoaded) speakIntroWhenReady()
            }
        }
        setContentView(webView)
        webView.loadUrl("file:///android_asset/index.html")

        MobileAds.initialize(this) {
            loadRewardedAd()
            loadInterstitialAd()
        }
    }

    private fun loadRewardedAd() {
        RewardedAd.load(
            this,
            REWARDED_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    rewardedAd = null
                }
            }
        )
    }


    private fun loadInterstitialAd() {
        InterstitialAd.load(
            this,
            INTERSTITIAL_AD_UNIT_ID,
            AdRequest.Builder().build(),
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }

    private fun speakIntroWhenReady() {
        if (!ttsReady || introSpoken) return
        introSpoken = true
        webView.postDelayed({
            speakBrain("E aí! Eu sou o cérebro do MENTEX! Preparado pra colocar essa cachola pra funcionar? Então bora!")
        }, 700)
    }

    private fun speakBrain(text: String) {
        if (!ttsReady) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mentex_voice")
    }

    private inner class GameBridge {
        @JavascriptInterface
        fun speak(text: String) {
            runOnUiThread { speakBrain(text) }
        }

        @JavascriptInterface
        fun stopSpeech() {
            runOnUiThread { tts?.stop() }
        }

        @JavascriptInterface
        fun showInterstitialAd() {
            runOnUiThread {
                val ad = interstitialAd
                if (ad != null) {
                    ad.show(this@MainActivity)
                    interstitialAd = null
                    loadInterstitialAd()
                } else {
                    loadInterstitialAd()
                }
            }
        }

        @JavascriptInterface
        fun showRewardedAd() {
            runOnUiThread {
                val ad = rewardedAd
                if (ad == null) {
                    webView.evaluateJavascript(
                        "alert('O anúncio ainda está carregando. Tente novamente em alguns segundos.');",
                        null
                    )
                    loadRewardedAd()
                    return@runOnUiThread
                }

                ad.show(this@MainActivity) { _: RewardItem ->
                    webView.evaluateJavascript(
                        "window.rewardFromAd && window.rewardFromAd();",
                        null
                    )
                }
                rewardedAd = null
                loadRewardedAd()
            }
        }
    }
}
