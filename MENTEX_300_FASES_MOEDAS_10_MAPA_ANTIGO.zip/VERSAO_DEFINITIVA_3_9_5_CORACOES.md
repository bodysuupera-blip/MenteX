# MENTEX 3.9.2

Versão normal do jogo: 5 corações, moedas, prêmios e pontuação.
Entrada em duas telas: Bem-vindo e Como Funciona. O segundo botão é JOGAR e entra diretamente na Fase 1. Música de entrada mantida. Sem voz e sem ícone de voz.
