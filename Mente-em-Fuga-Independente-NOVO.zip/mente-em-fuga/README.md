# Mente em Fuga — Labirinto Vivo

Projeto Android independente. Não depende dos projetos MENTEX ou Cão Fujão.

## Gerar APK
1. Envie a pasta `mente-em-fuga` para a raiz do repositório.
2. Envie `.github/workflows/mente-em-fuga.yml` para o repositório.
3. Execute o workflow em GitHub Actions.
4. Baixe o APK Debug em Artifacts.

O Android nativo é criado no CI por `npx cap add android`.
