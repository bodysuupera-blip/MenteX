MENTEX WEB - TESTE 999 CORAÇÕES

Correções:
- 999 ❤️ fixos no modo web de teste.
- Errar ou acabar o tempo não reduz as vidas.
- Voz IA do Mente xis na abertura.
- 200 fases mantidas.
- Android MENTEX normal não é alterado por este pacote.

Observação: navegadores podem bloquear reprodução automática antes de qualquer toque. A voz também é iniciada no botão COMEÇAR, garantindo reprodução após a interação do usuário.
