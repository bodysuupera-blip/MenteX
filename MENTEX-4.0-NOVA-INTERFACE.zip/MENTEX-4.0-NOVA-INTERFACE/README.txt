MENTEX 4.0 - NOVA INTERFACE

Esta pasta contém a nova interface HTML baseada na versão MENTEX V3.3 existente.
O conteúdo e a lógica dos 200 desafios foram preservados, com uma nova tela inicial,
navegação inferior, cards de progresso, perfil, mapa, loja e ranking.

Arquivo principal:
assets/index.html

Os arquivos de imagem e áudio originais também foram preservados.

Observação: este pacote é a interface extraída/reorganizada do APK existente; não é,
por si só, um projeto Android Gradle completo.
