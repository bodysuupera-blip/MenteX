# Labirinto Fantasma

Base do jogo preservada com ajustes solicitados: menu ilustrado, controles maiores, recompensa de 10 moedas por coleta e fase, preços de loja virtuais elevados, efeitos sonoros sintetizados e botão de pacote Google Play de 10.000 moedas por R$ 19,90 (a integração real de cobrança ainda não está implementada).

Workflow Android incluído. Envie o ZIP à raiz do repositório e execute Actions.
