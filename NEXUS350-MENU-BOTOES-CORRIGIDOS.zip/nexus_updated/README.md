# Nexus 350 – Atualização de sons e loja

Atualização dos arquivos web extraídos do APK de referência enviado.

- Efeitos de áudio sintetizados (início, moedas, chave, captura, vitória, botões).
- Música ambiente simples gerada por Web Audio, com botão de áudio.
- Loja sem botão de compra simulada; CTA para Google Play e botão VOLTAR.

**Importante:** esta entrega contém os assets web e workflow de compilação, não um APK recompilado. O APK enviado continha apenas o binário, não o projeto Android/Gradle original. O botão de compra ainda não faz cobrança: o Google Play Billing e o produto de moedas precisam ser configurados na Play Console e integrados ao projeto Android.
