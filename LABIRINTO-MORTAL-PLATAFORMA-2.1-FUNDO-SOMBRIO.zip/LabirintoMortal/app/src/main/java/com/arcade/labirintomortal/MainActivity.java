package com.arcade.labirintomortal;

import android.app.Activity;
import android.os.Bundle;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.media.MediaPlayer;
import android.view.MotionEvent;
import android.view.View;
import java.util.*;

public class MainActivity extends Activity {
    private MediaPlayer ambience;
    private boolean soundEnabled = true;
    private GameView game;
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(5, 8, 18));
        getWindow().setNavigationBarColor(Color.rgb(5, 8, 18));
        prefs = getSharedPreferences("labirinto_mortal", MODE_PRIVATE);
        soundEnabled = prefs.getBoolean("sound", true);
        ambience = MediaPlayer.create(this, R.raw.horror_ambience);
        if (ambience != null) {
            ambience.setLooping(true);
            ambience.setVolume(soundEnabled ? 0.42f : 0f, soundEnabled ? 0.42f : 0f);
            if (soundEnabled) ambience.start();
        }
        game = new GameView(this);
        setContentView(game);
    }
    void toggleSound() {
        soundEnabled = !soundEnabled;
        prefs.edit().putBoolean("sound", soundEnabled).apply();
        if (ambience != null) {
            if (soundEnabled && !ambience.isPlaying()) ambience.start();
            if (!soundEnabled && ambience.isPlaying()) ambience.pause();
        }
        if (game != null) game.invalidate();
    }
    @Override protected void onPause() { super.onPause(); if (ambience != null && ambience.isPlaying()) ambience.pause(); }
    @Override protected void onResume() { super.onResume(); if (soundEnabled && ambience != null && !ambience.isPlaying()) ambience.start(); }
    @Override protected void onDestroy() { if (ambience != null) { ambience.release(); ambience = null; } super.onDestroy(); }

    class GameView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final Random random = new Random();
        final int cols = 13, rows = 17;
        final int[][] map = new int[rows][cols];
        final int MENU=0, PLAY=1, SHOP=2, MISSIONS=3, PROFILE=4, SETTINGS=5;
        int screen = MENU;
        float cell, ox, oy, px, py, enemyX, enemyY;
        int level=1, lives=10, score=0, coins=0, dir=1, desired=1, tick=0;
        int games=0, wins=0, bestScore=0, shields=0;
        boolean started=false, gameOver=false, won=false, shield=false;
        long last=0;
        final int[][] dirs={{0,-1},{1,0},{0,1},{-1,0}};
        GameView(Context c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            SharedPreferences s = prefs;
            lives = Math.max(1, Math.min(10, s.getInt("lives", 10)));
            coins = s.getInt("coins", 0); score = s.getInt("score", 0);
            level = Math.max(1, s.getInt("level", 1)); games=s.getInt("games",0);
            wins=s.getInt("wins",0); bestScore=s.getInt("best",0); shields=s.getInt("shields",0);
            newLevel(); started=false; screen=MENU;
        }
        void save() {
            prefs.edit().putInt("lives",lives).putInt("coins",coins).putInt("score",score)
                .putInt("level",level).putInt("games",games).putInt("wins",wins)
                .putInt("best",bestScore).putInt("shields",shields).apply();
        }
        void newLevel() {
            for(int y=0;y<rows;y++) for(int x=0;x<cols;x++) map[y][x]=(x==0||y==0||x==cols-1||y==rows-1)?1:0;
            for(int y=2;y<rows-2;y+=3) for(int x=2;x<cols-2;x++) if(x%4!=0) map[y][x]=1;
            for(int x=3;x<cols-3;x+=4) for(int y=3;y<rows-3;y+=4) map[y][x]=1;
            for(int y=1;y<rows-1;y++) map[y][6]=0;
            for(int x=1;x<cols-1;x++) map[8][x]=0;
            for(int i=0;i<3+Math.min(level,4);i++){int x,y;int tries=0;do{x=1+random.nextInt(cols-2);y=1+random.nextInt(rows-2);tries++;}while((map[y][x]!=0||(x==1&&y==1)||(x==cols-2&&y==rows-2))&&tries<300);if(tries<300)map[y][x]=2;}
            for(int i=0;i<2;i++){int x,y;int tries=0;do{x=2+random.nextInt(cols-4);y=2+random.nextInt(rows-4);tries++;}while(map[y][x]!=0&&tries<300);if(tries<300)map[y][x]=3;}
            px=1;py=1;enemyX=cols-2;enemyY=rows-2;dir=1;desired=1;tick=0;started=true;gameOver=false;won=false;shield=shields>0;invalidate();
        }
        // Ilustração sombria compartilhada por TODAS as telas do jogo.
        void bg(Canvas c) {
            float w=getWidth(),h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,0xff11121d,0xff030407,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);p.setShader(null);

            // Lua enevoada no alto, deslocada para não competir com os menus.
            float mx=w*.82f,my=h*.17f,mr=Math.min(w,h)*.105f;
            p.setShader(new RadialGradient(mx,my,mr*1.35f,new int[]{0x55d6d9e8,0x2299a9c4,0x00000000},null,Shader.TileMode.CLAMP));
            c.drawCircle(mx,my,mr*1.35f,p);p.setShader(null);
            p.setColor(0x557f879a);c.drawCircle(mx,my,mr,p);
            p.setColor(0x44353b4d);c.drawCircle(mx-mr*.28f,my-mr*.18f,mr*.16f,p);c.drawCircle(mx+mr*.24f,my+mr*.25f,mr*.12f,p);

            // Névoa baixa em camadas suaves.
            for(int i=0;i<7;i++){
                float yy=h*(.60f+i*.055f);
                p.setShader(new LinearGradient(0,yy,w,yy+ h*.035f,0x001a2534,0x332d3545,0x001a2534,Shader.TileMode.CLAMP));
                c.drawRect(0,yy,w,yy+h*.045f,p);
            }
            p.setShader(null);

            // Silhuetas de castelo e muralhas no horizonte.
            p.setColor(0xff080a12);
            float base=h*.78f;
            c.drawRect(w*.66f,base-h*.19f,w*.94f,base,p);
            c.drawRect(w*.70f,base-h*.28f,w*.76f,base,p);
            c.drawRect(w*.84f,base-h*.34f,w*.90f,base,p);
            Path tower=new Path();tower.moveTo(w*.685f,base-h*.28f);tower.lineTo(w*.73f,base-h*.39f);tower.lineTo(w*.775f,base-h*.28f);tower.close();c.drawPath(tower,p);
            tower.reset();tower.moveTo(w*.825f,base-h*.34f);tower.lineTo(w*.87f,base-h*.46f);tower.lineTo(w*.915f,base-h*.34f);tower.close();c.drawPath(tower,p);
            p.setColor(0xff9b2531);c.drawCircle(w*.73f,base-h*.20f,Math.max(2,w*.006f),p);c.drawCircle(w*.87f,base-h*.25f,Math.max(2,w*.006f),p);

            // Árvores retorcidas nas laterais, deixando a região central livre.
            drawDeadTree(c,w*.035f,h*.78f,h*.53f,1f);
            drawDeadTree(c,w*.97f,h*.82f,h*.58f,-1f);
            drawDeadTree(c,w*.18f,h*.88f,h*.25f,1f);
            drawDeadTree(c,w*.91f,h*.91f,h*.29f,-1f);

            // Pedras, ossos e pequenas caveiras decorativas nos cantos inferiores.
            drawSkull(c,w*.09f,h*.91f,Math.min(w,h)*.035f);
            drawSkull(c,w*.94f,h*.94f,Math.min(w,h)*.027f);
            p.setColor(0x553d414d);
            for(int i=0;i<18;i++){
                float x=((i*73)%97)/97f*w, y=h*(.78f+((i*19)%18)/100f);
                c.drawOval(x,y,x+w*.025f,y+h*.012f,p);
            }
            // Vinheta escura para manter textos e botões legíveis em todas as telas.
            p.setShader(new RadialGradient(w*.5f,h*.48f,Math.max(w,h)*.72f,new int[]{0x00000000,0x66000000,0xcc000000},null,Shader.TileMode.CLAMP));
            c.drawRect(0,0,w,h,p);p.setShader(null);
        }
        void drawDeadTree(Canvas c,float x,float y,float height,float side){
            p.setColor(0xff080a10);p.setStrokeCap(Paint.Cap.ROUND);p.setStrokeJoin(Paint.Join.ROUND);
            p.setStrokeWidth(Math.max(3,getWidth()*.012f));
            Path trunk=new Path();trunk.moveTo(x,y);trunk.cubicTo(x-side*getWidth()*.035f,y-height*.30f,x+side*getWidth()*.025f,y-height*.62f,x,y-height);
            c.drawPath(trunk,p);
            p.setStrokeWidth(Math.max(2,getWidth()*.006f));
            Path branch=new Path();branch.moveTo(x,y-height*.55f);branch.quadTo(x+side*getWidth()*.08f,y-height*.70f,x+side*getWidth()*.10f,y-height*.84f);c.drawPath(branch,p);
            branch.reset();branch.moveTo(x+side*getWidth()*.045f,y-height*.70f);branch.quadTo(x+side*getWidth()*.10f,y-height*.76f,x+side*getWidth()*.13f,y-height*.75f);c.drawPath(branch,p);
            branch.reset();branch.moveTo(x,y-height*.36f);branch.quadTo(x-side*getWidth()*.07f,y-height*.48f,x-side*getWidth()*.10f,y-height*.58f);c.drawPath(branch,p);
            branch.reset();branch.moveTo(x-side*getWidth()*.045f,y-height*.48f);branch.quadTo(x-side*getWidth()*.11f,y-height*.54f,x-side*getWidth()*.14f,y-height*.52f);c.drawPath(branch,p);
        }
        void drawSkull(Canvas c,float x,float y,float r){
            p.setColor(0xff343642);c.drawOval(x-r,y-r*.72f,x+r,y+r*.48f,p);
            c.drawRoundRect(x-r*.58f,y+r*.12f,x+r*.58f,y+r*.82f,r*.18f,r*.18f,p);
            p.setColor(0xff090a10);c.drawCircle(x-r*.34f,y-r*.03f,r*.22f,p);c.drawCircle(x+r*.34f,y-r*.03f,r*.22f,p);
            Path nose=new Path();nose.moveTo(x,y+r*.15f);nose.lineTo(x-r*.12f,y+r*.36f);nose.lineTo(x+r*.12f,y+r*.36f);nose.close();c.drawPath(nose,p);
            p.setColor(0xff777987);p.setStrokeWidth(1.5f);for(int i=-1;i<=1;i++)c.drawLine(x+i*r*.25f,y+r*.47f,x+i*r*.25f,y+r*.72f,p);
        }
        void text(Canvas c,String s,float x,float y,float size,int color,boolean bold,Paint.Align align) {
            p.setShader(null);p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create(bold?"sans-serif-black":"sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));p.setTextAlign(align);p.clearShadowLayer();c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);
        }
        void panel(Canvas c,float l,float t,float r,float b) {
            p.setColor(0xee0c1427);c.drawRoundRect(l,t,r,b,24,24,p);
            p.setColor(0xff304b78);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawRoundRect(l,t,r,b,24,24,p);p.setStyle(Paint.Style.FILL);
        }
        void button(Canvas c,String label,float l,float t,float r,float b,boolean primary) {
            p.setColor(primary?0xff00c9b2:0xff1b2a49);c.drawRoundRect(l,t,r,b,16,16,p);
            p.setColor(primary?0xff70ffe5:0xff49638d);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(l,t,r,b,16,16,p);p.setStyle(Paint.Style.FILL);
            text(c,label,(l+r)/2,(t+b)/2+getWidth()*.014f,getWidth()*.038f,primary?0xff061522:0xffedf5ff,true,Paint.Align.CENTER);
        }
        void header(Canvas c,String title,String subtitle) {
            float w=getWidth(),h=getHeight();
            text(c,"LABIRINTO MORTAL",w*.07f,h*.075f,w*.065f,0xfff2f6ff,true,Paint.Align.LEFT);
            text(c,title,w*.07f,h*.145f,w*.052f,0xff62f3dc,true,Paint.Align.LEFT);
            text(c,subtitle,w*.07f,h*.185f,w*.029f,0xffa7bad8,false,Paint.Align.LEFT);
            text(c,soundEnabled?"♫ ON":"♫ OFF",w*.92f,h*.075f,w*.03f,0xffa7bad8,true,Paint.Align.RIGHT);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);bg(c);
            if(screen==MENU) drawMenu(c);
            else if(screen==PLAY) drawGame(c);
            else if(screen==SHOP) drawShop(c);
            else if(screen==MISSIONS) drawMissions(c);
            else if(screen==PROFILE) drawProfile(c);
            else if(screen==SETTINGS) drawSettings(c);
        }
        void drawMenu(Canvas c) {
            float w=getWidth(),h=getHeight();
            text(c,"LABIRINTO",w/2,h*.20f,w*.105f,0xfff4f7ff,true,Paint.Align.CENTER);
            text(c,"MORTAL",w/2,h*.285f,w*.105f,0xffff526f,true,Paint.Align.CENTER);
            text(c,"NÃO OLHE PARA TRÁS.",w/2,h*.335f,w*.033f,0xff9bb2d6,true,Paint.Align.CENTER);
            // stylized portal
            p.setColor(0x5532e6d0);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(w*.012f);c.drawOval(w*.34f,h*.37f,w*.66f,h*.57f,p);p.setStrokeWidth(w*.004f);c.drawOval(w*.38f,h*.39f,w*.62f,h*.55f,p);p.setStyle(Paint.Style.FILL);
            text(c,"♥ "+lives+" VIDAS      ◆ "+coins+" MOEDAS",w/2,h*.615f,w*.034f,0xffdce8ff,true,Paint.Align.CENTER);
            button(c,"ENTRAR NO LABIRINTO",w*.12f,h*.66f,w*.88f,h*.735f,true);
            button(c,"LOJA",w*.12f,h*.755f,w*.48f,h*.82f,false);
            button(c,"MISSÕES",w*.52f,h*.755f,w*.88f,h*.82f,false);
            button(c,"MEU PERFIL",w*.12f,h*.84f,w*.48f,h*.905f,false);
            button(c,"CONFIGURAÇÕES",w*.52f,h*.84f,w*.88f,h*.905f,false);
            text(c,"FASE "+level+"  •  RECORDE "+bestScore,w/2,h*.95f,w*.027f,0xff8096b9,false,Paint.Align.CENTER);
        }
        void drawGame(Canvas c) {
            float w=getWidth(),h=getHeight();
            text(c,"‹ MENU",w*.07f,h*.07f,w*.034f,0xff9fb8dc,true,Paint.Align.LEFT);
            text(c,"FASE "+level+"     ♥ "+lives+"     ◆ "+coins,w*.5f,h*.07f,w*.034f,0xffe5efff,true,Paint.Align.CENTER);
            cell=Math.min((w*.88f)/cols,(h*.59f)/rows);ox=(w-cols*cell)/2;oy=h*.13f;
            p.setColor(0xff101a31);c.drawRoundRect(ox-7,oy-7,ox+cols*cell+7,oy+rows*cell+7,18,18,p);
            for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){
                float l=ox+x*cell,t=oy+y*cell;
                if(map[y][x]==1){p.setColor(0xff263d78);c.drawRoundRect(l+2,t+2,l+cell-2,t+cell-2,7,7,p);p.setColor(0xff456bd0);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(l+4,t+4,l+cell-4,t+cell-4,5,5,p);p.setStyle(Paint.Style.FILL);}
                else if(map[y][x]==2){p.setColor((tick/8)%2==0?0xffff4d6d:0xffa52c52);Path tr=new Path();tr.moveTo(l+cell*.5f,t+cell*.18f);tr.lineTo(l+cell*.83f,t+cell*.82f);tr.lineTo(l+cell*.17f,t+cell*.82f);tr.close();c.drawPath(tr,p);}
                else if(map[y][x]==3){p.setColor((tick/12)%2==0?0xffffb52e:0xff713d32);p.setStrokeWidth(4);c.drawLine(l+cell*.2f,t+cell*.5f,l+cell*.8f,t+cell*.5f,p);}
                else {p.setColor(0xff263653);c.drawCircle(l+cell/2,t+cell/2,cell*.055f,p);}
            }
            p.setColor(0xff35e6b5);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);c.drawRoundRect(ox+(cols-2)*cell+5,oy+(rows-2)*cell+5,ox+(cols-1)*cell-5,oy+(rows-1)*cell-5,9,9,p);p.setStyle(Paint.Style.FILL);
            drawMonster(c,ox+(enemyX+.5f)*cell,oy+(enemyY+.5f)*cell,cell*.36f,true);
            drawMonster(c,ox+(px+.5f)*cell,oy+(py+.5f)*cell,cell*.38f,false);
            float cy=h*.84f,r=w*.07f;drawControl(c,w*.5f,cy-r*1.1f,"▲");drawControl(c,w*.5f,cy+r*1.1f,"▼");drawControl(c,w*.5f-r*1.35f,cy,"◀");drawControl(c,w*.5f+r*1.35f,cy,"▶");
            text(c,shield?"ESCUDO ATIVO":"TOQUE NAS SETAS PARA MOVER",w*.5f,h*.97f,w*.027f,shield?0xff5dffe0:0xff8ca4c9,false,Paint.Align.CENTER);
            if(!started||gameOver||won) {
                panel(c,w*.06f,h*.29f,w*.94f,h*.69f);
                text(c,won?"FASE CONCLUÍDA!":gameOver?"FIM DE JOGO":"PREPARE-SE",w/2,h*.39f,w*.066f,0xfff4f7ff,true,Paint.Align.CENTER);
                text(c,won?"Você escapou. O próximo labirinto espera.":"Fuja da criatura e evite as armadilhas.",w/2,h*.47f,w*.032f,0xffa9bddc,false,Paint.Align.CENTER);
                button(c,won?"PRÓXIMA FASE":gameOver?"TENTAR NOVAMENTE":"COMEÇAR",w*.2f,h*.56f,w*.8f,h*.64f,true);
            }
        }
        void drawControl(Canvas c,float x,float y,String s){p.setColor(0xff1d3158);c.drawCircle(x,y,getWidth()*.052f,p);p.setColor(0xff65e8ff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(x,y,getWidth()*.052f,p);p.setStyle(Paint.Style.FILL);text(c,s,x,y+getWidth()*.019f,getWidth()*.055f,0xffeaffff,true,Paint.Align.CENTER);}
        void drawMonster(Canvas c,float x,float y,float r,boolean enemy){p.setColor(enemy?0xffff4d78:0xff35e6ff);p.setShadowLayer(16,0,0,enemy?0xffff245e:0xff00cfff);c.drawCircle(x,y,r,p);p.clearShadowLayer();p.setColor(0xff071326);RectF m=new RectF(x-r*.55f,y-r*.05f,x+r*.55f,y+r*.65f);c.drawArc(m,0,180,true,p);p.setColor(Color.WHITE);c.drawCircle(x-r*.32f,y-r*.22f,r*.19f,p);c.drawCircle(x+r*.32f,y-r*.22f,r*.19f,p);p.setColor(0xff10172a);c.drawCircle(x-r*.28f,y-r*.2f,r*.09f,p);c.drawCircle(x+r*.36f,y-r*.2f,r*.09f,p);}
        void drawShop(Canvas c) {
            float w=getWidth(),h=getHeight();header(c,"LOJA SOMBRIA","Use suas moedas para ganhar vantagem");
            panel(c,w*.07f,h*.23f,w*.93f,h*.79f);
            text(c,"◆ SALDO: "+coins+" MOEDAS",w*.5f,h*.29f,w*.04f,0xffffd36a,true,Paint.Align.CENTER);
            text(c,"+5 VIDAS",w*.18f,h*.39f,w*.038f,0xfff3f6ff,true,Paint.Align.LEFT);text(c,"20 moedas",w*.18f,h*.425f,w*.029f,0xff9fb5d6,false,Paint.Align.LEFT);button(c,"COMPRAR",w*.62f,h*.36f,w*.86f,h*.44f,true);
            text(c,"ESCUDO EXTRA",w*.18f,h*.53f,w*.038f,0xfff3f6ff,true,Paint.Align.LEFT);text(c,"30 moedas",w*.18f,h*.565f,w*.029f,0xff9fb5d6,false,Paint.Align.LEFT);button(c,"COMPRAR",w*.62f,h*.50f,w*.86f,h*.58f,true);
            text(c,"+50 MOEDAS",w*.18f,h*.67f,w*.038f,0xfff3f6ff,true,Paint.Align.LEFT);text(c,"Recompensa por completar 3 fases",w*.18f,h*.705f,w*.026f,0xff9fb5d6,false,Paint.Align.LEFT);
            button(c,"VOLTAR AO MENU",w*.18f,h*.83f,w*.82f,h*.91f,false);
        }
        void drawMissions(Canvas c) {
            float w=getWidth(),h=getHeight();header(c,"MISSÕES","Desafios para sobreviver e ganhar moedas");panel(c,w*.07f,h*.23f,w*.93f,h*.79f);
            mission(c,"SOBREVIVENTE","Jogue uma partida",games>=1,w,h*.34f);
            mission(c,"CAÇADOR DE SAÍDAS","Conclua uma fase",wins>=1,w,h*.49f);
            mission(c,"COLECIONADOR","Acumule 100 pontos",bestScore>=100,w,h*.64f);
            button(c,"VOLTAR AO MENU",w*.18f,h*.83f,w*.82f,h*.91f,false);
        }
        void mission(Canvas c,String title,String desc,boolean done,float w,float y){text(c,(done?"✓  ":"○  ")+title,w*.15f,y,w*.037f,done?0xff55edc8:0xfff2f6ff,true,Paint.Align.LEFT);text(c,desc,w*.22f,y+w*.04f,w*.028f,0xff9fb5d6,false,Paint.Align.LEFT);text(c,done?"CONCLUÍDA":"EM ANDAMENTO",w*.84f,y+w*.04f,w*.023f,done?0xff55edc8:0xff8096b9,true,Paint.Align.RIGHT);}
        void drawProfile(Canvas c) {
            float w=getWidth(),h=getHeight();header(c,"MEU PERFIL","Seu histórico de sobrevivência");panel(c,w*.07f,h*.23f,w*.93f,h*.79f);
            text(c,"JOGADOR",w*.5f,h*.32f,w*.052f,0xfff2f6ff,true,Paint.Align.CENTER);
            text(c,"FASE ATUAL",w*.27f,h*.43f,w*.027f,0xff9fb5d6,true,Paint.Align.CENTER);text(c,""+level,w*.27f,h*.49f,w*.06f,0xff5ff2d9,true,Paint.Align.CENTER);
            text(c,"PONTUAÇÃO",w*.72f,h*.43f,w*.027f,0xff9fb5d6,true,Paint.Align.CENTER);text(c,""+score,w*.72f,h*.49f,w*.06f,0xff5ff2d9,true,Paint.Align.CENTER);
            text(c,"PARTIDAS",w*.27f,h*.59f,w*.027f,0xff9fb5d6,true,Paint.Align.CENTER);text(c,""+games,w*.27f,h*.65f,w*.052f,0xfff2f6ff,true,Paint.Align.CENTER);
            text(c,"FASES VENCIDAS",w*.72f,h*.59f,w*.027f,0xff9fb5d6,true,Paint.Align.CENTER);text(c,""+wins,w*.72f,h*.65f,w*.052f,0xfff2f6ff,true,Paint.Align.CENTER);
            text(c,"RECORDE: "+bestScore+"     MOEDAS: "+coins,w*.5f,h*.73f,w*.031f,0xffffd36a,true,Paint.Align.CENTER);
            button(c,"VOLTAR AO MENU",w*.18f,h*.83f,w*.82f,h*.91f,false);
        }
        void drawSettings(Canvas c) {
            float w=getWidth(),h=getHeight();header(c,"CONFIGURAÇÕES","Ajuste sua experiência");panel(c,w*.07f,h*.25f,w*.93f,h*.72f);
            text(c,"SOM DE SUSPENSE",w*.17f,h*.39f,w*.04f,0xfff2f6ff,true,Paint.Align.LEFT);button(c,soundEnabled?"LIGADO":"DESLIGADO",w*.58f,h*.34f,w*.85f,h*.43f,true);
            text(c,"VIDAS",w*.17f,h*.53f,w*.04f,0xfff2f6ff,true,Paint.Align.LEFT);text(c,""+lives+" / 10",w*.82f,h*.53f,w*.04f,0xff5ff2d9,true,Paint.Align.RIGHT);
            text(c,"ESCUDOS",w*.17f,h*.62f,w*.04f,0xfff2f6ff,true,Paint.Align.LEFT);text(c,""+shields,w*.82f,h*.62f,w*.04f,0xff5ff2d9,true,Paint.Align.RIGHT);
            button(c,"VOLTAR AO MENU",w*.18f,h*.79f,w*.82f,h*.87f,false);
        }
        boolean free(int x,int y){return x>0&&y>0&&x<cols-1&&y<rows-1&&map[y][x]!=1;}
        void step() {
            if(screen!=PLAY||!started||gameOver||won)return;tick++;
            int nx=(int)px+dirs[desired][0],ny=(int)py+dirs[desired][1];if(free(nx,ny))dir=desired;
            nx=(int)px+dirs[dir][0];ny=(int)py+dirs[dir][1];if(free(nx,ny)){px=nx;py=ny;}
            int tx=(int)px,ty=(int)py;
            if(map[ty][tx]==2||(map[ty][tx]==3&&(tick/12)%2==0)){
                if(shield)shield=false;else{lives=Math.max(0,lives-1);px=1;py=1;if(lives<=0){gameOver=true;bestScore=Math.max(bestScore,score);}}
            } else if(map[ty][tx]==0){score+=10;if(random.nextInt(5)==0)coins++;}
            if(tick%2==0){int ex=(int)enemyX,ey=(int)enemyY;ArrayList<int[]> opts=new ArrayList<>();for(int d=0;d<4;d++){int ax=ex+dirs[d][0],ay=ey+dirs[d][1];if(free(ax,ay))opts.add(new int[]{ax,ay});}if(!opts.isEmpty()){opts.sort((a,b)->Integer.compare(Math.abs(a[0]-(int)px)+Math.abs(a[1]-(int)py),Math.abs(b[0]-(int)px)+Math.abs(b[1]-(int)py)));int[] a=opts.get(0);enemyX=a[0];enemyY=a[1];}}
            if(Math.abs(enemyX-px)<.1f&&Math.abs(enemyY-py)<.1f){if(shield)shield=false;else{lives=Math.max(0,lives-1);px=1;py=1;if(lives<=0){gameOver=true;bestScore=Math.max(bestScore,score);}}}
            if((int)px==cols-2&&(int)py==rows-2){won=true;wins++;level++;coins+=10;bestScore=Math.max(bestScore,score);}
            save();
        }
        void startGame(){if(lives<=0)lives=10;games++;screen=PLAY;newLevel();save();}
        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;
            float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();
            if(x>w*.78f&&y<h*.12f){toggleSound();return true;}
            if(screen==MENU){
                if(y>h*.65f&&y<h*.745f){startGame();}
                else if(y>h*.75f&&y<h*.83f){screen=(x<w*.5f)?SHOP:MISSIONS;}
                else if(y>h*.835f&&y<h*.915f){screen=(x<w*.5f)?PROFILE:SETTINGS;}
            } else if(screen==SHOP){
                if(y>h*.35f&&y<h*.455f&&x>w*.58f){if(coins>=20){coins-=20;lives=Math.min(10,lives+5);save();}}
                else if(y>h*.49f&&y<h*.60f&&x>w*.58f){if(coins>=30){coins-=30;shields++;save();}}
                else if(y>h*.81f){screen=MENU;}
            } else if(screen==MISSIONS){if(y>h*.81f)screen=MENU;}
            else if(screen==PROFILE){if(y>h*.81f)screen=MENU;}
            else if(screen==SETTINGS){if(y>h*.32f&&y<h*.46f)toggleSound();else if(y>h*.76f)screen=MENU;}
            else if(screen==PLAY){
                if(y<h*.11f&&x<w*.25f){screen=MENU;save();}
                else if(!started||gameOver||won){if(y>h*.53f&&y<h*.67f){if(gameOver){lives=10;score=0;level=1;}if(won&&shields>0){shields--;}newLevel();started=true;save();}}
                else {float cy=h*.84f,r=w*.07f;if(y<cy-r*.55f&&x>w*.35f&&x<w*.65f)desired=0;else if(y>cy+r*.55f&&x>w*.35f&&x<w*.65f)desired=2;else if(x<w*.5f)desired=3;else desired=1;}
            }
            invalidate();return true;
        }
        @Override public void computeScroll(){super.computeScroll();if(screen==PLAY&&started&&!gameOver&&!won){long now=System.currentTimeMillis();if(now-last>230){last=now;step();invalidate();}postInvalidateDelayed(70);}}
    }
}
