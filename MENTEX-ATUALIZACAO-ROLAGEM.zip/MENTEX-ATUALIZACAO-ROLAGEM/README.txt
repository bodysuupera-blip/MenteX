MENTEX - Atualização de rolagem

Inclui index.html atualizado para habilitar rolagem vertical na tela inicial (após sair), no perfil do jogador e na tela de resultado, mantendo a tela de perguntas sem rolagem.

IMPORTANTE: este ZIP contém o arquivo HTML atualizado, NÃO o projeto Android completo. Para gerar APK, substitua o HTML correspondente dentro do projeto original na pasta assets/www/ ou na pasta equivalente usada pelo seu WebView, e compile usando o workflow do projeto. O HTML sozinho não é suficiente para compilar um APK.
