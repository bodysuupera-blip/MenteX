package com.mentex.caofujao;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private BillingClient billingClient;
    private final Map<String, ProductDetails> products = new HashMap<>();
    private static final List<String> PRODUCT_IDS = Arrays.asList(
            "coins_500", "coins_1500", "coins_4000", "coins_10000"
    );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new ShareBridge(), "AndroidShare");
        webView.addJavascriptInterface(new BillingBridge(), "AndroidBilling");
        webView.loadUrl("file:///android_asset/index.html");

        startBilling();
    }

    private void js(String script) {
        runOnUiThread(() -> {
            if (webView != null) webView.evaluateJavascript(script, null);
        });
    }

    private void billingStatus(boolean ready, String message) {
        js("if(window.onBillingReady)window.onBillingReady(" + ready + "," +
                JSONObject.quote(message) + ");");
    }

    private void startBilling() {
        billingClient = BillingClient.newBuilder(this)
                .setListener(this::onPurchasesUpdated)
                .enablePendingPurchases(
                        com.android.billingclient.api.PendingPurchasesParams.newBuilder()
                                .enableOneTimeProducts()
                                .build()
                )
                .build();

        billingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    billingStatus(true, "Google Play pronta");
                    queryProducts();
                } else {
                    billingStatus(false, "Compras indisponíveis: " + result.getDebugMessage());
                }
            }

            @Override
            public void onBillingServiceDisconnected() {
                billingStatus(false, "Conexão com a Google Play perdida. Tente novamente.");
            }
        });
    }

    private void queryProducts() {
        List<QueryProductDetailsParams.Product> list = new ArrayList<>();
        for (String id : PRODUCT_IDS) {
            list.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id)
                    .setProductType(BillingClient.ProductType.INAPP)
                    .build());
        }

        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(list)
                .build();

        billingClient.queryProductDetailsAsync(params, (result, response) -> {
            if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                billingStatus(false, "Não foi possível carregar os produtos da Google Play.");
                return;
            }

            products.clear();
            JSONObject prices = new JSONObject();
            for (ProductDetails details : response.getProductDetailsList()) {
                products.put(details.getProductId(), details);
                ProductDetails.OneTimePurchaseOfferDetails offer =
                        details.getOneTimePurchaseOfferDetails();
                if (offer != null) {
                    try {
                        prices.put(details.getProductId(), offer.getFormattedPrice());
                    } catch (Exception ignored) { }
                }
            }
            js("if(window.onBillingProducts)window.onBillingProducts(" +
                    JSONObject.quote(prices.toString()) + ");");
        });
    }

    private void launchPurchase(String productId) {
        if (billingClient == null ||
                !billingClient.isReady()) {
            billingStatus(false, "A Google Play ainda não está conectada. Tente novamente.");
            return;
        }

        ProductDetails details = products.get(productId);
        if (details == null) {
            queryProducts();
            billingStatus(false, "Produto não encontrado. Confira se ele foi cadastrado na Google Play.");
            return;
        }

        BillingFlowParams.ProductDetailsParams productParams =
                BillingFlowParams.ProductDetailsParams.newBuilder()
                        .setProductDetails(details)
                        .build();

        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(productParams))
                .build();

        BillingResult result = billingClient.launchBillingFlow(this, flowParams);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            billingStatus(false, "Não foi possível iniciar a compra: " + result.getDebugMessage());
        }
    }

    private void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) {
                if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                    grantAndConsume(purchase);
                } else if (purchase.getPurchaseState() == Purchase.PurchaseState.PENDING) {
                    billingStatus(false, "Compra pendente de aprovação da Google Play.");
                }
            }
        } else if (result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            billingStatus(true, "Compra cancelada.");
        } else {
            billingStatus(false, "Falha na compra: " + result.getDebugMessage());
        }
    }

    private void grantAndConsume(Purchase purchase) {
        if (purchase.getProducts().isEmpty()) return;
        String productId = purchase.getProducts().get(0);
        String token = purchase.getPurchaseToken();

        // Os pacotes de moedas são consumíveis. O jogo registra o token para evitar
        // creditar duas vezes a mesma transação.
        js("if(window.onGooglePurchase)window.onGooglePurchase(" +
                JSONObject.quote(productId) + "," + JSONObject.quote(token) + ");");

        ConsumeParams params = ConsumeParams.newBuilder()
                .setPurchaseToken(token)
                .build();

        billingClient.consumeAsync(params, (result, consumedToken) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                billingStatus(true, "Compra concluída com sucesso!");
            } else {
                billingStatus(false, "Compra recebida; não foi possível finalizar o consumo: " +
                        result.getDebugMessage());
            }
        });
    }

    private class ShareBridge {
        @JavascriptInterface
        public void share(String message) {
            runOnUiThread(() -> {
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("text/plain");
                send.putExtra(Intent.EXTRA_TEXT, message);
                startActivity(Intent.createChooser(send, "Convidar amigos"));
            });
        }
    }

    private class BillingBridge {
        @JavascriptInterface
        public void buyProduct(String productId) {
            runOnUiThread(() -> launchPurchase(productId));
        }
    }

    @Override
    protected void onDestroy() {
        if (billingClient != null) billingClient.endConnection();
        if (webView != null) {
            webView.removeJavascriptInterface("AndroidShare");
            webView.removeJavascriptInterface("AndroidBilling");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
