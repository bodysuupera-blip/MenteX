# MENTEX Android 1.0.0

Projeto Android com o protótipo de 50 fases.

## O que já está incluído
- 50 fases jogáveis
- Progressão e desbloqueio
- Vidas, moedas e pontuação
- Bônus diário
- Salvamento local via localStorage
- Interface mobile responsiva
- Ícone inicial do aplicativo
- Estrutura Android pronta para abrir no Android Studio

## Como gerar o APK
1. Instale o Android Studio.
2. Abra esta pasta como projeto.
3. Aguarde a sincronização do Gradle.
4. Use **Build > Build APK(s)**.
5. O APK será gerado na pasta `app/build/outputs/apk/`.

## Próxima etapa de produção
Adicionar arte final, efeitos sonoros profissionais, AdMob real, compras no aplicativo, política de privacidade, testes em vários aparelhos e preparação para Google Play.

Este projeto é um protótipo; não há garantia de receita.

## Anúncio premiado de teste
A versão 0.6 inclui um anúncio premiado de TESTE. Ao assistir, o jogador recebe +1 vida e +10 moedas.
O ID usado é o ID oficial de teste do Google. Antes de publicar, substitua-o pelo seu bloco de anúncios da AdMob.

## Monetização
A integração real exige uma conta AdMob e IDs próprios. Nunca use anúncios de produção durante o desenvolvimento.

## Loja MENTEX
A versão 0.7 adiciona uma loja interna usando moedas virtuais:
- +1 vida: 40 moedas
- +3 vidas: 100 moedas
- Dica: 30 moedas
- Escudo de erro: 80 moedas

As moedas são virtuais e não podem ser sacadas. A loja não exige depósito de dinheiro.

## Visual 0.8
- Interface mobile refinada
- Mapa com 5 mundos
- Indicador de sequência (streak)
- Bônus de moedas ao completar 5 fases consecutivas
- Feedback visual de fases concluídas

## MENTEX 1.0
- Perfil do jogador
- Nível baseado em pontuação
- 8 conquistas
- Recompensa de 25 moedas por conquista
- Melhor sequência registrada
- Ranking local demonstrativo
- 50 fases, loja e anúncio premiado mantidos

### Antes da Google Play
Ainda é necessário testar em aparelhos reais, configurar seus IDs de produção da AdMob, criar política de privacidade, revisar permissões, preparar screenshots/descrição e fazer testes de segurança e desempenho.

## Versão 1.1 — Preparação para publicação
Inclui materiais de Política de Privacidade, ficha da Google Play, roteiro de Segurança dos dados e checklist de release.

**Importante:** os IDs reais de produção do AdMob e os dados do desenvolvedor ainda precisam ser preenchidos. O projeto continua sendo código-fonte; é necessário gerar o AAB/APK em Android Studio.


## MENTEX 1.2 — AdMob configurado

Esta versão foi preparada com os IDs de produção fornecidos pelo proprietário da conta AdMob MENTX:
- App ID: `ca-app-pub-3631665156241326~8323112024`
- Rewarded: `ca-app-pub-3631665156241326/4036769692`
- Interstitial: `ca-app-pub-3631665156241326/2935053979`

O intersticial é solicitado em transições após cada 5ª fase concluída. Durante desenvolvimento/testes, não clique em anúncios de produção; prefira anúncios de teste até a versão de lançamento.
