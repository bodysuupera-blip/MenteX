MENTEX Web — 200 fases

Para publicar no GitHub Pages, envie o conteúdo desta pasta para o repositório.
O arquivo principal é index.html.

Arquivos incluídos:
- index.html
- opening_screen.png
- brain_mascot.png
- mentex_intro.mp3
- mentex_icon.png

Esta versão abre em navegadores de Android, iPhone e computador.
