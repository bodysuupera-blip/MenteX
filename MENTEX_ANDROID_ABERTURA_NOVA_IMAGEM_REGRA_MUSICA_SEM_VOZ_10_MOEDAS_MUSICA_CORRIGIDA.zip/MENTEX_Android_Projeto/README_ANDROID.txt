MENTEX — Projeto Android com compras de moedas

Produtos de compra no Google Play Console:
- coins_100  -> 100 moedas
- coins_500  -> 500 moedas
- coins_1200 -> 1.200 moedas

Tipo: produto no aplicativo consumível (INAPP).

O jogo chama AndroidAds.purchaseCoins() pelo WebView. O Android abre o Google Play Billing, verifica a compra e consome o produto. Somente após o consumo confirmado o JavaScript recebe onAndroidCoinPurchaseSuccess() e credita as moedas.

ANTES DE PUBLICAR:
1. Crie os três produtos no Google Play Console com os mesmos IDs.
2. Defina os preços.
3. Gere/associe a chave de assinatura conforme o processo da Play Console.
4. Teste com licença/testador interno.
5. Gere o AAB assinado para publicação.

Observação: o botão de anúncio recompensado está apenas como ponte; o código de anúncios precisa ser integrado ao provedor de anúncios escolhido antes da publicação.
