package com.caofujao.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.util.Log;
import com.android.billingclient.api.*;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private BillingClient billing;
    private final Map<String, ProductDetails> products = new HashMap<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,27,55));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,27,55));
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void share(String message) {
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(send, "Convidar amigos"));
                });
            }
            @JavascriptInterface public void buyProduct(String productId) {
                runOnUiThread(() -> launchPurchase(productId));
            }
        }, "AndroidShare");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void buyProduct(String productId) {
                runOnUiThread(() -> launchPurchase(productId));
            }
        }, "AndroidBilling");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        setupBilling();
    }

    private void js(String script) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(script, null); });
    }
    private void setupBilling() {
        billing = BillingClient.newBuilder(this)
            .setListener((result, purchases) -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                    for (Purchase p : purchases) handlePurchase(p);
                } else if (result.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
                    js("window.onBillingReady&&window.onBillingReady(false,'Não foi possível concluir a compra. Tente novamente.');");
                }
            })
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .build();
        billing.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) queryProducts();
                else js("window.onBillingReady&&window.onBillingReady(false,'Google Play indisponível neste momento.');");
            }
            @Override public void onBillingServiceDisconnected() {
                js("window.onBillingReady&&window.onBillingReady(false,'Conexão com Google Play interrompida.');");
            }
        });
    }
    private void queryProducts() {
        List<QueryProductDetailsParams.Product> list = new ArrayList<>();
        for (String id : Arrays.asList("coins_500", "coins_1500", "coins_4000", "coins_10000"))
            list.add(QueryProductDetailsParams.Product.newBuilder().setProductId(id).setProductType(BillingClient.ProductType.INAPP).build());
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(list).build();
        billing.queryProductDetailsAsync(params, (result, query) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                products.clear();
                for (ProductDetails d : query.getProductDetailsList()) products.put(d.getProductId(), d);
                StringBuilder json = new StringBuilder("{");
                for (ProductDetails d : products.values()) {
                    if (json.length() > 1) json.append(',');
                    String price = d.getOneTimePurchaseOfferDetails() != null ? d.getOneTimePurchaseOfferDetails().getFormattedPrice() : "";
                    json.append("\"").append(d.getProductId()).append("\":\"").append(price.replace("\\", "\\\\").replace("\"", "\\\"")).append("\"");
                }
                json.append('}');
                js("window.onBillingProducts&&window.onBillingProducts(" + org.json.JSONObject.quote(json.toString()) + ");window.onBillingReady&&window.onBillingReady(true,'Compras pela Google Play disponíveis.');");
            } else js("window.onBillingReady&&window.onBillingReady(false,'Cadastre os pacotes de moedas no Google Play Console.');");
        });
    }
    private void launchPurchase(String id) {
        if (billing == null || !billing.isReady() || !products.containsKey(id)) {
            js("window.onBillingReady&&window.onBillingReady(false,'Pacote ainda não disponível na Google Play.');"); return;
        }
        ProductDetails d = products.get(id);
        BillingFlowParams.ProductDetailsParams dp = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(d).build();
        BillingFlowParams flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(Collections.singletonList(dp)).build();
        billing.launchBillingFlow(this, flow);
    }
    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        if (purchase.getProducts().isEmpty()) return;
        String productId = purchase.getProducts().get(0);
        if (purchase.isAcknowledged()) consume(purchase, productId);
        else {
            AcknowledgePurchaseParams ack = AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
            billing.acknowledgePurchase(ack, result -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) consume(purchase, productId);
            });
        }
    }
    private void consume(Purchase purchase, String productId) {
        ConsumeParams params = ConsumeParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
        billing.consumeAsync(params, (result, token) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                js("window.onGooglePurchase&&window.onGooglePurchase(" + org.json.JSONObject.quote(productId) + "," + org.json.JSONObject.quote(token) + ");");
            }
        });
    }
    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("(function(){var ids=['game','shop','rules','result','end'];for(var i=0;i<ids.length;i++){var e=document.getElementById(ids[i]);if(e&&!e.classList.contains('hidden')){['home','game','shop','rules','result','end'].forEach(function(x){document.getElementById(x).classList.add('hidden')});document.getElementById('home').classList.remove('hidden');return true}}return false})()", v -> { if ("false".equals(v)) super.onBackPressed(); });
        else super.onBackPressed();
    }
    @Override protected void onDestroy() { if (billing != null && billing.isReady()) billing.endConnection(); super.onDestroy(); }
}
