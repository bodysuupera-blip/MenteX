# Cão Fujão 1.3 — 500 fases

Projeto Android nativo com a mesma plataforma WebView do jogo anterior.

## Atualizações incluídas
- 500 fases com obstáculos que aumentam gradualmente (1 a 5, por faixa de 100 fases).
- Modo fácil: o cachorro só tenta se mover a cada quatro movimentos do jogador e fica parado em metade dessas tentativas.
- Controles direcionais grandes em cruz, com setas maiores e acessibilidade.
- Ícone redondo restaurado, sem número de versão.
- Sons de movimento, moeda, botão, vitória e derrota, com opção para desligar.
- Loja com descrição de funcionamento de cada item e preços em moedas reduzidos.
- Pacotes de moedas ligados ao Google Play Billing.
- Tela inicial sem a linha de saldo de corações/moedas.

## Google Play — configuração necessária
No Play Console, crie e ative produtos de compra única com estes IDs exatos: `coins_500`, `coins_1500`, `coins_4000` e `coins_10000`. Defina os preços na Play Console; o aplicativo mostra o preço localizado retornado pelo Google Play. As compras só podem ser testadas com o app distribuído por uma faixa de teste da Play Store e com uma conta de testador configurada.

**Atenção:** esta versão mantém o fluxo de compra no aplicativo. Para lançamento comercial, recomenda-se validar os tokens de compra em um backend seguro antes de conceder moedas, conforme a documentação oficial do Google Play Billing.

## Compilar
Use Gradle 8.9, Java 17 e Android SDK Platform 35. O workflow GitHub Actions correspondente compila `:app:assembleDebug`.
