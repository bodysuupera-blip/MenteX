# Voz do MENTEX 2.8

## Pronúncia da marca
Na fala, `MENTEX` é convertido para **“Mente xis”**. A grafia visual continua sendo MENTEX.

## Perfil desejado para a voz IA
Voz masculina brasileira, divertida e energética, com interpretação de palhaço de desenho animado, jovem, carismática, levemente grave, com reações exageradas e humor. Voz original, sem imitar pessoa real ou personagem conhecido.

## Importante
Esta versão ajusta a pronúncia e deixa o fallback do Android mais expressivo, mas **não contém áudio gerado por uma IA externa**. Para ter voz IA de verdade, é preciso gerar arquivos de áudio (por exemplo, em um serviço de TTS por IA) e colocar os MP3s no projeto, ou usar um backend seguro. A chave da API não deve ser colocada dentro do APK.
