FUGA DOS FANTASMAS - PACOTE DE ATUALIZACAO

Base: assets extraidos do APK enviado pelo usuario.

Alteracoes em assets/public:
- Nome/titulo atualizado para Fuga dos Fantasmas.
- Progressao limitada a 100 fases.
- Fase 1 com 3 fantasmas, aumentando progressivamente ate 20 na fase 100.
- Invisibilidade: 500 moedas, 10 segundos, uma ativacao por compra, sem acumular.
- Escudo: 500 moedas, protege 5 contatos, consumo ao esgotar, sem acumular.

Preservado nos assets:
- Canvas e estrutura visual original.
- Joystick, botoes e controles.
- Movimento e fluxo de chave/portal.
- Estilo da plataforma.

IMPORTANTE:
Este pacote contem arquivos de jogo (assets) atualizados, nao um APK compilado.
Para gerar APK, substitua os arquivos assets/public no projeto Android/Capacitor original
pela pasta deste pacote e compile/assine usando o fluxo de build existente.
