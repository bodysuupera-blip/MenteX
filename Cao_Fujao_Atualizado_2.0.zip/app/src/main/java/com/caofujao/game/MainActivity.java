package com.caofujao.game;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import com.android.billingclient.api.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

public class MainActivity extends Activity {
    private WebView web;
    private BillingClient billing;
    private final Map<String, ProductDetails> products = new HashMap<>();
    private final Map<String, Integer> coinAmounts = new HashMap<>();
    private boolean billingReady = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16,27,55));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16,27,55));
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void share(String message) {
                runOnUiThread(() -> {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_TEXT, message);
                    startActivity(Intent.createChooser(send, "Convidar amigos"));
                });
            }
        }, "AndroidShare");
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface public void buyCoins(String productId) {
                runOnUiThread(() -> launchCoinPurchase(productId));
            }
            @JavascriptInterface public String getBillingStatus() {
                return billingReady ? "ready" : "not_ready";
            }
        }, "AndroidBilling");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        setupBilling();
    }

    private void setupBilling() {
        billing = BillingClient.newBuilder(this)
            .setListener((billingResult, purchases) -> {
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                    for (Purchase purchase : purchases) handlePurchase(purchase);
                } else if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.USER_CANCELED) {
                    notifyPage("say('Não foi possível concluir a compra. Tente novamente.');");
                }
            })
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .build();
        billing.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    billingReady = true;
                    queryCoinProducts();
                }
            }
            @Override public void onBillingServiceDisconnected() { billingReady = false; }
        });
    }

    private void queryCoinProducts() {
        List<QueryProductDetailsParams.Product> list = new ArrayList<>();
        for (String id : Arrays.asList("coins_500", "coins_1500", "coins_5000", "coins_10000")) {
            list.add(QueryProductDetailsParams.Product.newBuilder()
                .setProductId(id).setProductType(BillingClient.ProductType.INAPP).build());
        }
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(list).build();
        billing.queryProductDetailsAsync(params, (result, queryResult) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                for (ProductDetails details : queryResult.getProductDetailsList()) products.put(details.getProductId(), details);
                notifyPage("say('Conexão com a Google Play pronta para compras.');");
            }
        });
    }

    private void launchCoinPurchase(String productId) {
        if (!billingReady || !products.containsKey(productId)) {
            notifyPage("say('Produto ainda não disponível. Cadastre os pacotes no Google Play Console e teste pela faixa de teste.');");
            return;
        }
        ProductDetails details = products.get(productId);
        BillingFlowParams.ProductDetailsParams productParams =
            BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details).build();
        BillingFlowParams flow = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(Collections.singletonList(productParams)).build();
        billing.launchBillingFlow(this, flow);
    }

    private void handlePurchase(Purchase purchase) {
        if (purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        String productId = purchase.getProducts().isEmpty() ? "" : purchase.getProducts().get(0);
        int amount;
        switch (productId) {
            case "coins_500": amount = 500; break;
            case "coins_1500": amount = 1500; break;
            case "coins_5000": amount = 5000; break;
            case "coins_10000": amount = 10000; break;
            default: return;
        }
        // Consumo permite que o mesmo pacote de moedas seja comprado novamente.
        ConsumeParams params = ConsumeParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
        final int credit = amount;
        billing.consumeAsync(params, (result, token) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                notifyPage("window.onCoinsPurchase && window.onCoinsPurchase('" + productId + "'," + credit + ");");
            } else {
                Log.e("CaoFujao", "Falha ao consumir compra: " + result.getDebugMessage());
            }
        });
    }

    private void notifyPage(String js) {
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    @Override protected void onDestroy() {
        if (billing != null) billing.endConnection();
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
