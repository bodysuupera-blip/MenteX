# Cão Fujão — atualização 2.0

Projeto Android (Java + WebView) com jogo HTML5.

## O que foi atualizado
- Progressão de dificuldade por faixa: fases 1–25 Fácil, 26–50 Médio, 51–75 Difícil e 76–100 Hard Extremo.
- Labirintos com geração que verifica se existe caminho entre o jogador e o cão.
- Armadilhas em fases intermediárias e avançadas.
- Loja com vida extra, escudo consumível, tênis turbo e ímã de moedas.
- Salvamento local de fase, moedas, vidas, pontuação e inventário.
- Correção dos controles direcionais, pausa e recordes.
- Integração Android com Google Play Billing para quatro produtos consumíveis:
  `coins_500`, `coins_1500`, `coins_5000`, `coins_10000`.

## IMPORTANTE: configurar compras na Play Store
A integração de faturamento está no código, mas as compras só ficam disponíveis depois que:
1. Criar os quatro produtos no Google Play Console com os IDs exatos acima.
2. Publicar um build em uma faixa de teste interno/fechado.
3. Adicionar os testadores licenciados e instalar o app pela Play Store.
4. Configurar preço e país no Console.

Os produtos são consumíveis (pacotes de moedas). Para um lançamento comercial robusto, valide compras no servidor antes de creditar moedas. Este projeto faz o consumo pelo cliente e é uma base de integração, não substitui validação de recibos em backend.

## Gerar APK
Abra a pasta no Android Studio com JDK 17 e Android SDK 35. Aguarde sincronizar o Gradle e use:
`Build > Build Bundle(s) / APK(s) > Build APK(s)`.

O ZIP contém código-fonte, não um APK compilado. O APK de debug fica em:
`app/build/outputs/apk/debug/app-debug.apk`.

## Observação sobre o projeto original enviado
O ZIP original não continha imagens externas da tela inicial/mascote nem wrapper Gradle. A atualização mantém a estrutura visual azul e o mascote em emoji que já existiam no código-fonte recebido.
