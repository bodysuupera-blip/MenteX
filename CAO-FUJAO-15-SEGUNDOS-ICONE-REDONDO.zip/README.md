# Cão Fujão — atualização com ícone redondo e cronômetro

- Mantém o projeto Android e os recursos existentes nesta versão.
- Mantém `android:icon` e `android:roundIcon` configurados no Manifest.
- Cada fase/ tentativa começa com 15 segundos visíveis na tela.
- O cronômetro pausa quando o jogo está pausado.
- Ao chegar a zero, o jogador perde uma vida e vê a tela de derrota.
- Capturar o cachorro antes do fim do tempo conclui a fase normalmente.
- O cronômetro é reiniciado ao avançar ou tentar novamente.
- Corrigido o seletor dos botões direcionais para que os controles respondam.
