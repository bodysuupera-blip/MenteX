# NEXUS 350 - projeto recuperado do APK enviado


Este projeto foi reconstruído a partir dos arquivos web encontrados dentro do APK fornecido. Não é o código-fonte original completo, mas inclui os arquivos de jogo extraídos e a configuração Capacitor.


## Gerar APK pelo GitHub Actions
1. Envie todo o conteúdo deste ZIP para a raiz de um repositório GitHub (substituindo os arquivos existentes, se necessário).
2. Abra Actions.
3. Execute `NEXUS 350 - APK com novo ícone` com Run workflow.
4. Baixe o APK em Artifacts quando finalizar.

