package com.arcade.labirintomortal;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.content.Context;
import android.graphics.*;
import java.util.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); getWindow().setStatusBarColor(Color.rgb(7,7,15)); getWindow().setNavigationBarColor(Color.rgb(7,7,15)); setContentView(new GameView(this)); }

    static class GameView extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); final Random random = new Random();
        final int cols=13, rows=17; int[][] map=new int[rows][cols];
        float cell, ox, oy, px, py, enemyX, enemyY; int level=1, lives=5, score=0, coins=0;
        int dir=1, desired=1, tick=0; boolean started=false, gameOver=false, won=false, shield=true;
        long last=0; final int[][] dirs={{0,-1},{1,0},{0,1},{-1,0}};
        GameView(Context c){super(c);setLayerType(View.LAYER_TYPE_SOFTWARE,null);setFocusable(true);newLevel();started=false;}
        void newLevel(){
            for(int y=0;y<rows;y++)for(int x=0;x<cols;x++)map[y][x]=(x==0||y==0||x==cols-1||y==rows-1)?1:0;
            for(int y=2;y<rows-2;y+=3)for(int x=2;x<cols-2;x++)if(x%4!=0)map[y][x]=1;
            for(int x=3;x<cols-3;x+=4)for(int y=3;y<rows-3;y+=4)map[y][x]=1;
            for(int y=1;y<rows-1;y++)map[y][6]=0;for(int x=1;x<cols-1;x++)map[8][x]=0;
            for(int i=0;i<3+Math.min(level,4);i++){int x,y;do{x=1+random.nextInt(cols-2);y=1+random.nextInt(rows-2);}while(map[y][x]!=0||(x==1&&y==1)||(x==cols-2&&y==rows-2));map[y][x]=2;}
            for(int i=0;i<2;i++){int x,y;do{x=2+random.nextInt(cols-4);y=2+random.nextInt(rows-4);}while(map[y][x]!=0);map[y][x]=3;}
            px=1;py=1;enemyX=cols-2;enemyY=rows-2;dir=1;desired=1;tick=0;gameOver=false;won=false;shield=true;invalidate();
        }
        @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();
            p.setShader(new LinearGradient(0,0,w,h,0xff151326,0xff05060d,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
            // atmospheric glows
            p.setShader(new RadialGradient(w*.12f,h*.12f,w*.6f,new int[]{0x442d1a58,0x00000000},null,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
            p.setShader(new RadialGradient(w*.9f,h*.6f,w*.45f,new int[]{0x3324002a,0x00000000},null,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
            drawHeader(c,w,h);
            if(started&&!gameOver&&!won)drawMaze(c,w,h);else drawBackdropMaze(c,w,h);
            drawControls(c,w,h);
            if(!started||gameOver||won)drawOverlay(c,w,h);
        }
        void drawHeader(Canvas c,float w,float h){
            p.setColor(0xfff3efff);p.setTypeface(Typeface.create("sans-serif-black",Typeface.BOLD));p.setTextSize(w*.065f);c.drawText("LABIRINTO",w*.065f,h*.055f,p);
            p.setColor(0xffff426d);p.setTextSize(w*.065f);c.drawText("MORTAL",w*.065f+w*.34f,h*.055f,p);
            p.setColor(0xff8e8aa8);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextSize(w*.027f);c.drawText("SOBREVIVA À ESCURIDÃO",w*.07f,h*.083f,p);
            float top=h*.105f, bottom=h*.155f, gap=w*.025f, left=w*.06f, cw=(w*.88f-gap*2)/3;
            statCard(c,left,top,left+cw,bottom,"FASE",String.format(Locale.getDefault(),"%03d",level),0xffb58aff);
            statCard(c,left+cw+gap,top,left+cw*2+gap,bottom,"VIDAS","♥ "+lives,0xffff426d);
            statCard(c,left+cw*2+gap*2,top,w*.94f,bottom,"PONTOS",""+score,0xff57e6d4);
        }
        void statCard(Canvas c,float l,float t,float r,float b,String label,String value,int accent){
            p.setColor(0xff151522);c.drawRoundRect(l,t,r,b,12,12,p);p.setColor(0xff302a40);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawRoundRect(l,t,r,b,12,12,p);p.setStyle(Paint.Style.FILL);
            p.setColor(accent);c.drawRoundRect(l+7,t+8,l+10,b-8,2,2,p);p.setColor(0xff89859f);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextSize(getWidth()*.022f);c.drawText(label,l+16,t+17,p);
            p.setColor(0xfff8f5ff);p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextSize(getWidth()*.032f);c.drawText(value,l+16,t+34,p);
        }
        void drawMaze(Canvas c,float w,float h){
            cell=Math.min((w*.88f)/cols,(h*.535f)/rows);ox=(w-cols*cell)/2;oy=h*.185f;
            p.setColor(0xb5090914);c.drawRoundRect(ox-9,oy-9,ox+cols*cell+9,oy+rows*cell+9,19,19,p);
            p.setColor(0xff3c294e);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(ox-5,oy-5,ox+cols*cell+5,oy+rows*cell+5,15,15,p);p.setStyle(Paint.Style.FILL);
            for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){float l=ox+x*cell,t=oy+y*cell;
                if(map[y][x]==1){p.setShader(new LinearGradient(l,t,l+cell,t+cell,0xff29243e,0xff11111f,Shader.TileMode.CLAMP));c.drawRoundRect(l+1,t+1,l+cell-1,t+cell-1,5,5,p);p.setShader(null);p.setColor(0xff4d3d68);p.setStrokeWidth(1);c.drawLine(l+4,t+cell*.22f,l+cell-4,t+cell*.22f,p);p.setColor(0xff191624);c.drawLine(l+cell*.25f,t+cell*.3f,l+cell*.25f,t+cell*.8f,p);}
                else {p.setColor(0xff151523);c.drawRect(l,t,l+cell,t+cell,p);p.setColor(0xff272137);p.setStrokeWidth(.7f);c.drawRect(l,t,l+cell,t+cell,p);
                    if(map[y][x]==2)drawSpike(c,l+cell/2,t+cell/2,cell*.37f);
                    else if(map[y][x]==3)drawLaser(c,l,t,cell);
                    else if((x*3+y*7)%11==0){p.setColor(0xffb58aff);c.drawCircle(l+cell/2,t+cell/2,cell*.07f,p);}
                }
            }
            // exit portal
            float ex=ox+(cols-1.5f)*cell,ey=oy+(rows-1.5f)*cell;p.setColor(0x553be7c4);p.setShadowLayer(18,0,0,0xff40f2cf);c.drawCircle(ex,ey,cell*.43f,p);p.clearShadowLayer();p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2.5f);p.setColor(0xff60f5d5);c.drawCircle(ex,ey,cell*.31f,p);c.drawCircle(ex,ey,cell*.18f,p);p.setStyle(Paint.Style.FILL);
            drawHunter(c,ox+(enemyX+.5f)*cell,oy+(enemyY+.5f)*cell,cell*.42f,tick);
            drawHero(c,ox+(px+.5f)*cell,oy+(py+.5f)*cell,cell*.44f,tick);
            p.setColor(0xff77718f);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextSize(w*.026f);p.setTextAlign(Paint.Align.CENTER);c.drawText("ENCONTRE O PORTAL • FUJA DA CRIATURA",w/2,oy+rows*cell+ h*.023f,p);p.setTextAlign(Paint.Align.LEFT);
        }
        void drawBackdropMaze(Canvas c,float w,float h){cell=Math.min((w*.88f)/cols,(h*.535f)/rows);ox=(w-cols*cell)/2;oy=h*.185f;
            for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){float l=ox+x*cell,t=oy+y*cell;p.setColor(((x+y)%2==0)?0xff12111c:0xff0e0d17);c.drawRoundRect(l+1,t+1,l+cell-1,t+cell-1,4,4,p);if(x==0||y==0||x==cols-1||y==rows-1){p.setColor(0xff292137);c.drawRoundRect(l+1,t+1,l+cell-1,t+cell-1,4,4,p);}}
            drawHunter(c,w*.72f,oy+rows*cell*.48f,cell*1.25f,tick);drawHero(c,w*.3f,oy+rows*cell*.67f,cell*1.1f,tick);
        }
        void drawSpike(Canvas c,float x,float y,float r){p.setColor(0x55ff315d);p.setShadowLayer(8,0,0,0xffff315d);c.drawCircle(x,y,r*1.2f,p);p.clearShadowLayer();Path a=new Path();a.moveTo(x,y-r);a.lineTo(x+r*.8f,y+r*.7f);a.lineTo(x-r*.8f,y+r*.7f);a.close();p.setShader(new LinearGradient(x-r,y-r,x+r,y+r,0xffff6b80,0xff6e183e,Shader.TileMode.CLAMP));c.drawPath(a,p);p.setShader(null);p.setColor(0xffffa0b0);c.drawLine(x,y-r*.55f,x,y+r*.45f,p);}
        void drawLaser(Canvas c,float l,float t,float s){p.setColor(0x55ff174f);c.drawRect(l+s*.18f,t+s*.43f,l+s*.82f,t+s*.57f,p);p.setColor((tick/10)%2==0?0xffff315b:0xff8d1c45);p.setShadowLayer(7,0,0,0xffff164d);c.drawRoundRect(l+s*.12f,t+s*.46f,l+s*.88f,t+s*.54f,3,3,p);p.clearShadowLayer();}
        void drawHero(Canvas c,float x,float y,float r,int frame){
            c.save();c.rotate((float)Math.sin(frame*.12)*3,x,y);
            p.setColor(0x553ce6ff);p.setShadowLayer(13,0,0,0xff36dff4);c.drawCircle(x,y,r*1.02f,p);p.clearShadowLayer();
            // boots and armored body
            p.setColor(0xff171c32);c.drawRoundRect(x-r*.55f,y+r*.28f,x-r*.12f,y+r*.86f,r*.12f,r*.12f,p);c.drawRoundRect(x+r*.12f,y+r*.28f,x+r*.55f,y+r*.86f,r*.12f,r*.12f,p);
            p.setShader(new LinearGradient(x-r,y-r,x+r,y+r,0xffd7f7ff,0xff4c7f9e,Shader.TileMode.CLAMP));Path body=new Path();body.moveTo(x-r*.58f,y-r*.08f);body.lineTo(x-r*.42f,y-r*.43f);body.lineTo(x+r*.42f,y-r*.43f);body.lineTo(x+r*.58f,y-r*.08f);body.lineTo(x+r*.38f,y+r*.55f);body.lineTo(x-r*.38f,y+r*.55f);body.close();c.drawPath(body,p);p.setShader(null);
            p.setColor(0xff29374e);c.drawRoundRect(x-r*.33f,y-r*.28f,x+r*.33f,y+r*.23f,r*.12f,r*.12f,p);p.setColor(0xff55efff);p.setShadowLayer(6,0,0,0xff4fefff);c.drawRoundRect(x-r*.25f,y-r*.17f,x+r*.25f,y-r*.03f,r*.06f,r*.06f,p);p.clearShadowLayer();
            // helmet and luminous visor
            p.setColor(0xffd9e9f4);c.drawCircle(x,y-r*.43f,r*.43f,p);p.setColor(0xff25334c);c.drawRoundRect(x-r*.34f,y-r*.55f,x+r*.34f,y-r*.3f,r*.12f,r*.12f,p);p.setColor(0xff61f5f1);p.setShadowLayer(5,0,0,0xff35f8ed);c.drawRoundRect(x-r*.25f,y-r*.49f,x+r*.25f,y-r*.39f,r*.05f,r*.05f,p);p.clearShadowLayer();
            p.setColor(0xfff5ffff);c.drawCircle(x-r*.27f,y+r*.05f,r*.07f,p);c.drawCircle(x+r*.27f,y+r*.05f,r*.07f,p);c.restore();
        }
        void drawHunter(Canvas c,float x,float y,float r,int frame){
            c.save();float bob=(float)Math.sin(frame*.18)*r*.06f;y+=bob;
            p.setColor(0x66ff164f);p.setShadowLayer(18,0,0,0xffff174f);c.drawCircle(x,y,r*1.08f,p);p.clearShadowLayer();
            // shoulders, long claws and body silhouette
            p.setColor(0xff210f22);Path torso=new Path();torso.moveTo(x-r*.56f,y-r*.05f);torso.lineTo(x-r*.75f,y+r*.25f);torso.lineTo(x-r*.42f,y+r*.37f);torso.lineTo(x-r*.28f,y+r*.72f);torso.lineTo(x+r*.28f,y+r*.72f);torso.lineTo(x+r*.42f,y+r*.37f);torso.lineTo(x+r*.75f,y+r*.25f);torso.lineTo(x+r*.56f,y-r*.05f);torso.close();c.drawPath(torso,p);
            p.setColor(0xff3b142c);p.setStrokeWidth(r*.14f);p.setStrokeCap(Paint.Cap.ROUND);c.drawLine(x-r*.5f,y+r*.08f,x-r*.78f,y+r*.58f,p);c.drawLine(x+r*.5f,y+r*.08f,x+r*.78f,y+r*.58f,p);p.setStrokeWidth(1);p.setStrokeCap(Paint.Cap.BUTT);
            // horns
            p.setColor(0xff110d19);Path horns=new Path();horns.moveTo(x-r*.4f,y-r*.35f);horns.lineTo(x-r*.78f,y-r*.92f);horns.lineTo(x-r*.22f,y-r*.58f);horns.lineTo(x+r*.22f,y-r*.58f);horns.lineTo(x+r*.78f,y-r*.92f);horns.lineTo(x+r*.4f,y-r*.35f);horns.close();c.drawPath(horns,p);
            p.setShader(new LinearGradient(x-r,y-r,x+r,y+r,0xff8c274b,0xff250d25,Shader.TileMode.CLAMP));c.drawOval(x-r*.56f,y-r*.56f,x+r*.56f,y+r*.38f,p);p.setShader(null);
            p.setColor(0xfffff0f3);Path jaw=new Path();jaw.moveTo(x-r*.36f,y+r*.02f);jaw.lineTo(x-r*.22f,y+r*.3f);jaw.lineTo(x,y+r*.42f);jaw.lineTo(x+r*.22f,y+r*.3f);jaw.lineTo(x+r*.36f,y+r*.02f);jaw.close();c.drawPath(jaw,p);
            p.setColor(0xffff263f);p.setShadowLayer(7,0,0,0xffff153a);c.drawOval(x-r*.38f,y-r*.19f,x-r*.08f,y-r*.04f,p);c.drawOval(x+r*.08f,y-r*.19f,x+r*.38f,y-r*.04f,p);p.clearShadowLayer();
            p.setColor(0xfff4dce5);for(int i=-1;i<=1;i++){float tx=x+i*r*.18f;Path fang=new Path();fang.moveTo(tx-r*.06f,y+r*.1f);fang.lineTo(tx,y+r*.28f);fang.lineTo(tx+r*.06f,y+r*.1f);fang.close();c.drawPath(fang,p);}c.restore();
        }
        void drawControls(Canvas c,float w,float h){float cy=h*.855f,r=w*.066f;drawControl(c,w*.5f,cy-r*1.08f,"▲");drawControl(c,w*.5f,cy+r*1.08f,"▼");drawControl(c,w*.5f-r*1.25f,cy,"◀");drawControl(c,w*.5f+r*1.25f,cy,"▶");
            p.setColor(0xff68627c);p.setTextSize(w*.025f);p.setTypeface(Typeface.create("sans-serif-medium",0));p.setTextAlign(Paint.Align.CENTER);c.drawText("TOQUE PARA SE MOVER",w/2,h*.965f,p);p.setTextAlign(Paint.Align.LEFT);
        }
        void drawControl(Canvas c,float x,float y,String s){float r=getWidth()*.052f;p.setColor(0xff191725);p.setShadowLayer(8,0,0,0xffa64cff);c.drawCircle(x,y,r*1.14f,p);p.clearShadowLayer();p.setColor(0xff30223f);c.drawCircle(x,y,r,p);p.setColor(0xffbb8cff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.7f);c.drawCircle(x,y,r,p);p.setStyle(Paint.Style.FILL);p.setColor(0xfff4eaff);p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextSize(getWidth()*.047f);c.drawText(s,x,y+getWidth()*.016f,p);p.setTextAlign(Paint.Align.LEFT);}
        void drawOverlay(Canvas c,float w,float h){p.setColor(0xc9050610);c.drawRect(0,0,w,h,p);float top=h*.31f,bottom=h*.68f;
            p.setColor(0xff171321);c.drawRoundRect(w*.07f,top,w*.93f,bottom,24,24,p);p.setColor(0xff624177);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(w*.07f,top,w*.93f,bottom,24,24,p);p.setStyle(Paint.Style.FILL);
            p.setTextAlign(Paint.Align.CENTER);p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextSize(w*.075f);p.setColor(won?0xff65f2d3:gameOver?0xffff496e:0xfff5edff);c.drawText(won?"VOCÊ SOBREVIVEU":gameOver?"FIM DE JOGO":"NÃO OLHE PARA TRÁS",w/2,top+h*.075f,p);
            p.setColor(0xffaaa1bd);p.setTypeface(Typeface.create("sans-serif",0));p.setTextSize(w*.035f);String sub=won?"O portal foi aberto. O próximo nível espera.":gameOver?"A criatura venceu desta vez.":"Atravesse o labirinto. Evite as armadilhas.";c.drawText(sub,w/2,top+h*.12f,p);
            p.setColor(0xffb64cff);p.setShadowLayer(14,0,0,0xff9e3cff);c.drawRoundRect(w*.22f,top+h*.17f,w*.78f,top+h*.25f,16,16,p);p.clearShadowLayer();p.setColor(0xff100a1b);p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextSize(w*.041f);c.drawText(won?"PRÓXIMA FASE":gameOver?"TENTAR NOVAMENTE":"ENTRAR NO LABIRINTO",w/2,top+h*.222f,p);p.setTextAlign(Paint.Align.LEFT);
        }
        boolean free(int x,int y){return x>0&&y>0&&x<cols-1&&y<rows-1&&map[y][x]!=1;}
        void step(){if(!started||gameOver||won)return;tick++;
            int nx=(int)px+dirs[desired][0],ny=(int)py+dirs[desired][1];if(free(nx,ny))dir=desired;nx=(int)px+dirs[dir][0];ny=(int)py+dirs[dir][1];if(free(nx,ny)){px=nx;py=ny;}
            int tx=(int)px,ty=(int)py;if(map[ty][tx]==2||(map[ty][tx]==3&&(tick/12)%2==0)){if(shield)shield=false;else{lives--;px=1;py=1;if(lives<=0)gameOver=true;}}
            else if(map[ty][tx]==0){score+=10;if(random.nextInt(5)==0)coins++;map[ty][tx]=4;}
            if(tick%2==0){int ex=(int)enemyX,ey=(int)enemyY;ArrayList<int[]> opts=new ArrayList<>();for(int d=0;d<4;d++){int ax=ex+dirs[d][0],ay=ey+dirs[d][1];if(free(ax,ay))opts.add(new int[]{ax,ay});}if(!opts.isEmpty()){opts.sort((a,b)->Integer.compare(Math.abs(a[0]-(int)px)+Math.abs(a[1]-(int)py),Math.abs(b[0]-(int)px)+Math.abs(b[1]-(int)py)));int[] a=opts.get(0);enemyX=a[0];enemyY=a[1];}}
            if(Math.abs(enemyX-px)<.1f&&Math.abs(enemyY-py)<.1f){lives--;px=1;py=1;if(lives<=0)gameOver=true;}
            if((int)px==cols-2&&(int)py==rows-2){won=true;level++;}
        }
        @Override public boolean onTouchEvent(MotionEvent e){if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();if(!started||gameOver||won){if(y>h*.47f&&y<h*.72f){if(gameOver){level=1;lives=5;score=0;coins=0;}newLevel();started=true;}invalidate();return true;}float cy=h*.855f,r=w*.066f;if(y<cy-r*.55f&&x>w*.35f&&x<w*.65f)desired=0;else if(y>cy+r*.55f&&x>w*.35f&&x<w*.65f)desired=2;else if(x<w*.5f)desired=3;else desired=1;return true;}
        @Override public void computeScroll(){super.computeScroll();long now=System.currentTimeMillis();if(now-last>230){last=now;step();invalidate();}postInvalidateDelayed(70);}
    }
}
