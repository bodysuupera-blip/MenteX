NEXUS 350 - SOURCE RECONSTRUIDA A PARTIR DO APK ORIGINAL

Esta fonte preserva os arquivos web extraidos do APK recebido:
- www/index.html
- www/game.js
- www/style.css
- www/welcome.png

O jogo nao foi reescrito nem alterado. O Android nativo e gerado pelo workflow.

Para compilar: npm install; npx cap add android; npx cap sync android; cd android; ./gradlew assembleDebug
