# MENTEX 3.9 — versão normal

- 5 corações ❤️ (limite máximo de 5)
- 200 fases + Modo Infinito
- recompensas em moedas e pontuação
- bônus diário
- loja com vidas, dicas e escudo
- anúncio recompensado: +1 ❤️ e +10 🪙
- anúncio intersticial entre fases conforme a lógica do jogo
- entrada em duas telas
- música somente na abertura
- sem voz e sem ícone de voz
- applicationId: br.com.mentex.game
- versão Android: 3.9.0
