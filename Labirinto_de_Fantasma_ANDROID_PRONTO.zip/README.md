# Labirinto de Fantasma — Android

Projeto mobile vertical baseado no primeiro layout enviado.

## Recursos
- 300 fases e 10 mundos planejados no jogo.
- Controle direcional grande em formato de cruz (+), com pausa separada.
- Moedas: +10 por moeda coletada e +10 ao concluir uma fase.
- Loja virtual com itens de 100 a 600 moedas.
- Efeitos sonoros e música gerados no próprio jogo, com controles para desligar.
- Progresso básico salvo localmente no aparelho.
- Arte de abertura incluída em `www/hero-maze.png`.

## Google Play
O pacote de 10.000 moedas por R$ 19,90 aparece na interface como oferta planejada. A cobrança real NÃO está ativa: é necessário criar o produto no Google Play Console e implementar/validar Google Play Billing.

## Gerar APK
Envie o conteúdo desta pasta para a raiz de um repositório GitHub e execute o workflow `LABIRINTO DE FANTASMA - APK ANDROID` em Actions. O workflow gera um APK debug para testes; publicação na Play Store exige assinatura e configuração de lançamento.
