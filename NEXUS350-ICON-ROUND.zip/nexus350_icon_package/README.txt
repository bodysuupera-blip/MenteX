NEXUS 350 - ICONE REDONDO

Arquivo:
NEXUS350-ICON-ROUND.png

Imagem quadrada 1254 x 1254 px, pronta como arte-base para o icone do aplicativo.

Para atualizar o projeto Android completo e integrar este icone ao APK, e necessario o ZIP mais recente do projeto-fonte.
