MENTEX V4.9 — PROJETO ANDROID COMPLETO

Este ZIP inclui o projeto Android e o HTML atualizado de rolagem.

Atualização aplicada: rolagem vertical nas telas inicial/após sair, perfil do jogador e resultado; a tela de perguntas continua sem rolagem.

Como usar no GitHub:
1. Extraia o ZIP no computador.
2. Envie o CONTEÚDO da pasta MENTEX_Android_Projeto para a raiz do repositório, incluindo a pasta oculta .github.
3. No GitHub, abra Actions > MENTEX V4.9 - Gerar APK > Run workflow.
4. Quando terminar, baixe o artefato MENTEX-V4.9-APK.

Nota: o projeto usa Gradle instalado pela ação oficial; não depende de um arquivo gradlew ausente. O anúncio recompensado ainda depende de integrar um provedor de anúncios, conforme README_ANDROID.txt.
