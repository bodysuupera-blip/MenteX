# Nexus 350 Ghost Run — recriação independente
Jogo HTML5/Canvas, mobile horizontal, pacote Capacitor. Abra o projeto e execute `npm install`, `npx cap add android`, `npx cap sync android`. Build debug: `cd android && ./gradlew assembleDebug`.

Nota: vida bônus é demo; anúncios reais exigem integração AdMob. Botão Google Play abre pesquisa até existir listing oficial.
