# MENTEX — estilo original melhorado

Projeto Android baseado na interface e nos recursos visuais do MENTEX enviado pelo usuário.

Melhorias incluídas:
- Mantém o estilo azul/neon, telas, mapa, fases, mascotes e reações do jogo antigo.
- Mantém abertura e manual/regras existentes.
- Adiciona convite de amigos pelo compartilhamento nativo do aparelho.
- Impede receber moedas e pontos novamente ao concluir a mesma fase já recompensada.
- Preserva os arquivos visuais originais do jogo.

## Gerar APK
Envie todos os arquivos deste projeto para o repositório GitHub. Execute o workflow `MENTEX - Gerar APK` em Actions e baixe o artefato.
