package com.caofujao.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.ProductDetailsParams;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Collections;
import java.util.List;

public class MainActivity extends Activity implements PurchasesUpdatedListener {
    private static final String COIN_PRODUCT_ID = "coins_10000";
    private WebView webView;
    private BillingClient billingClient;
    private ProductDetails coinProduct;
    private boolean pageReady = false;
    private boolean billingConnected = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 27, 55));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 27, 55));

        webView = new WebView(this);
        setContentView(webView);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageReady = true;
                if (billingConnected && coinProduct == null) queryCoinProduct();
                else if (coinProduct != null) notifyProductReady();
            }
        });
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new BillingBridge(), "AndroidBilling");
        webView.loadUrl("file:///android_asset/index.html");
        connectBilling();
    }

    private void connectBilling() {
        billingClient = BillingClient.newBuilder(this)
                .setListener(this)
                .enablePendingPurchases()
                .build();
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    billingConnected = true;
                    if (pageReady) queryCoinProduct();
                    restorePurchases();
                } else {
                    billingConnected = false;
                    js("window.onBillingReady && window.onBillingReady(false,'Google Play indisponível');");
                }
            }
            @Override public void onBillingServiceDisconnected() {
                js("window.onBillingReady && window.onBillingReady(false,'Conexão com a Google Play perdida');");
            }
        });
    }

    private void queryCoinProduct() {
        QueryProductDetailsParams.Product product = QueryProductDetailsParams.Product.newBuilder()
                .setProductId(COIN_PRODUCT_ID)
                .setProductType(BillingClient.ProductType.INAPP)
                .build();
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
                .setProductList(Collections.singletonList(product)).build();
        billingClient.queryProductDetailsAsync(params, (result, detailsList) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                coinProduct = detailsList.isEmpty() ? null : detailsList.get(0);
                if (coinProduct != null && coinProduct.getOneTimePurchaseOfferDetails() != null) {
                    notifyProductReady();
                } else {
                    js("window.onBillingReady && window.onBillingReady(false,'Produto de moedas não encontrado na Google Play');");
                }
            } else {
                js("window.onBillingReady && window.onBillingReady(false,'Não foi possível consultar o produto');");
            }
        });
    }

    private void notifyProductReady() {
        if (!pageReady || coinProduct == null || coinProduct.getOneTimePurchaseOfferDetails() == null) return;
        try {
            JSONObject prices = new JSONObject();
            prices.put(COIN_PRODUCT_ID, coinProduct.getOneTimePurchaseOfferDetails().getFormattedPrice());
            js("window.onBillingProducts && window.onBillingProducts(" + JSONObject.quote(prices.toString()) + ");");
        } catch (Exception ignored) { }
        js("window.onBillingReady && window.onBillingReady(true,'');");
    }

    private void restorePurchases() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
                .setProductType(BillingClient.ProductType.INAPP).build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                for (Purchase purchase : purchases) processPurchase(purchase);
            }
        });
    }

    private void launchCoinPurchase() {
        if (billingClient == null || !billingClient.isReady() || coinProduct == null) {
            js("window.onBillingReady && window.onBillingReady(false,'Pacote de moedas indisponível na Google Play');");
            return;
        }
        BillingFlowParams.ProductDetailsParams detailsParams = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(coinProduct).build();
        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
                .setProductDetailsParamsList(Collections.singletonList(detailsParams)).build();
        billingClient.launchBillingFlow(this, flowParams);
    }

    @Override public void onPurchasesUpdated(BillingResult result, List<Purchase> purchases) {
        if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
            for (Purchase purchase : purchases) processPurchase(purchase);
        } else if (result.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {
            js("window.onBillingReady && window.onBillingReady(true,'');");
        } else {
            js("window.onBillingReady && window.onBillingReady(false,'Não foi possível concluir a compra');");
        }
    }

    private void processPurchase(Purchase purchase) {
        if (!purchase.getProducts().contains(COIN_PRODUCT_ID)
                || purchase.getPurchaseState() != Purchase.PurchaseState.PURCHASED) return;
        if (purchase.isAcknowledged()) {
            grantAndConsume(purchase);
        } else {
            AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                    .setPurchaseToken(purchase.getPurchaseToken()).build();
            billingClient.acknowledgePurchase(params, result -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) grantAndConsume(purchase);
            });
        }
    }

    private void grantAndConsume(Purchase purchase) {
        String product = COIN_PRODUCT_ID;
        String token = purchase.getPurchaseToken();
        js("window.onGooglePurchase && window.onGooglePurchase(" + JSONObject.quote(product) + "," + JSONObject.quote(token) + ");");
        ConsumeParams params = ConsumeParams.newBuilder().setPurchaseToken(token).build();
        billingClient.consumeAsync(params, (result, consumedToken) -> { /* Consumível: permite comprar outro pacote depois. */ });
    }

    private void js(String script) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(script, null); });
    }

    private class BillingBridge {
        @JavascriptInterface public void buyProduct(String productId) {
            runOnUiThread(() -> {
                if (COIN_PRODUCT_ID.equals(productId)) launchCoinPurchase();
            });
        }
    }

    @Override protected void onDestroy() {
        if (billingClient != null && billingClient.isReady()) billingClient.endConnection();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
