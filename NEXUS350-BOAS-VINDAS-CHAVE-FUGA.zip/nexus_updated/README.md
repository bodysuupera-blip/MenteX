# NEXUS 350 - Labirinto de Fantasmas

Atualizacao de gameplay:
- Tela de captura quando as vidas acabam, com Tentar Novamente, Loja/Melhorias, Ajustar Som e Voltar ao Menu.
- Loja retorna para a tela de captura quando aberta a partir dela.
- Efeito de moeda acionado imediatamente, sem nota agendada com atraso.
- Efeito de conclusao da porta/fase tocado em acorde imediato, sem sequencia de notas atrasadas.
- Desbloqueio do AudioContext no primeiro toque para reduzir latencia de audio em celulares.


ZIP de projeto web/Capacitor para gerar APK via workflow GitHub Actions. Compra real na Google Play ainda exige configuracao do Google Play Billing e produto na Play Console.
