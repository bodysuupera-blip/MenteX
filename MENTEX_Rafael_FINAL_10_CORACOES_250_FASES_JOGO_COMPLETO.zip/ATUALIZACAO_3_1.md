# MENTEX Android 3.1 — Nova tela inicial

Base: MENTEX Android 3.0 — 200 fases (não é versão de teste).

Alteração:
- A primeira tela usa a nova arte fornecida pelo usuário em `app/src/main/assets/intro_screen.png`.
- A imagem ocupa a tela inteira.
- O botão COMEÇAR incorporado na arte funciona por uma área transparente clicável.
- Depois de COMEÇAR, aparece a tela existente de regras do jogo.
- Depois das regras, o jogo entra normalmente no mapa e nas 200 fases.
