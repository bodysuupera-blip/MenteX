# MENTEX Android 3.1 — Nova tela inicial

- Nova tela de abertura usando a arte fornecida pelo projeto.
- A nova tela aparece primeiro, antes da tela "COMO FUNCIONA O JOGO?".
- O botão COMEÇAR da nova arte leva para a tela de regras.
- O botão COMEÇAR da tela de regras continua levando ao jogo.
- Mantidos os 200 desafios e a estrutura da versão Android 3.0.
- Mantido o áudio de abertura já presente no APK.
