# MENTEX Android 3.2 — Tela de boas-vindas

- Nova tela inicial vertical em tela cheia usando `intro_screen.png`.
- A voz inicial é uma gravação de IA masculina e empolgada.
- A fala toca automaticamente ao abrir o aplicativo.
- Ao tocar no botão COMEÇAR da imagem, a voz é interrompida e a tela de regras aparece.
- Não usa Google/Android Text-to-Speech para a abertura.
- O restante do jogo permanece igual à versão Android 3.1.

Frase da abertura:
“E aííí! Eu sou o Mente X! Seja muito bem-vindo! Preparado pra desafiar essa cachola? Então boraaa! Vai ser divertido demais!”
