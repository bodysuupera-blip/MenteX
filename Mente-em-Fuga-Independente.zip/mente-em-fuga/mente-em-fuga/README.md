# Mente em Fuga — Labirinto Vivo (projeto independente)

Este projeto vive na pasta `mente-em-fuga/` e não usa arquivos de MENTEX, Cão Fujão ou qualquer outro jogo.

## Teste local
Abra `www/index.html` em um navegador. A movimentação funciona por setas, botões e swipe no labirinto.
## APK via GitHub Actions
Copie o workflow `main.yml` deste ZIP para `.github/workflows/mente-em-fuga.yml` na raiz do repositório. O workflow constrói somente este diretório.
## Avisos
A loja nesta versão é demonstrativa. Não há cobrança. Para pagamentos reais, implementar Google Play Billing; para recompensa de anúncio, integrar AdMob Rewarded e validar callback de recompensa.
