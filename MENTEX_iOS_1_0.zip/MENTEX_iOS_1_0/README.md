# MENTEX iOS 1.0

Projeto-fonte para iPhone que reaproveita o conteúdo web do MENTEX Android 3.0 (200 fases).

- Swift + WKWebView
- `index.html`, imagens e áudio do projeto Android reutilizados
- Ícone MENTEX incluído
- Portrait
- Bundle ID: `br.com.mentex.game.ios`

Este pacote é fonte para Xcode; não é um IPA assinado. Para instalar em um iPhone e publicar na App Store, é necessário macOS/Xcode e assinatura Apple.

Em 2026, uploads para App Store Connect devem ser construídos com Xcode 26 ou posterior usando SDK iOS 26 ou posterior.
