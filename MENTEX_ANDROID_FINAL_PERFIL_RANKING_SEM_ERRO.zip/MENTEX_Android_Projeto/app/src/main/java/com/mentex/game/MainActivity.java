package com.mentex.game;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private WebView webView;
    private BillingClient billingClient;
    private final Map<String, ProductDetails> products = new HashMap<>();
    private static final Map<String, Integer> COIN_AMOUNTS = new HashMap<>();
    static {
        COIN_AMOUNTS.put("coins_100", 100);
        COIN_AMOUNTS.put("coins_500", 500);
        COIN_AMOUNTS.put("coins_1200", 1200);
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        // Permite a música da introdução tocar automaticamente no APK.
        s.setMediaPlaybackRequiresUserGesture(false);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidAds");
        webView.loadUrl("file:///android_asset/index.html");
        setupBilling();
    }

    private void setupBilling() {
        billingClient = BillingClient.newBuilder(this)
                .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
                .enableAutoServiceReconnection()
                .setListener((billingResult, purchases) -> {
                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                        for (Purchase p : purchases) handlePurchase(p);
                    }
                }).build();
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult result) {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    queryProducts();
                    restorePurchases();
                }
            }
            @Override public void onBillingServiceDisconnected() { }
        });
    }

    private void queryProducts() {
        List<QueryProductDetailsParams.Product> list = new ArrayList<>();
        for (String id : COIN_AMOUNTS.keySet()) {
            list.add(QueryProductDetailsParams.Product.newBuilder()
                    .setProductId(id).setProductType(BillingClient.ProductType.INAPP).build());
        }
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder().setProductList(list).build();
        billingClient.queryProductDetailsAsync(params, (result, details) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && details != null) {
                products.clear();
                for (ProductDetails d : details.getProductDetailsList()) products.put(d.getProductId(), d);
            }
        });
    }

    private void restorePurchases() {
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.INAPP).build();
        billingClient.queryPurchasesAsync(params, (result, purchases) -> {
            if (result.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {
                for (Purchase p : purchases) handlePurchase(p);
            }
        });
    }

    private void launchPurchase(String productId) {
        if (billingClient == null || !billingClient.isReady()) {
            Toast.makeText(this, "Google Play ainda está conectando. Tente novamente.", Toast.LENGTH_SHORT).show();
            return;
        }
        ProductDetails d = products.get(productId);
        if (d == null) {
            Toast.makeText(this, "Produto indisponível. Configure-o no Google Play Console.", Toast.LENGTH_LONG).show();
            queryProducts();
            return;
        }
        BillingFlowParams.ProductDetailsParams pd = BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(d).build();
        BillingFlowParams flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(List.of(pd)).build();
        billingClient.launchBillingFlow(this, flow);
    }

    private void handlePurchase(Purchase purchase) {
        if (!purchase.getProducts().isEmpty() && purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
            String productId = purchase.getProducts().get(0);
            Integer amount = COIN_AMOUNTS.get(productId);
            if (amount == null) return;
            ConsumeParams cp = ConsumeParams.newBuilder().setPurchaseToken(purchase.getPurchaseToken()).build();
            billingClient.consumeAsync(cp, (result, token) -> {
                if (result.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    runOnUiThread(() -> webView.evaluateJavascript("window.onAndroidCoinPurchaseSuccess(" + amount + ");", null));
                }
            });
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void purchaseCoins(String amount) {
            String id = "coins_" + amount;
            if (!COIN_AMOUNTS.containsKey(id)) return;
            runOnUiThread(() -> launchPurchase(id));
        }
        @JavascriptInterface public void showRewardedAd() {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, "Anúncio recompensado será integrado aqui.", Toast.LENGTH_SHORT).show());
        }
    }

    @Override protected void onDestroy() {
        if (billingClient != null) billingClient.endConnection();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
