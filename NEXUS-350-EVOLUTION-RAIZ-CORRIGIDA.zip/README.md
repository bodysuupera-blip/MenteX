# NEXUS 350 EVOLUTION
Projeto novo e independente do código anterior. Jogo web em canvas, pronto para empacotamento Android com Capacitor via GitHub Actions.

## Build APK
1. Envie o conteúdo desta pasta para um repositório GitHub novo (ou substitua o conteúdo de um repositório dedicado).
2. Vá em **Actions** → **NEXUS 350 EVOLUTION - BUILD APK** → **Run workflow**.
3. Quando terminar, abra a execução e baixe `Nexus-350-Evolution-APK` em Artifacts.

O workflow gera APK debug. Para publicar na Play Store será necessário configurar assinatura de release e billing/ads reais.
