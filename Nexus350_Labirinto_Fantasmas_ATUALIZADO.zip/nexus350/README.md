# Nexus 350 — Labirinto de Fantasmas

Projeto Android/Capacitor independente. Jogo em tela cheia, orientação horizontal, canvas responsivo, controles touch virtuais, fases, fantasmas perseguidores, moedas, chave e portal.

## Build no GitHub Actions
1. Coloque este ZIP na raiz do repositório.
2. Workflow `Nexus350 - APK Android` pode ser disparado manualmente.
3. O workflow instala dependências, adiciona/sincroniza Android e compila APK debug.

Observação: loja e compras são demonstrativas/local. Não há Billing Google Play nem anúncios reais conectados. O convite usa compartilhamento do dispositivo quando disponível.
