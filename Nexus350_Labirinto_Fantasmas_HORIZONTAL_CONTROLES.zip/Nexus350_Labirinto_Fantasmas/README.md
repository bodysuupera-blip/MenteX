# Nexus 350 — Labirinto de Fantasmas

Projeto Android horizontal (landscape), independente.

## Conteúdo
- Menu animado com título Nexus 350 e opções Jogar, Loja, Perfil, Convidar e Som.
- Arena aberta: pegue a chave, evite fantasmas perseguidores e alcance o portal.
- 350 fases progressivas, vidas, moedas, poderes, pausa e controles touch.
- Efeitos sonoros sintetizados com Web Audio (ativados após interação do usuário).
- Capacitor + workflow GitHub Actions para APK debug.

## Build
Envie `Nexus350_Labirinto_Fantasmas.zip` para a raiz do repositório e adicione o workflow em `.github/workflows/build-nexus350.yml`. Execute Actions > Nexus 350 - Gerar APK Android.

Observação: a loja usa moedas internas demonstrativas; anúncios recompensados e publicação Google Play ainda exigem integração/conta próprias.
