# Labirinto de Fantasmas — fonte reconstruída do demonstrativo


Esta fonte foi reconstruída a partir dos arquivos web embutidos no APK fornecido. Mantém a base de jogo HTML/CSS/JavaScript e o wrapper Capacitor, sem trocar a plataforma por outro motor.


## Atualizações nesta versão
- Nome atualizado para **Labirinto de Fantasmas**.
- Controles direcionais em cruz.
- Fantasmas com movimento automático contínuo (intervalo aproximado de 450 ms).
- Cronômetro de 15 segundos por fase.
- Moedas coletadas: +10 cada.
- Fase concluída: +10 moedas.
- Botão de recompensa de vida com fluxo demonstrativo.
- Botão para pacote único de 10.000 moedas com tela de configuração pendente.


## Importante sobre serviços externos
Os botões de anúncio e compra são **demonstrativos** nesta fonte. Para recompensas reais, integrar uma rede de anúncios recompensados e validar o callback de conclusão. Para compra real, cadastrar um produto consumível/não consumível conforme decisão da loja na Google Play Console e integrar Google Play Billing. Não há cobrança ou anúncio real ativo nesta versão.


## Construção Android
O workflow GitHub Actions (`.github/workflows/build-android.yml`) gera uma plataforma Android Capacitor no runner e compila APK debug para download nos artefatos da execução.


## Arquivos principais
- `www/index.html`: jogo e interface.
- `package.json`: dependências Capacitor.
- `capacitor.config.json`: nome e identificador Android.
