(()=>{'use strict';
const canvas=document.getElementById('field'),ctx=canvas.getContext('2d'),screen=document.getElementById('screen'),modal=document.getElementById('modal'),modalContent=document.getElementById('modalContent');
const $=id=>document.getElementById(id);let W=0,H=0,dpr=1,active=false,paused=false,sound=true,phase=1,coins=0,lives=5,key=false,toastTimer=0,held=new Set(),lastTick=0,player={x:0,y:0,r:12,speed:190},ghosts=[],walls=[],coinItems=[],portal={x:0,y:0},keyItem={x:0,y:0},obstacles=[];
function resize(){dpr=Math.min(2,devicePixelRatio||1);W=innerWidth;H=innerHeight;canvas.width=Math.floor(W*dpr);canvas.height=Math.floor(H*dpr);canvas.style.width=W+'px';canvas.style.height=H+'px';ctx.setTransform(dpr,0,0,dpr,0,0);if(!active)drawPreview();}addEventListener('resize',resize);
function showToast(t){$('toast').textContent=t;$('toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').classList.remove('show'),1800)}
function updateHud(){$('phase').textContent=phase;$('coins').textContent=coins;$('lives').textContent=Array.from({length:5},(_,i)=>i<lives?'♥':'♡').join(' ')}
function layout(){
  const margin=Math.min(W,H)*.12;
  const box={x:margin,y:62,w:W-margin*2,h:H-72-margin};
  // Campo aberto: sem paredes/atalhos aleatorios, para o jogador cruzar o mapa.
  walls=[]; obstacles=[];
  player.x=box.x+box.w-48; player.y=box.y+box.h*.72;
  portal={x:box.x+box.w-28,y:box.y+box.h*.72};
  keyItem={x:box.x+28,y:box.y+box.h*.28,got:false};
  coinItems=[];
  const coinCount=4+((phase-1)%3); // apenas 4 a 6 moedas por fase
  for(let i=0;i<coinCount;i++){
    const t=(i+1)/(coinCount+1);
    coinItems.push({x:box.x+box.w*(.18+.64*t),y:box.y+box.h*(.2+((i%2)*.58)),got:false});
  }
  ghosts=[];
  const count=Math.min(2+Math.floor((phase-1)/8),7);
  // Fantasmas nascem em pontos bem separados e recebem alvos/movimentos individuais.
  const spawn=[
    {x:box.x+box.w*.25,y:box.y+box.h*.22},
    {x:box.x+box.w*.48,y:box.y+box.h*.78},
    {x:box.x+box.w*.68,y:box.y+box.h*.28},
    {x:box.x+box.w*.34,y:box.y+box.h*.55},
    {x:box.x+box.w*.78,y:box.y+box.h*.7},
    {x:box.x+box.w*.56,y:box.y+box.h*.48},
    {x:box.x+box.w*.16,y:box.y+box.h*.78}
  ];
  for(let i=0;i<count;i++){const pos=spawn[i];ghosts.push({x:pos.x,y:pos.y,r:13,color:['#ff5c88','#b47cff','#4de5ff','#ffb35d','#80ff99'][i%5],speed:46+Math.min(phase,50)*.42+Math.random()*7,phaseOffset:i*1.7,turn:i%2?1:-1});}
}
function roundedRect(x,y,w,h,r,fill,stroke){ctx.beginPath();ctx.roundRect(x,y,w,h,r);if(fill){ctx.fillStyle=fill;ctx.fill()}if(stroke){ctx.strokeStyle=stroke;ctx.stroke()}}
function draw(){ctx.clearRect(0,0,W,H);let grad=ctx.createLinearGradient(0,0,W,H);grad.addColorStop(0,'#071a2d');grad.addColorStop(1,'#030a15');ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);let margin=Math.min(W,H)*.12,bx=margin,by=56,bw=W-margin*2,bh=H-70-margin;
// subtle tile maze field
ctx.strokeStyle='#18395155';ctx.lineWidth=1;for(let x=bx;x<bx+bw;x+=34){ctx.beginPath();ctx.moveTo(x,by);ctx.lineTo(x,by+bh);ctx.stroke()}for(let y=by;y<by+bh;y+=34){ctx.beginPath();ctx.moveTo(bx,y);ctx.lineTo(bx+bw,y);ctx.stroke()}
roundedRect(bx,by,bw,bh,18,null,'#49c9ff55');walls.forEach(w=>roundedRect(w.x,w.y,w.w,w.h,5,'#1b4564','#43b9ff88'));
obstacles.forEach(o=>{ctx.beginPath();ctx.arc(o.x,o.y,o.r,0,Math.PI*2);ctx.fillStyle='#ff773344';ctx.fill();ctx.strokeStyle='#ff886a';ctx.stroke()});coinItems.filter(c=>!c.got).forEach(c=>{ctx.beginPath();ctx.arc(c.x,c.y,8,0,Math.PI*2);ctx.fillStyle='#ffd955';ctx.fill();ctx.strokeStyle='#fff0a1';ctx.stroke();ctx.fillStyle='#9e6a0d';ctx.font='bold 9px Arial';ctx.textAlign='center';ctx.fillText('$',c.x,c.y+3)});
if(!keyItem.got){ctx.fillStyle='#ffe46a';ctx.font='22px Arial';ctx.textAlign='center';ctx.fillText('🔑',keyItem.x,keyItem.y+8)}ctx.font='26px Arial';ctx.fillText('🚪',portal.x,portal.y+9);
ghosts.forEach(g=>drawGhost(g));drawPlayer();}
function drawGhost(g){ctx.save();ctx.translate(g.x,g.y);ctx.shadowBlur=14;ctx.shadowColor=g.color;ctx.fillStyle=g.color;ctx.beginPath();ctx.arc(0,-2,g.r,Math.PI,0);ctx.lineTo(g.r,g.r);ctx.lineTo(g.r*.5,g.r*.65);ctx.lineTo(0,g.r);ctx.lineTo(-g.r*.5,g.r*.65);ctx.lineTo(-g.r,g.r);ctx.closePath();ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#fff';ctx.beginPath();ctx.ellipse(-4,-2,3.5,5,0,0,Math.PI*2);ctx.ellipse(4,-2,3.5,5,0,0,Math.PI*2);ctx.fill();ctx.fillStyle='#15324b';ctx.beginPath();ctx.arc(-4,-1,1.5,0,Math.PI*2);ctx.arc(4,-1,1.5,0,Math.PI*2);ctx.fill();ctx.restore()}
function drawPlayer(){ctx.save();ctx.shadowBlur=18;ctx.shadowColor='#55edff';ctx.fillStyle='#6be7ff';ctx.beginPath();ctx.arc(player.x,player.y,player.r,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#07223a';ctx.beginPath();ctx.arc(player.x+4,player.y-3,2,0,Math.PI*2);ctx.fill();ctx.restore()}
function drawPreview(){if(W&&H){walls=[];coinItems=[];ghosts=[];obstacles=[];player.x=W*.5;player.y=H*.6;portal={x:W*.8,y:H*.3};keyItem={x:W*.3,y:H*.35,got:false};draw()}}
function startGame(){screen.classList.add('hidden');modal.classList.add('hidden');active=true;paused=false;phase=1;lives=5;coins=0;layout();updateHud();showToast('Pegue a chave e chegue ao portal!')}
function clampToField(){let margin=Math.min(W,H)*.12;player.x=Math.max(margin+player.r,Math.min(W-margin-player.r,player.x));player.y=Math.max(62+player.r,Math.min(H-margin-player.r,player.y))}
function hitsWall(x,y){return walls.some(w=>x+player.r>w.x&&x-player.r<w.x+w.w&&y+player.r>w.y&&y-player.r<w.y+w.h)}
function step(dt){if(!active||paused)return;let dx=0,dy=0;if(held.has('left')||held.has('ArrowLeft'))dx--;if(held.has('right')||held.has('ArrowRight'))dx++;if(held.has('up')||held.has('ArrowUp'))dy--;if(held.has('down')||held.has('ArrowDown'))dy++;let len=Math.hypot(dx,dy)||1;dx/=len;dy/=len;let nx=player.x+dx*player.speed*dt,ny=player.y+dy*player.speed*dt;if(!hitsWall(nx,player.y))player.x=nx;if(!hitsWall(player.x,ny))player.y=ny;clampToField();ghosts.forEach((g,i)=>{let d=Math.hypot(player.x-g.x,player.y-g.y)||1;let steerX=(player.x-g.x)/d,steerY=(player.y-g.y)/d;g.x+=steerX*g.speed*dt;g.y+=steerY*g.speed*dt;/* separation prevents ghost pile-ups */ghosts.forEach((other,j)=>{if(i===j)return;let sx=g.x-other.x,sy=g.y-other.y,sd=Math.hypot(sx,sy)||1;if(sd<g.r+other.r+12){g.x+=(sx/sd)*24*dt;g.y+=(sy/sd)*24*dt}});});coinItems.forEach(c=>{if(!c.got&&Math.hypot(player.x-c.x,player.y-c.y)<player.r+10){c.got=true;coins+=5;updateHud();showToast('+5 moedas')}});if(!keyItem.got&&Math.hypot(player.x-keyItem.x,player.y-keyItem.y)<player.r+18){keyItem.got=true;showToast('Chave encontrada! Vá ao portal')};if(keyItem.got&&Math.hypot(player.x-portal.x,player.y-portal.y)<player.r+22){phase=Math.min(350,phase+1);layout();updateHud();showToast('Fase '+phase+'!')};if(ghosts.some(g=>Math.hypot(player.x-g.x,player.y-g.y)<player.r+g.r)){lives--;updateHud();player.x=W-Math.min(W,H)*.12-48;player.y=H*.72;ghosts.forEach((g,i)=>{let pos=[.22,.42,.62,.78,.32,.55,.7][i%7];g.x=W*pos;g.y=H*(i%2?.25:.72)});showToast(lives?'Um fantasma pegou você!':'Fim de jogo!');if(lives<=0){active=false;setTimeout(()=>showModal('FIM DE JOGO',`Você chegou à fase ${phase} e acumulou ${coins} moedas.`,[['TENTAR NOVAMENTE',startGame],['VOLTAR AO MENU',()=>{screen.classList.remove('hidden')}]]),700)}}}
function loop(t){let dt=Math.min(.04,(t-lastTick)/1000||0);lastTick=t;if(active&&!paused)step(dt);if(active||!screen.classList.contains('hidden'))draw();requestAnimationFrame(loop)}requestAnimationFrame(loop);
function showModal(title,body,actions=[]){modalContent.innerHTML=`<h2>${title}</h2><p>${body}</p>`;actions.forEach(([label,fn])=>{let b=document.createElement('button');b.textContent=label;b.onclick=()=>{modal.classList.add('hidden');fn()};modalContent.appendChild(b)});modal.classList.remove('hidden')}
function openMenu(){showModal('NEXUS 350',`Fase ${phase} • ${coins} moedas • ${lives} vidas`,[['CONTINUAR',()=>{paused=false}],['LOJA',openStore],['PERFIL',openProfile],['CONVIDAR',invite],['VOLTAR AO MENU',()=>{active=false;paused=false;screen.classList.remove('hidden')}]]);paused=true}
function openStore(){showModal('LOJA DE MOEDAS',`Você possui ${coins} moedas. A loja é local (itens demonstrativos).`,[['COMPRAR VIDA — 40 moedas',()=>{if(coins>=40&&lives<5){coins-=40;lives++;updateHud();showToast('Vida comprada!')}else showToast(coins<40?'Moedas insuficientes':'Você já tem 5 vidas')}],['VELOCIDADE — 60 moedas',()=>{if(coins>=60){coins-=60;player.speed+=25;updateHud();showToast('Velocidade aumentada!')}else showToast('Moedas insuficientes')}],['FECHAR',()=>{}]])}
function openProfile(){showModal('PERFIL',`Aventureiro Nexus<br><br>Fase alcançada: ${phase}/350<br>Moedas coletadas: ${coins}<br>Vidas restantes: ${lives}`,[['FECHAR',()=>{}]])}
async function invite(){let msg='Vamos jogar Nexus 350 – Labirinto de Fantasmas! Colete moedas, pegue a chave e escape!';try{if(navigator.share)await navigator.share({title:'Nexus 350',text:msg});else{await navigator.clipboard.writeText(msg);showToast('Convite copiado!')}}catch(e){showToast('Convite pronto: compartilhe Nexus 350!')}}
$('startBtn').onclick=startGame;$('menuBtn').onclick=openMenu;$('pauseBtn').onclick=()=>{if(active){paused=!paused;showToast(paused?'Jogo pausado':'Continuando')}};$('exitBtn').onclick=()=>showModal('SAIR DO JOGO','Deseja voltar ao menu principal?',[['SIM, SAIR',()=>{active=false;paused=false;screen.classList.remove('hidden')}],['CANCELAR',()=>{}]]);$('soundBtn').onclick=()=>{sound=!sound;$('soundBtn').textContent=sound?'🔊':'🔇';showToast(sound?'Som ativado':'Som desativado')};$('storeBtn').onclick=openStore;$('profileBtn').onclick=openProfile;$('inviteBtn').onclick=invite;$('closeModal').onclick=()=>modal.classList.add('hidden');
const pad=document.querySelectorAll('.pad[data-dir]');pad.forEach(b=>{let dir=b.dataset.dir;const down=e=>{e.preventDefault();held.add(dir);try{b.setPointerCapture(e.pointerId)}catch{}};const up=e=>{e.preventDefault();held.delete(dir)};b.addEventListener('pointerdown',down);['pointerup','pointercancel','pointerleave','lostpointercapture'].forEach(ev=>b.addEventListener(ev,up));});addEventListener('keydown',e=>{let map={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',w:'up',s:'down',a:'left',d:'right'};if(map[e.key]){e.preventDefault();held.add(map[e.key])}if(e.key==='Escape')openMenu()});addEventListener('keyup',e=>{let map={ArrowUp:'up',ArrowDown:'down',ArrowLeft:'left',ArrowRight:'right',w:'up',s:'down',a:'left',d:'right'};if(map[e.key])held.delete(map[e.key])});document.addEventListener('visibilitychange',()=>{if(document.hidden&&active)paused=true});document.addEventListener('contextmenu',e=>e.preventDefault());document.addEventListener('selectstart',e=>e.preventDefault());document.addEventListener('copy',e=>e.preventDefault());resize();updateHud();
// best effort orientation/fullscreen on start (requires browser permission gesture)
$('startBtn').addEventListener('click',()=>{try{if(document.documentElement.requestFullscreen)document.documentElement.requestFullscreen().catch(()=>{});if(screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{})}catch{}},{once:false});
})();
