package com.arcade.labirintomortal;

import android.app.Activity;
import android.os.Bundle;
import android.view.*;
import android.graphics.*;
import android.content.Context;
import android.content.SharedPreferences;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Vibrator;
import java.util.*;

public class MainActivity extends Activity {
  @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().getDecorView().setSystemUiVisibility(4|1024|4096);setContentView(new ArcadeView(this));}
  @Override public void onBackPressed(){ if(view!=null)view.back(); else super.onBackPressed(); }
  @Override protected void onDestroy(){if(view!=null)view.tones.release();super.onDestroy();}
  ArcadeView view;
  class ArcadeView extends View {
    final Paint p=new Paint(3); final Random rng=new Random(); final SharedPreferences prefs=getSharedPreferences("labirinto",0);
    final ToneGenerator tones=new ToneGenerator(AudioManager.STREAM_MUSIC,55);
    String screen="intro", notice="", player="CAÇADOR", dailyDate=""; boolean sound=true, vibration=true, moving=false, dead=false, victory=false, dailyClaimed=false; int dailyRuns=0;
    int coins, best, totalRuns, bonusPoints=0, level=1,lives=3,score=0,selected=0; boolean[] owned={true,false,false,false};
    final String[] skins={"NEON", "SOMBRA", "VENENO", "COSMOS"}; final int[] skinColors={0xff31eaff,0xffb6a4ff,0xff7dff72,0xffff71c8}; final int[] prices={0,180,320,500};
    final int cols=13,rows=17; int[][] map=new int[rows][cols]; float cell,ox,oy,px,py,ex,ey; int direction=1,wanted=1,tick=0; long last=0; float anim=0;
    ArcadeView(Context c){super(c);view=this;setLayerType(View.LAYER_TYPE_SOFTWARE,null);coins=prefs.getInt("coins",0);best=prefs.getInt("best",0);totalRuns=prefs.getInt("runs",0);bonusPoints=prefs.getInt("bonusPoints",0);selected=prefs.getInt("skin",0);for(int i=0;i<4;i++)owned[i]=prefs.getBoolean("owned"+i,i==0);sound=prefs.getBoolean("sound",true);vibration=prefs.getBoolean("vibration",true);dailyDate=prefs.getString("dailyDate","");dailyRuns=prefs.getInt("dailyRuns",0);dailyClaimed=prefs.getBoolean("dailyClaimed",false);String today=new java.text.SimpleDateFormat("yyyyMMdd",java.util.Locale.US).format(new java.util.Date());if(!today.equals(dailyDate)){dailyDate=today;dailyRuns=0;dailyClaimed=false;save();}}
    void save(){prefs.edit().putInt("coins",coins).putInt("best",best).putInt("runs",totalRuns).putInt("bonusPoints",bonusPoints).putInt("skin",selected).putBoolean("sound",sound).putBoolean("vibration",vibration).putString("dailyDate",dailyDate).putInt("dailyRuns",dailyRuns).putBoolean("dailyClaimed",dailyClaimed).apply();for(int i=0;i<4;i++)prefs.edit().putBoolean("owned"+i,owned[i]).apply();}
    void tone(int t){if(sound)try{tones.startTone(t,110);}catch(Exception ignored){}}
    void back(){if(screen.equals("game")){screen="menu";moving=false;}else if(!screen.equals("menu")){screen="menu";}else{screen="intro";}invalidate();}
    void start(){level=1;lives=Math.max(3,lives);score=bonusPoints;bonusPoints=0;totalRuns++;dailyRuns++;newLevel();screen="game";save();tone(ToneGenerator.TONE_PROP_ACK);}
    void newLevel(){for(int y=0;y<rows;y++)for(int x=0;x<cols;x++)map[y][x]=(x==0||y==0||x==cols-1||y==rows-1)?1:0;
      for(int y=2;y<rows-2;y+=3)for(int x=2;x<cols-2;x++)if(x%4!=0)map[y][x]=1;
      for(int x=3;x<cols-3;x+=4)for(int y=3;y<rows-3;y+=4)map[y][x]=1;
      for(int y=1;y<rows-1;y++)map[y][6]=0;for(int x=1;x<cols-1;x++)map[8][x]=0;
      for(int i=0;i<4+Math.min(level,7);i++){int x,y;do{x=1+rng.nextInt(cols-2);y=1+rng.nextInt(rows-2);}while(map[y][x]!=0||(x==1&&y==1)||(x==cols-2&&y==rows-2));map[y][x]=2;}
      for(int i=0;i<3;i++){int x,y;do{x=2+rng.nextInt(cols-4);y=2+rng.nextInt(rows-4);}while(map[y][x]!=0);map[y][x]=3;}
      px=1;py=1;ex=cols-2;ey=rows-2;direction=1;wanted=1;tick=0;dead=false;victory=false;moving=true;}
    @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight();anim+=.035f;drawBackdrop(c,w,h);
      if(screen.equals("intro"))drawIntro(c,w,h);else if(screen.equals("menu"))drawMenu(c,w,h);else if(screen.equals("shop"))drawShop(c,w,h);else if(screen.equals("profile"))drawProfile(c,w,h);else if(screen.equals("ranking"))drawRanking(c,w,h);else if(screen.equals("howto"))drawHowTo(c,w,h);else if(screen.equals("invite"))drawInvite(c,w,h);else if(screen.equals("bank"))drawBank(c,w,h);else if(screen.equals("missions"))drawMissions(c,w,h);else if(screen.equals("achievements"))drawAchievements(c,w,h);else if(screen.equals("settings"))drawSettings(c,w,h);else drawGame(c,w,h);
      postInvalidateDelayed(45);
    }
    void drawBackdrop(Canvas c,float w,float h){p.setShader(new LinearGradient(0,0,w,h,0xff090d20,0xff160d2a,Shader.TileMode.CLAMP));c.drawRect(0,0,w,h,p);p.setShader(null);
      for(int i=0;i<32;i++){float x=(float)((i*83+Math.sin(anim+i)*20)%w);float y=(float)((i*137+anim*18)%h);p.setColor(i%3==0?0x5536dfff:0x33a16cff);c.drawCircle(x,y,1.5f+(i%3),p);} }
    void text(Canvas c,String s,float x,float y,float size,int color,boolean bold){p.setColor(color);p.setTextSize(size);p.setTypeface(Typeface.create("sans-serif"+(bold?"-black":""),bold?1:0));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y,p);p.setTextAlign(Paint.Align.LEFT);}
    void panel(Canvas c,float l,float t,float r,float b){p.setColor(0xdd101a31);p.setStyle(Paint.Style.FILL);c.drawRoundRect(l,t,r,b,24,24,p);p.setColor(0x883b6da0);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1.5f);c.drawRoundRect(l,t,r,b,24,24,p);p.setStyle(Paint.Style.FILL);}
    void button(Canvas c,String s,float x,float y,float ww,float hh,int color){p.setColor(color);c.drawRoundRect(x-ww/2,y-hh/2,x+ww/2,y+hh/2,hh/2,hh/2,p);p.setColor(0xff07101e);p.setTextSize(Math.min(ww*.095f,ww*1.45f/Math.max(1,s.length())));p.setTypeface(Typeface.create("sans-serif-black",1));p.setTextAlign(Paint.Align.CENTER);c.drawText(s,x,y+ww*.032f,p);p.setTextAlign(Paint.Align.LEFT);}
    void monster(Canvas c,float x,float y,float r,int color,float phase){p.setColor(color);p.setShadowLayer(r*.55f,0,0,color);c.drawCircle(x,y,r,p);p.clearShadowLayer();p.setColor(0xff101126);RectF m=new RectF(x-r*.55f,y-r*.05f,x+r*.55f,y+r*.68f);c.drawArc(m,0,180,true,p);p.setColor(0xfff8ffff);c.drawOval(x-r*.43f,y-r*.45f,x-r*.08f,y+r*.02f,p);c.drawOval(x+r*.08f,y-r*.45f,x+r*.43f,y+r*.02f,p);p.setColor(0xff15152c);c.drawCircle(x-r*.24f,y-r*.2f,r*.1f,p);c.drawCircle(x+r*.24f,y-r*.2f,r*.1f,p);p.setColor(0xfff8ffff);for(int i=0;i<4;i++)c.drawRoundRect(x-r*.36f+i*r*.2f,y+r*.31f,x-r*.27f+i*r*.2f,y+r*.48f,2,2,p);}
    void drawIntro(Canvas c,float w,float h){
      float cx=w/2;
      p.setColor(0x332d70ff);c.drawCircle(cx,h*.31f,w*.27f,p);
      monster(c,cx,h*.31f,w*.18f,skinColors[selected],anim);
      text(c,"BEM-VINDO AO",cx,h*.53f,w*.052f,0xffa8c8ef,true);
      text(c,"LABIRINTO",cx,h*.60f,w*.105f,0xfff3f7ff,true);
      text(c,"MORTAL",cx,h*.68f,w*.13f,0xffff477b,true);
      text(c,"VOCÊ CONSEGUE ESCAPAR?",cx,h*.75f,w*.035f,0xffb4c8e8,true);
      button(c,"ENTRAR NO JOGO",cx,h*.86f,w*.72f,h*.075f,0xff43e5e8);
      text(c,"ARCADE • SOBREVIVA • EVOLUA",cx,h*.94f,w*.027f,0xff7189b2,true);
    }
    void drawMenu(Canvas c,float w,float h){
      // Hub principal redesenhado: identidade visual, progresso e atalhos em cartões.
      text(c,"LABIRINTO",w/2,h*.075f,w*.083f,0xfff5f8ff,true);
      text(c,"MORTAL  /  TOQUE AQUI: COMO JOGAR",w/2,h*.115f,w*.027f,0xff82a6d9,true);
      panel(c,w*.07f,h*.15f,w*.93f,h*.355f);
      monster(c,w*.27f,h*.255f,w*.095f,skinColors[selected],anim);
      text(c,"BEM-VINDO DE VOLTA",w*.64f,h*.205f,w*.033f,0xff9db7df,true);
      text(c,player,w*.64f,h*.255f,w*.061f,0xfff5f8ff,true);
      text(c,"FASE  "+level,w*.64f,h*.30f,w*.039f,0xff5be8dc,true);
      text(c,"◆ "+coins+"   ♥ "+lives,w*.64f,h*.335f,w*.033f,0xffffd36d,true);
      // Barra de evolução até o próximo marco.
      p.setColor(0xff263958);c.drawRoundRect(w*.13f,h*.385f,w*.87f,h*.402f,12,12,p);
      p.setColor(0xff4fe3d2);c.drawRoundRect(w*.13f,h*.385f,w*(.13f+.74f*Math.min(1f,(best%1000)/1000f)),h*.402f,12,12,p);
      text(c,"RECORDE  "+best+" PONTOS",w/2,h*.445f,w*.032f,0xffd7e5ff,true);
      button(c,"▶  ENTRAR NO LABIRINTO",w/2,h*.515f,w*.84f,h*.075f,0xff43e5d8);
      // Grade de serviços da plataforma.
      cardButton(c,"LOJA","CRIATURAS E VISUAIS",w*.27f,h*.625f,w*.40f,h*.085f,0xff9b83ff);
      cardButton(c,"MISSÕES","DESAFIO DO DIA",w*.73f,h*.625f,w*.40f,h*.085f,0xffffc45c);
      cardButton(c,"CARTEIRA","MOEDAS E VIDAS",w*.27f,h*.735f,w*.40f,h*.085f,0xff4ccebb);
      cardButton(c,"RANKING","SEUS RECORDES",w*.73f,h*.735f,w*.40f,h*.085f,0xffff658e);
      text(c,"PERFIL",w*.11f,h*.855f,w*.025f,0xffdce8ff,true);
      text(c,"GUIA",w*.30f,h*.855f,w*.025f,0xffdce8ff,true);
      text(c,"TROFÉUS",w*.50f,h*.855f,w*.023f,0xffdce8ff,true);
      text(c,"AMIGOS",w*.70f,h*.855f,w*.024f,0xffdce8ff,true);
      text(c,"AJUSTES",w*.89f,h*.855f,w*.023f,0xffdce8ff,true);
      for(int i=0;i<5;i++){float x=w*(.11f+i*.195f);p.setColor(i==0?0xff4c9eff:i==1?0xff579bff:i==2?0xffffc45c:i==3?0xff54d6a4:0xff9b83ff);c.drawCircle(x,h*.89f,w*.023f,p);}
      text(c,"EVENTO DIÁRIO  •  ENTRE, JOGUE E EVOLUA",w/2,h*.955f,w*.026f,0xff7189b2,true);
    }
    void cardButton(Canvas c,String title,String sub,float x,float y,float ww,float hh,int color){
      p.setColor(0xdd14213c);c.drawRoundRect(x-ww/2,y-hh/2,x+ww/2,y+hh/2,18,18,p);
      p.setColor(color);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawRoundRect(x-ww/2,y-hh/2,x+ww/2,y+hh/2,18,18,p);p.setStyle(Paint.Style.FILL);
      text(c,title,x,y-2,getWidth()*.041f,0xfff5f8ff,true);text(c,sub,x,y+getHeight()*.025f,getWidth()*.021f,color,true);
    }
    void drawMissions(Canvas c,float w,float h){
      header(c,"CENTRAL DE MISSÕES","Desafios que renovam sua jornada");
      panel(c,w*.08f,h*.22f,w*.92f,h*.73f);
      text(c,"MISSÃO DIÁRIA",w/2,h*.30f,w*.048f,0xffffd36d,true);
      text(c,"Entre no labirinto e complete uma partida",w/2,h*.37f,w*.031f,0xffdce8ff,false);
      text(c,"PROGRESSO  "+Math.min(dailyRuns,1)+" / 1",w/2,h*.45f,w*.046f,0xff5be8d8,true);
      p.setColor(0xff263958);c.drawRoundRect(w*.17f,h*.49f,w*.83f,h*.515f,12,12,p);
      p.setColor(0xff50e0c9);c.drawRoundRect(w*.17f,h*.49f,w*(.17f+.66f*Math.min(1,dailyRuns)),h*.515f,12,12,p);
      text(c,"RECOMPENSA: 75 MOEDAS",w/2,h*.58f,w*.039f,0xffffd36d,true);
      button(c,dailyClaimed?"MISSÃO CONCLUÍDA":(dailyRuns>0?"RESGATAR RECOMPENSA":"JOGAR AGORA"),w/2,h*.68f,w*.76f,h*.075f,dailyClaimed?0xff607da9:(dailyRuns>0?0xff50dfbd:0xff579bff));
      text(c,"MISSÕES RENOVAM A CADA DIA",w/2,h*.77f,w*.027f,0xff9db2d6,true);
      text(c,notice,w/2,h*.82f,w*.028f,0xffffbd72,true);
      button(c,"VOLTAR",w/2,h*.90f,w*.45f,h*.065f,0xff607da9);
    }
    void drawAchievements(Canvas c,float w,float h){
      header(c,"GALERIA DE CONQUISTAS","Marcos desbloqueados na sua jornada");
      String[] names={"PRIMEIRA FUGA","CAÇADOR DE ORBES","SOBREVIVENTE","LENDÁRIO"};
      String[] desc={"Inicie sua primeira partida","Alcance 500 pontos","Alcance 1.000 pontos","Alcance 5.000 pontos"};
      int[] goals={1,500,1000,5000}; int[] vals={totalRuns,best,best,best};
      for(int i=0;i<4;i++){float y=h*(.28f+i*.145f);panel(c,w*.09f,y-h*.052f,w*.91f,y+h*.052f);p.setColor(vals[i]>=goals[i]?0xffffcf65:0xff52678c);c.drawCircle(w*.20f,y,w*.027f,p);text(c,vals[i]>=goals[i]?"★":"·",w*.20f,y+w*.012f,w*.04f,0xff10172b,true);text(c,names[i],w*.54f,y-h*.009f,w*.036f,0xfff4f7ff,true);text(c,desc[i],w*.54f,y+h*.025f,w*.025f,0xffa9bddc,false);}
      button(c,"VOLTAR",w/2,h*.90f,w*.45f,h*.065f,0xff607da9);
    }
    void drawSettings(Canvas c,float w,float h){
      header(c,"CENTRAL DE AJUSTES","Personalize sua experiência");
      panel(c,w*.09f,h*.25f,w*.91f,h*.72f);
      text(c,"ÁUDIO DO JOGO",w/2,h*.36f,w*.044f,0xfff4f7ff,true);
      button(c,sound?"SOM LIGADO":"SOM DESLIGADO",w/2,h*.43f,w*.65f,h*.07f,sound?0xff4bd9c4:0xff607da9);
      text(c,"VIBRAÇÃO",w/2,h*.55f,w*.044f,0xfff4f7ff,true);
      button(c,vibration?"VIBRAÇÃO LIGADA":"VIBRAÇÃO DESLIGADA",w/2,h*.62f,w*.75f,h*.07f,vibration?0xff4bd9c4:0xff607da9);
      text(c,"SEUS DADOS FICAM SALVOS NESTE APARELHO",w/2,h*.72f,w*.026f,0xff9db2d6,true);
      button(c,"VOLTAR",w/2,h*.86f,w*.45f,h*.065f,0xff607da9);
    }
    void drawHowTo(Canvas c,float w,float h){
      header(c,"COMO JOGAR","Aprenda a sobreviver ao labirinto");
      panel(c,w*.08f,h*.22f,w*.92f,h*.76f);
      String[] lines={"1. USE AS SETAS PARA SE MOVER", "2. COLETE ORBES PARA GANHAR PONTOS", "3. FUJA DO CAÇADOR VERMELHO", "4. NÃO PISE NOS ESPINHOS", "5. EVITE AS ARMADILHAS DE LASER", "6. CHEGUE À SAÍDA PARA AVANÇAR", "", "DICA: GUARDE MOEDAS PARA COMPRAR", "VIDAS EXTRAS E NOVAS CRIATURAS."};
      for(int i=0;i<lines.length;i++)text(c,lines[i],w/2,h*(.31f+i*.052f),w*.032f,i==8?0xffffd66b:0xffe4edff,true);
      button(c,"VOLTAR",w/2,h*.88f,w*.48f,h*.07f,0xff607da9);
    }
    void drawInvite(Canvas c,float w,float h){
      header(c,"CHAME SEUS AMIGOS","Compartilhe o desafio");
      monster(c,w/2,h*.34f,w*.15f,skinColors[selected],anim);
      panel(c,w*.1f,h*.52f,w*.9f,h*.72f);
      text(c,"VOCÊ CONSEGUE ESCAPAR?",w/2,h*.60f,w*.045f,0xfff4f7ff,true);
      text(c,"Convide seus amigos para",w/2,h*.65f,w*.034f,0xffb7c9e5,false);
      text(c,"bater seu recorde no labirinto!",w/2,h*.69f,w*.034f,0xffb7c9e5,false);
      button(c,"COMPARTILHAR CONVITE",w/2,h*.79f,w*.78f,h*.075f,0xff54d6a4);
      button(c,"VOLTAR",w/2,h*.90f,w*.45f,h*.065f,0xff607da9);
    }
    void drawBank(Canvas c,float w,float h){
      header(c,"PONTOS E VIDAS","Use suas moedas para continuar");
      panel(c,w*.1f,h*.22f,w*.9f,h*.36f);
      text(c,"SUA CARTEIRA",w/2,h*.29f,w*.04f,0xffa9bfdf,true);
      text(c,"◆ "+coins+" MOEDAS",w/2,h*.36f,w*.075f,0xffffd66b,true);
      text(c,"♥ "+lives+" VIDAS",w/2,h*.42f,w*.06f,0xffff7298,true);
      text(c,"BÔNUS PARA A PRÓXIMA PARTIDA: "+bonusPoints,w/2,h*.535f,w*.027f,0xffb9c9e5,true);
      text(c,"★ "+score+" PONTOS NESTA PARTIDA",w/2,h*.49f,w*.032f,0xff75e8d0,true);
      button(c,"COMPRAR 1 VIDA • 30 MOEDAS",w/2,h*.65f,w*.82f,h*.075f,0xffff7196);
      button(c,"TROCAR 50 MOEDAS POR 500 PONTOS",w/2,h*.76f,w*.86f,h*.075f,0xff58d9c7);
      text(c,notice,w/2,h*.835f,w*.03f,0xffffbd72,true);
      button(c,"VOLTAR",w/2,h*.91f,w*.45f,h*.065f,0xff607da9);
    }
    void drawShop(Canvas c,float w,float h){header(c,"LOJA DE CRIATURAS","Desbloqueie aparências com suas moedas");for(int i=0;i<4;i++){float y=h*.28f+i*h*.145f;panel(c,w*.09f,y-h*.055f,w*.91f,y+h*.055f);monster(c,w*.23f,y,w*.038f,skinColors[i],anim);text(c,skins[i],w*.43f,y-5,w*.043f,0xfff4f7ff,true);text(c,owned[i]?(selected==i?"EQUIPADO":"DESBLOQUEADO"):"◆ "+prices[i],w*.69f,y+22,w*.032f,owned[i]?0xff55e9c0:0xffffd36d,true);button(c,owned[i]?(selected==i?"OK":"USAR"):"COMPRAR",w*.78f,y+2,w*.22f,h*.052f,owned[i]?0xff48d8c7:0xffffc45c);}button(c,"VOLTAR",w/2,h*.91f,w*.45f,h*.065f,0xff607da9);}
    void header(Canvas c,String a,String b){text(c,a,getWidth()/2,getHeight()*.10f,getWidth()*.075f,0xfff4f7ff,true);text(c,b,getWidth()/2,getHeight()*.15f,getWidth()*.031f,0xff9db2d6,false);}
    void drawProfile(Canvas c,float w,float h){header(c,"MEU PERFIL","Sua jornada no labirinto");monster(c,w/2,h*.32f,w*.13f,skinColors[selected],anim);text(c,player,w/2,h*.44f,w*.055f,0xfff4f7ff,true);panel(c,w*.12f,h*.51f,w*.88f,h*.78f);text(c,"MELHOR PONTUAÇÃO",w/2,h*.58f,w*.035f,0xffa8bbd8,true);text(c,""+best,w/2,h*.65f,w*.10f,0xffffd66b,true);text(c,"PARTIDAS INICIADAS: "+totalRuns,w/2,h*.72f,w*.035f,0xffdce8ff,true);text(c,"MOEDAS: "+coins,w/2,h*.76f,w*.035f,0xff63e9d0,true);button(c,"VOLTAR",w/2,h*.89f,w*.45f,h*.07f,0xff607da9);}
    void drawRanking(Canvas c,float w,float h){header(c,"RANKING LOCAL","Seus melhores resultados neste aparelho");panel(c,w*.1f,h*.24f,w*.9f,h*.72f);text(c,"#",w*.22f,h*.32f,w*.04f,0xff8fa9d0,true);text(c,"JOGADOR",w*.47f,h*.32f,w*.04f,0xff8fa9d0,true);text(c,"PONTOS",w*.77f,h*.32f,w*.04f,0xff8fa9d0,true);String[] labels={"1  •  VOCÊ","2  •  MELHOR MARCA","3  •  PRÓXIMO DESAFIO"};int[] values={best,best,Math.max(0,best-100)};for(int i=0;i<3;i++){float y=h*(.42f+i*.105f);text(c,labels[i],w*.42f,y,w*.032f,i==0?0xffffd66b:0xffdce7fa,true);text(c,""+values[i],w*.78f,y,w*.035f,0xff65e9d2,true);}text(c,"Ranking offline: sem jogadores fictícios.",w/2,h*.70f,w*.026f,0xff8198bc,false);button(c,"VOLTAR",w/2,h*.86f,w*.45f,h*.07f,0xff607da9);}
    void drawGame(Canvas c,float w,float h){text(c,"FASE "+level+"     ♥ "+lives+"     ★ "+score+"     ◆ "+coins,w/2,h*.065f,w*.039f,0xffe9f2ff,true);cell=Math.min(w*.88f/cols,h*.59f/rows);ox=(w-cols*cell)/2;oy=h*.13f;panel(c,ox-7,oy-7,ox+cols*cell+7,oy+rows*cell+7);
      for(int y=0;y<rows;y++)for(int x=0;x<cols;x++){float l=ox+x*cell,t=oy+y*cell;if(map[y][x]==1){p.setColor(0xff273d72);c.drawRoundRect(l+1,t+1,l+cell-1,t+cell-1,5,5,p);p.setColor(0xff5479ce);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);c.drawRoundRect(l+3,t+3,l+cell-3,t+cell-3,4,4,p);p.setStyle(Paint.Style.FILL);}else if(map[y][x]==2){p.setColor((tick/7)%2==0?0xffff477c:0xff9e2c60);Path tr=new Path();tr.moveTo(l+cell/2,t+cell*.16f);tr.lineTo(l+cell*.84f,t+cell*.84f);tr.lineTo(l+cell*.16f,t+cell*.84f);tr.close();c.drawPath(tr,p);}else if(map[y][x]==3){p.setColor((tick/10)%2==0?0xffffbf4c:0xff743d45);p.setStrokeWidth(4);c.drawLine(l+cell*.18f,t+cell/2,l+cell*.82f,t+cell/2,p);}else{p.setColor(0xff30415e);c.drawCircle(l+cell/2,t+cell/2,cell*.045f,p);}}
      p.setColor(0xff51f2c3);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(3);c.drawCircle(ox+(cols-1.5f)*cell,oy+(rows-1.5f)*cell,cell*.3f,p);p.setStyle(Paint.Style.FILL);monster(c,ox+(ex+.5f)*cell,oy+(ey+.5f)*cell,cell*.34f,0xffff477c,anim);monster(c,ox+(px+.5f)*cell,oy+(py+.5f)*cell,cell*.36f,skinColors[selected],anim);
      float cy=h*.84f,r=w*.067f;control(c,w*.5f,cy-r*1.1f,"▲");control(c,w*.5f,cy+r*1.1f,"▼");control(c,w*.5f-r*1.35f,cy,"◀");control(c,w*.5f+r*1.35f,cy,"▶");text(c,"TOQUE NAS SETAS • FUJA DO CAÇADOR",w/2,h*.97f,w*.027f,0xff8ca3c9,true);
      if(dead||victory){panel(c,w*.09f,h*.34f,w*.91f,h*.64f);text(c,victory?"VOCÊ SOBREVIVEU":"A ESCURIDÃO VENCEU",w/2,h*.43f,w*.062f,victory?0xff55efc5:0xffff6489,true);text(c,victory?"Prepare-se. O próximo labirinto é pior.":"Suas vidas acabaram.",w/2,h*.49f,w*.034f,0xffd4def1,false);button(c,victory?"PRÓXIMA FASE":"TENTAR NOVAMENTE",w/2,h*.56f,w*.68f,h*.07f,0xff48e2d8);}
    }
    void control(Canvas c,float x,float y,String s){p.setColor(0xff1d3158);c.drawCircle(x,y,getWidth()*.052f,p);p.setColor(0xff62eaff);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);c.drawCircle(x,y,getWidth()*.052f,p);p.setStyle(Paint.Style.FILL);text(c,s,x,y+getWidth()*.018f,getWidth()*.052f,0xffeafaff,true);}
    boolean free(int x,int y){return x>0&&y>0&&x<cols-1&&y<rows-1&&map[y][x]!=1;}
    void hit(){lives--;tone(ToneGenerator.TONE_PROP_NACK);if(vibration)try{((Vibrator)getContext().getSystemService(VIBRATOR_SERVICE)).vibrate(100);}catch(Exception ignored){}px=1;py=1;if(lives<=0){dead=true;moving=false;coins+=score/100;save();}}
    void step(){if(!screen.equals("game")||!moving||dead||victory)return;tick++;int nx=(int)px+new int[]{0,1,0,-1}[wanted],ny=(int)py+new int[]{-1,0,1,0}[wanted];if(free(nx,ny))direction=wanted;nx=(int)px+new int[]{0,1,0,-1}[direction];ny=(int)py+new int[]{-1,0,1,0}[direction];if(free(nx,ny)){px=nx;py=ny;}
      int tx=(int)px,ty=(int)py;if(map[ty][tx]==2||(map[ty][tx]==3&&(tick/10)%2==0)){hit();}else if(map[ty][tx]==0){score+=10;if(rng.nextInt(4)==0){coins++;tone(ToneGenerator.TONE_PROP_BEEP);save();}map[ty][tx]=4;}
      if(tick%2==0){int ax=(int)ex,ay=(int)ey;ArrayList<int[]> opts=new ArrayList<>();int[][] ds={{0,-1},{1,0},{0,1},{-1,0}};for(int[] d:ds)if(free(ax+d[0],ay+d[1]))opts.add(new int[]{ax+d[0],ay+d[1]});if(!opts.isEmpty()){opts.sort((a,b)->Integer.compare(Math.abs(a[0]-(int)px)+Math.abs(a[1]-(int)py),Math.abs(b[0]-(int)px)+Math.abs(b[1]-(int)py)));ex=opts.get(0)[0];ey=opts.get(0)[1];}}
      if(Math.abs(ex-px)<.1f&&Math.abs(ey-py)<.1f)hit();if((int)px==cols-2&&(int)py==rows-2){victory=true;moving=false;score+=level*100;coins+=level*15;level++;if(score>best)best=score;save();tone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD);}}
    @Override public boolean onTouchEvent(android.view.MotionEvent e){float x=e.getX(),y=e.getY(),w=getWidth(),h=getHeight();if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;
      if(screen.equals("intro")){screen="menu";tone(ToneGenerator.TONE_PROP_ACK);}
      else if(screen.equals("menu")){if(y>h*.085f&&y<h*.145f)screen="howto";else if(y>h*.47f&&y<h*.56f)start();else if(y>h*.57f&&y<h*.68f){if(x<w*.5f)screen="shop";else screen="missions";}else if(y>h*.69f&&y<h*.79f){if(x<w*.5f)screen="bank";else screen="ranking";}else if(y>h*.82f&&y<h*.92f){if(x<w*.20f)screen="profile";else if(x<w*.40f)screen="howto";else if(x<w*.60f)screen="achievements";else if(x<w*.80f)screen="invite";else screen="settings";}}
      else if(screen.equals("howto")){if(y>h*.80f)screen="menu";}
      else if(screen.equals("invite")){if(y>h*.74f&&y<h*.85f){try{android.content.Intent send=new android.content.Intent(android.content.Intent.ACTION_SEND);send.setType("text/plain");send.putExtra(android.content.Intent.EXTRA_SUBJECT,"Desafio: Labirinto Mortal");send.putExtra(android.content.Intent.EXTRA_TEXT,"Vamos jogar LABIRINTO MORTAL! Entre no labirinto, fuja das armadilhas e tente superar meu recorde de "+best+" pontos.");getContext().startActivity(android.content.Intent.createChooser(send,"Convidar amigos"));}catch(Exception ignored){}}else if(y>h*.86f)screen="menu";}
      else if(screen.equals("bank")){if(y>h*.60f&&y<h*.70f){if(coins>=30){coins-=30;lives=Math.min(9,lives+1);notice="VIDA ADICIONADA!";tone(ToneGenerator.TONE_PROP_ACK);save();}else{notice="MOEDAS INSUFICIENTES";tone(ToneGenerator.TONE_PROP_NACK);}}else if(y>h*.71f&&y<h*.81f){if(coins>=50){coins-=50;bonusPoints+=500;notice="500 PONTOS RESERVADOS PARA A PRÓXIMA PARTIDA!";tone(ToneGenerator.TONE_PROP_ACK);save();}else{notice="MOEDAS INSUFICIENTES";tone(ToneGenerator.TONE_PROP_NACK);}}else if(y>h*.85f){screen="menu";notice="";}}
      else if(screen.equals("shop")){if(y>h*.86f){screen="menu";}else{int i=Math.round((y-h*.28f)/(h*.145f));if(i>=0&&i<4){if(owned[i]){selected=i;save();tone(ToneGenerator.TONE_PROP_ACK);}else if(coins>=prices[i]){coins-=prices[i];owned[i]=true;selected=i;save();tone(ToneGenerator.TONE_PROP_ACK);}else{notice="MOEDAS INSUFICIENTES";tone(ToneGenerator.TONE_PROP_NACK);}}}}
      else if(screen.equals("profile")||screen.equals("ranking")||screen.equals("achievements")){if(y>h*.78f)screen="menu";}
      else if(screen.equals("missions")){if(y>h*.61f&&y<h*.75f){if(dailyRuns>0&&!dailyClaimed){coins+=75;dailyClaimed=true;notice="75 MOEDAS RESGATADAS!";save();tone(ToneGenerator.TONE_PROP_ACK);}else if(!dailyClaimed){start();}}else if(y>h*.85f){screen="menu";notice="";}}
      else if(screen.equals("settings")){if(y>h*.38f&&y<h*.49f){sound=!sound;save();tone(ToneGenerator.TONE_PROP_BEEP);}else if(y>h*.55f&&y<h*.68f){vibration=!vibration;save();tone(ToneGenerator.TONE_PROP_BEEP);}else if(y>h*.80f)screen="menu";}
      else if(screen.equals("game")){if(dead||victory){if(y>h*.50f&&y<h*.63f){if(dead){level=1;lives=3;score=0;}newLevel();}else if(y<h*.34f){screen="menu";}}else{float cy=h*.84f,r=w*.067f;if(y<cy-r*.55f&&x>w*.35f&&x<w*.65f)wanted=0;else if(y>cy+r*.55f&&x>w*.35f&&x<w*.65f)wanted=2;else if(x<w*.5f)wanted=3;else wanted=1;}}
      invalidate();return true;}
    @Override public void computeScroll(){super.computeScroll();long now=System.currentTimeMillis();if(now-last>210){last=now;step();invalidate();}}
  }
}
