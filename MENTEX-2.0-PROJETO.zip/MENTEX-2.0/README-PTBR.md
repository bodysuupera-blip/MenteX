# MENTEX 2.0 — pacote de desenvolvimento

## O que está incluído
- Aplicação web local baseada no MENTEX original.
- As 200 fases originais preservadas no código, mais 50 fases novas (201–250).
- Progressão, mapa, moedas, vidas, dicas, escudos, perfil, ranking local, loja de itens, compartilhamento, bônus e interfaces de anúncio/compra já existentes no original.
- Imagens originais do cérebro e áudio de abertura extraídos do APK enviado.
- Identidade visual azul/roxo neon e mascote animado durante as perguntas.

## Importante sobre o APK
Este pacote ainda **não é um APK instalável**. O ambiente desta sessão não tem Android SDK, Gradle ou ferramentas de assinatura instaladas. Os pontos de integração nativa de compras Google Play e anúncios recompensados dependem da implementação Android/Capacitor e da configuração das contas e produtos reais. Não foram simuladas compras nem anúncios reais.

## Prévia local
Abra `www/index.html` em um navegador moderno. Para testar melhor, sirva a pasta `www` por um servidor HTTP local.

## Dados e moedas
O jogo original salva progresso no armazenamento local do navegador (`localStorage`). Uma instalação nova não importa automaticamente o progresso do aplicativo antigo; as moedas e fases existentes só poderão ser migradas se houver exportação/importação de dados ou um mecanismo de migração implementado na versão Android.
